import React, { useEffect, useRef, useState, useCallback } from "react";
import { Heart, Anchor, ChevronUp, RotateCcw, Play, Pause, Trophy, Flame, AlertTriangle, Gauge, Lock, Volume2, VolumeX, X, HelpCircle, ChevronRight, Sparkles, Check } from "lucide-react";

type PlatformKind = "normal" | "fragile" | "ghost" | "slow" | "fast" | "vertical" | "diagonal" | "bounce" | "ice" | "narrow" | "wide" | "spikes" | "conveyor" | "timed" | "gear" | "steam" | "shroom" | "vine";
type Platform = { x: number; y: number; w: number; fragile: boolean; gone: number; flash: number; moving: boolean; baseX: number; baseY: number; movePhase: number; moveRange: number; moveSpeed: number; kind: PlatformKind; conveyorDir: 1 | -1; ghostPhase: number; activated: number; checkpoint?: boolean };
type Enemy = { x: number; y: number; type: "hunter" | "gunner"; t: number; vx: number; vy: number; state: string; stateT: number; homeX: number; homeY: number; laserAngle: number; laserOn: boolean; fireT: number };
type Particle = { x: number; y: number; vx: number; vy: number; life: number; max: number; color: string; size: number; rot?: number; spin?: number; kind?: "pixel" | "star" | "bubble" | "ring"; split?: boolean };
type Telegraph = { x: number; y: number; type: "hunter" | "gunner"; t: number };
type Ghost = { x: number; y: number; dir: number; life: number; max: number };
type Shock = { x: number; y: number; t: number; max: number };

type LevelConfig = {
  id: number; name: string; short: string; desc: string; stars: number; icon: string;
  bg: string; edge: string; particle: string; floor: string; floor2: string;
  width: number; gap: number; zig: number; fragile: number; moving: number;
  floorSpeed: number; windEvery: number; tongue: boolean; enemyInterval: number; maxEnemies: number; moveSpeed: number;
  goal: number; ambient: string; sky: string;
};

const GOALS = [220,260,300,340,380,420,460,500,540,580,620,660,700,740,780,820,860,900,950,1000];
const PORTAL_COLORS: Record<number, string> = { 1: "#a855f7", 2: "#ff5400", 3: "#4ade80", 4: "#7dd3fc", 5: "#facc15", 6: "#ff2a85", 7: "#ef4444", 8: "#00e5ff", 9: "#7c3aed", 10: "#a3e635", 11: "#facc15", 12: "#ffffff", 13: "#84cc16", 14: "#f59e0b", 15: "#6d28d9", 16: "#f87171", 17: "#991b1b", 18: "#34d399", 19: "#22d3ee", 20: "#ff2d55", 21: "#ffb703", 22: "#00ff88" };
const portalColorFor = (id: number) => PORTAL_COLORS[id] || "#a855f7";
const LEVELS: LevelConfig[] = [
  { id:1, name:"GROTTA DEI CRISTALLI", short:"Cristalli", desc:"Cristalli che brillano e stalattiti. Piattaforme larghe per imparare.", stars:1, icon:"crystal", bg:"#0b0620", edge:"#a855f7", particle:"#c084fc", floor:"#1a0b2e", floor2:"#a855f7", width:78, gap:46, zig:55, fragile:0.08, moving:0, floorSpeed:12, windEvery:999, tongue:false, enemyInterval:4.5, maxEnemies:1, moveSpeed:0, goal:GOALS[0], ambient:"dust", sky:"#1a0b2e" },
  { id:2, name:"CAVERNA DI LAVA", short:"Lava", desc:"Fiumi di lava sotto, rocce nere. Prime piattaforme fragili.", stars:1, icon:"volcano", bg:"#1a0505", edge:"#ff5400", particle:"#ff9a3d", floor:"#1a0a2e", floor2:"#ff5400", width:74, gap:48, zig:58, fragile:0.12, moving:0, floorSpeed:13, windEvery:999, tongue:true, enemyInterval:4.2, maxEnemies:1, moveSpeed:0, goal:GOALS[1], ambient:"embers", sky:"#2a0a0a" },
  { id:3, name:"FORESTA SOTTERRANEA", short:"Foresta", desc:"Radici, muschio e funghi luminosi. Arriva l'Artigliere.", stars:2, icon:"tree", bg:"#07130a", edge:"#4ade80", particle:"#a7f3d0", floor:"#0a2a12", floor2:"#4ade80", width:70, gap:50, zig:60, fragile:0.12, moving:0, floorSpeed:14, windEvery:999, tongue:false, enemyInterval:3.8, maxEnemies:2, moveSpeed:0, goal:GOALS[2], ambient:"fireflies", sky:"#0a1f0f" },
  { id:4, name:"GHIACCIO ETERNO", short:"Ghiaccio", desc:"Ghiaccioli e neve che cade. Prime piattaforme mobili lente e fantasma.", stars:2, icon:"snowflake", bg:"#071a2e", edge:"#7dd3fc", particle:"#e0f2fe", floor:"#0a2a3a", floor2:"#7dd3fc", width:68, gap:50, zig:62, fragile:0.15, moving:0.15, floorSpeed:15, windEvery:999, tongue:false, enemyInterval:3.6, maxEnemies:2, moveSpeed:0.9, goal:GOALS[3], ambient:"snow", sky:"#0a2438" },
  { id:5, name:"DESERTO DI SABBIA", short:"Deserto", desc:"Dune, cactus e sole cocente. Piattaforme che si muovono e scompaiono.", stars:2, icon:"cactus", bg:"#2a1a05", edge:"#facc15", particle:"#fde68a", floor:"#3a2a0a", floor2:"#facc15", width:66, gap:52, zig:62, fragile:0.15, moving:0.18, floorSpeed:16, windEvery:999, tongue:false, enemyInterval:3.4, maxEnemies:2, moveSpeed:1, goal:GOALS[4], ambient:"dust", sky:"#3a2a0a" },
  { id:6, name:"CITTÀ NEON CYBER", short:"Neon", desc:"Grattacieli, insegne e pioggia elettrica. Nemici più frequenti.", stars:3, icon:"neon", bg:"#0a051a", edge:"#ff2a85", particle:"#ff7ad9", floor:"#1a0a2e", floor2:"#ff2a85", width:64, gap:52, zig:64, fragile:0.18, moving:0.2, floorSpeed:17, windEvery:999, tongue:false, enemyInterval:3.1, maxEnemies:2, moveSpeed:1.1, goal:GOALS[5], ambient:"rain", sky:"#140a2e" },
  { id:7, name:"VULCANO", short:"Vulcano", desc:"Fumo, brace e cenere. Il pavimento accelera, resta in movimento.", stars:3, icon:"flame", bg:"#120808", edge:"#ff6b35", particle:"#ff9a3d", floor:"#1a0a0a", floor2:"#ff6b35", width:62, gap:54, zig:64, fragile:0.2, moving:0.22, floorSpeed:18, windEvery:999, tongue:true, enemyInterval:3.0, maxEnemies:2, moveSpeed:1.2, goal:GOALS[6], ambient:"ash", sky:"#1f0d0d" },
  { id:8, name:"ABISSO OCEANICO", short:"Oceano", desc:"Bolle, coralli e pesci. Piattaforme veloci, verticali e ghiaccio.", stars:3, icon:"fish", bg:"#020a1a", edge:"#00e5ff", particle:"#7dd3fc", floor:"#021a2e", floor2:"#00e5ff", width:60, gap:54, zig:65, fragile:0.2, moving:0.25, floorSpeed:19, windEvery:999, tongue:false, enemyInterval:2.9, maxEnemies:2, moveSpeed:1.3, goal:GOALS[7], ambient:"bubbles", sky:"#042a3a" },
  { id:9, name:"SPAZIO STELLARE", short:"Spazio", desc:"Stelle, pianeti e nebulose. Rimbalza sui trampolini spaziali.", stars:3, icon:"star", bg:"#020204", edge:"#a855f7", particle:"#c084fc", floor:"#0a0614", floor2:"#a855f7", width:60, gap:55, zig:65, fragile:0.22, moving:0.25, floorSpeed:20, windEvery:999, tongue:false, enemyInterval:2.8, maxEnemies:2, moveSpeed:1.3, goal:GOALS[8], ambient:"dust", sky:"#0a0614" },
  { id:10, name:"GIUNGLA LUMINOSA", short:"Giungla", desc:"Liane, lucciole e fiori giganti. Salti veloci tra piattaforme mobili.", stars:4, icon:"butterfly", bg:"#071a05", edge:"#a3e635", particle:"#d9f99d", floor:"#0a2a0a", floor2:"#a3e635", width:58, gap:56, zig:66, fragile:0.22, moving:0.28, floorSpeed:21, windEvery:14, tongue:false, enemyInterval:2.7, maxEnemies:2, moveSpeed:1.4, goal:GOALS[9], ambient:"fireflies", sky:"#0f2a0a" },
  { id:11, name:"TEMPIO ANTICO", short:"Tempio", desc:"Colonne dorate, geroglifici e torce. Precisione sui salti.", stars:4, icon:"temple", bg:"#1a1205", edge:"#facc15", particle:"#fde68a", floor:"#2a1a0a", floor2:"#facc15", width:56, gap:56, zig:66, fragile:0.25, moving:0.28, floorSpeed:22, windEvery:999, tongue:false, enemyInterval:2.6, maxEnemies:3, moveSpeed:1.4, goal:GOALS[10], ambient:"embers", sky:"#241a05" },
  { id:12, name:"REGNO DELLE NUVOLE", short:"Nuvole", desc:"Nuvole soffici e arcobaleni. Vento leggero, piattaforme a tempo.", stars:4, icon:"cloud", bg:"#0a1a2e", edge:"#e0f2fe", particle:"#ffffff", floor:"#1a2a3a", floor2:"#e0f2fe", width:56, gap:57, zig:66, fragile:0.25, moving:0.3, floorSpeed:23, windEvery:12, tongue:false, enemyInterval:2.5, maxEnemies:3, moveSpeed:1.4, goal:GOALS[11], ambient:"dust", sky:"#1a3a5a" },
  { id:13, name:"PALUDE TOSSICA", short:"Palude", desc:"Bolle velenose e nebbia acida. Arrivano diagonali, strette e spuntoni.", stars:4, icon:"drop", bg:"#0a1a05", edge:"#84cc16", particle:"#a3e635", floor:"#0a2a0a", floor2:"#84cc16", width:54, gap:58, zig:68, fragile:0.28, moving:0.32, floorSpeed:24, windEvery:999, tongue:false, enemyInterval:2.4, maxEnemies:3, moveSpeed:1.5, goal:GOALS[12], ambient:"bubbles", sky:"#122a05" },
  { id:14, name:"MINIERA D'ORO", short:"Miniera", desc:"Binari, carrelli e lanterne. Conveyor che ti spingono, attento ai bordi.", stars:4, icon:"pickaxe", bg:"#120a02", edge:"#f59e0b", particle:"#fcd34d", floor:"#241505", floor2:"#f59e0b", width:54, gap:58, zig:68, fragile:0.28, moving:0.32, floorSpeed:25, windEvery:999, tongue:false, enemyInterval:2.3, maxEnemies:3, moveSpeed:1.5, goal:GOALS[13], ambient:"sparks", sky:"#1f1505" },
  { id:15, name:"CASTELLO OSCURO", short:"Castello", desc:"Torri, pipistrelli e luna. Nemici più veloci, salti più tesi.", stars:5, icon:"castle", bg:"#0d051a", edge:"#8b5cf6", particle:"#c4b5fd", floor:"#150a2a", floor2:"#8b5cf6", width:52, gap:59, zig:68, fragile:0.3, moving:0.35, floorSpeed:26, windEvery:999, tongue:false, enemyInterval:2.1, maxEnemies:3, moveSpeed:1.6, goal:GOALS[14], ambient:"dust", sky:"#1a0a2e" },
  { id:16, name:"MONDO DEI FUNGHI", short:"Funghi", desc:"Funghi giganti a pois e spore. Rimbalzi alti e piattaforme a tempo.", stars:5, icon:"mushroom", bg:"#1a050a", edge:"#f87171", particle:"#fecaca", floor:"#2a0a10", floor2:"#f87171", width:52, gap:59, zig:68, fragile:0.3, moving:0.35, floorSpeed:27, windEvery:999, tongue:false, enemyInterval:2.0, maxEnemies:3, moveSpeed:1.6, goal:GOALS[15], ambient:"spores", sky:"#2a0a12" },
  { id:17, name:"INFERNO DI FUOCO", short:"Inferno", desc:"Fiamme e demoni di roccia. Mix di tutto: veloce, stretto, pericoloso.", stars:5, icon:"flame", bg:"#1a0505", edge:"#ef4444", particle:"#fca5a5", floor:"#1a0a0a", floor2:"#ef4444", width:50, gap:60, zig:68, fragile:0.32, moving:0.38, floorSpeed:28, windEvery:999, tongue:true, enemyInterval:1.9, maxEnemies:3, moveSpeed:1.7, goal:GOALS[16], ambient:"embers", sky:"#240a0a" },
  { id:18, name:"AURORA BOREALE", short:"Aurora", desc:"Aurora che si muove e neve. Quasi tutto è mobile o fantasma.", stars:5, icon:"aurora", bg:"#020a12", edge:"#34d399", particle:"#6ee7b7", floor:"#041a12", floor2:"#34d399", width:50, gap:60, zig:68, fragile:0.32, moving:0.4, floorSpeed:29, windEvery:12, tongue:false, enemyInterval:1.8, maxEnemies:4, moveSpeed:1.8, goal:GOALS[17], ambient:"snow", sky:"#042a1a" },
  { id:19, name:"LABORATORIO ELETTRICO", short:"Lab", desc:"Circuiti, scintille e tubi. Conveyor veloci e piattaforme che spariscono.", stars:5, icon:"bolt", bg:"#050a12", edge:"#22d3ee", particle:"#67e8f9", floor:"#0a1420", floor2:"#22d3ee", width:48, gap:61, zig:68, fragile:0.33, moving:0.42, floorSpeed:30, windEvery:999, tongue:false, enemyInterval:1.7, maxEnemies:4, moveSpeed:1.9, goal:GOALS[18], ambient:"sparks", sky:"#0a1a24" },
  { id:20, name:"REGNO DEL VUOTO FINALE", short:"Vuoto", desc:"Portali e frammenti di realtà. Ondata finale: più nemici, tutto insieme.", stars:5, icon:"portal", bg:"#020204", edge:"#ff2d55", particle:"#f472b6", floor:"#050208", floor2:"#ff2d55", width:48, gap:62, zig:68, fragile:0.33, moving:0.45, floorSpeed:32, windEvery:14, tongue:true, enemyInterval:1.6, maxEnemies:5, moveSpeed:2, goal:GOALS[19], ambient:"dust", sky:"#0d0210" },
  { id:21, name:"BONUS 1 — TEMPESTA STEAMPUNK", short:"Steampunk", desc:"Ingranaggi, rame e vapore. Piattaforme attorcigliate, ingranaggi e venti di vapore.", stars:5, icon:"gear", bg:"#1a0f08", edge:"#d4a017", particle:"#ffb703", floor:"#1a0f08", floor2:"#ff6b00", width:62, gap:54, zig:64, fragile:0.22, moving:0.3, floorSpeed:28, windEvery:999, tongue:false, enemyInterval:2.0, maxEnemies:3, moveSpeed:1.5, goal:450, ambient:"sparks", sky:"#241505" },
  { id:22, name:"BONUS 2 — FORESTA BIOLUMINESCENTE", short:"Biolum", desc:"Funghi luminosi e liane che ondeggiano. Rimbalza sui funghi ciano.", stars:5, icon:"glowshroom", bg:"#0a1a2e", edge:"#00ff88", particle:"#a3ff00", floor:"#0a1a2e", floor2:"#00ff88", width:62, gap:54, zig:64, fragile:0.22, moving:0.3, floorSpeed:28, windEvery:999, tongue:false, enemyInterval:2.0, maxEnemies:3, moveSpeed:1.5, goal:450, ambient:"fireflies", sky:"#0d2a1a" },
];

// UNLOCK_ALL = true mette in pausa la logica di blocco in sequenza (tutti i 22 mondi giocabili).
// Per tornare al blocco progressivo, rimettere UNLOCK_ALL = false: la logica originale resta intatta.
const UNLOCK_ALL = true;
const ALL_LEVEL_IDS = LEVELS.map((lv) => lv.id);
type PixelRect = [number, number, number, number, string];
function PixelWorldIcon({ kind, size, glow }: { kind: string; size: number; glow: string }) {
  const P = (x: number, y: number, w: number, h: number, c: string): PixelRect => [x, y, w, h, c];
  let rects: PixelRect[] = [];
  switch (kind) {
    case "crystal": rects = [P(7, 0, 2, 2, "#ffffff"), P(6, 2, 4, 2, "#e9d5ff"), P(5, 4, 6, 2, "#c084fc"), P(4, 6, 8, 2, "#a855f7"), P(5, 8, 6, 2, "#7dd3fc"), P(6, 10, 4, 2, "#7c3aed"), P(7, 12, 2, 2, "#4c1d95"), P(7, 14, 2, 2, "#2e1065"), P(6, 4, 1, 2, "#ffffff")]; break;
    case "volcano": rects = [P(7, 0, 2, 1, "#d1d5db"), P(7, 1, 2, 2, "#9ca3af"), P(5, 3, 6, 2, "#ff9a3d"), P(4, 5, 8, 2, "#ff5400"), P(3, 7, 10, 2, "#78716c"), P(2, 9, 12, 2, "#44403c"), P(1, 11, 14, 2, "#292524"), P(0, 13, 16, 3, "#1a0a0a"), P(7, 7, 2, 4, "#ff5400"), P(8, 11, 2, 2, "#ffd23d")]; break;
    case "tree": rects = [P(6, 1, 4, 2, "#4ade80"), P(4, 3, 8, 2, "#22c55e"), P(3, 5, 10, 2, "#16a34a"), P(4, 7, 8, 2, "#4ade80"), P(6, 9, 4, 2, "#22c55e"), P(7, 10, 2, 6, "#78350f"), P(5, 5, 1, 1, "#facc15"), P(10, 6, 1, 1, "#fef08a")]; break;
    case "snowflake": rects = [P(7, 0, 2, 16, "#7dd3fc"), P(0, 7, 16, 2, "#7dd3fc"), P(2, 2, 2, 2, "#bae6fd"), P(4, 4, 2, 2, "#bae6fd"), P(10, 10, 2, 2, "#bae6fd"), P(12, 12, 2, 2, "#bae6fd"), P(12, 2, 2, 2, "#bae6fd"), P(10, 4, 2, 2, "#bae6fd"), P(4, 10, 2, 2, "#bae6fd"), P(2, 12, 2, 2, "#bae6fd"), P(6, 6, 4, 4, "#ffffff"), P(7, 7, 2, 2, "#0ea5e9")]; break;
    case "cactus": rects = [P(12, 1, 3, 3, "#facc15"), P(11, 0, 1, 1, "#fde68a"), P(3, 3, 2, 11, "#22c55e"), P(3, 6, 5, 2, "#22c55e"), P(6, 6, 2, 4, "#16a34a"), P(4, 5, 1, 1, "#a7f3d0"), P(0, 14, 16, 2, "#eab308"), P(0, 12, 16, 2, "#facc15")]; break;
    case "neon": rects = [P(1, 5, 4, 11, "#1a0a2e"), P(6, 2, 4, 14, "#0a051a"), P(11, 7, 4, 9, "#1a0a2e"), P(2, 7, 2, 2, "#ff2a85"), P(7, 4, 2, 2, "#22d3ee"), P(12, 9, 2, 2, "#facc15"), P(2, 11, 2, 2, "#22d3ee"), P(7, 9, 2, 2, "#ff2a85"), P(7, 0, 1, 2, "#ffffff")]; break;
    case "fish": rects = [P(2, 7, 8, 3, "#00e5ff"), P(1, 8, 2, 1, "#22d3ee"), P(10, 6, 3, 4, "#22d3ee"), P(3, 8, 1, 1, "#ffffff"), P(12, 2, 2, 2, "#bae6fd"), P(14, 5, 1, 1, "#bae6fd"), P(13, 11, 2, 5, "#f472b6"), P(0, 14, 16, 2, "#0284c7"), P(6, 7, 3, 1, "#ffffff")]; break;
    case "star": rects = [P(7, 0, 2, 3, "#ffffff"), P(0, 7, 3, 2, "#ffffff"), P(13, 7, 3, 2, "#ffffff"), P(7, 13, 2, 3, "#ffffff"), P(5, 5, 6, 6, "#facc15"), P(6, 6, 4, 4, "#f59e0b"), P(11, 11, 4, 3, "#a855f7"), P(10, 12, 6, 1, "#22d3ee"), P(12, 10, 1, 1, "#ffffff")]; break;
    case "butterfly": rects = [P(2, 3, 5, 5, "#a3e635"), P(9, 3, 5, 5, "#4ade80"), P(3, 9, 4, 3, "#84cc16"), P(9, 9, 4, 3, "#22c55e"), P(7, 2, 2, 12, "#14532d"), P(5, 1, 2, 2, "#14532d"), P(9, 1, 2, 2, "#14532d"), P(4, 5, 2, 2, "#fef08a"), P(10, 5, 2, 2, "#fef08a")]; break;
    case "temple": rects = [P(2, 2, 12, 2, "#facc15"), P(3, 4, 2, 10, "#f59e0b"), P(7, 4, 2, 10, "#f59e0b"), P(11, 4, 2, 10, "#f59e0b"), P(1, 14, 14, 2, "#f59e0b"), P(7, 6, 2, 2, "#ff5400"), P(7, 8, 2, 1, "#ffd23d")]; break;
    case "cloud": rects = [P(4, 5, 8, 3, "#ffffff"), P(2, 8, 12, 4, "#ffffff"), P(6, 4, 4, 1, "#e0f2fe"), P(2, 13, 12, 1, "#ff3b6b"), P(2, 14, 12, 1, "#ffd23d"), P(2, 15, 12, 1, "#4ade80")]; break;
    case "drop": rects = [P(7, 1, 2, 2, "#a3e635"), P(5, 4, 6, 3, "#a3e635"), P(4, 7, 8, 4, "#84cc16"), P(6, 11, 4, 3, "#4d7c0f"), P(1, 2, 2, 2, "#a3e635"), P(13, 5, 2, 2, "#a3e635"), P(1, 12, 2, 2, "#22d3ee"), P(5, 8, 1, 2, "#d9f99d")]; break;
    case "pickaxe": rects = [P(2, 2, 2, 2, "#fcd34d"), P(4, 4, 2, 2, "#fcd34d"), P(6, 6, 2, 2, "#fcd34d"), P(8, 8, 2, 2, "#fcd34d"), P(10, 10, 2, 2, "#fcd34d"), P(1, 5, 11, 2, "#f59e0b"), P(12, 11, 3, 3, "#f59e0b"), P(11, 14, 2, 2, "#facc15"), P(3, 12, 2, 2, "#f59e0b")]; break;
    case "castle": rects = [P(12, 1, 3, 3, "#fef3c7"), P(2, 3, 4, 13, "#8b5cf6"), P(10, 3, 4, 13, "#8b5cf6"), P(2, 2, 2, 1, "#a78bfa"), P(4, 2, 2, 1, "#a78bfa"), P(10, 2, 2, 1, "#a78bfa"), P(12, 2, 2, 1, "#a78bfa"), P(6, 8, 4, 8, "#6d28d9"), P(7, 12, 2, 4, "#0d051a"), P(7, 6, 2, 2, "#ffd23d")]; break;
    case "mushroom": rects = [P(2, 5, 12, 4, "#f87171"), P(4, 6, 2, 2, "#ffffff"), P(10, 6, 2, 2, "#ffffff"), P(7, 5, 2, 1, "#ffffff"), P(6, 9, 4, 5, "#fef3c7"), P(0, 14, 16, 2, "#22c55e"), P(7, 10, 2, 1, "#78350f")]; break;
    case "flame": rects = [P(6, 1, 4, 4, "#ef4444"), P(4, 5, 8, 4, "#f97316"), P(5, 9, 6, 4, "#facc15"), P(6, 13, 4, 2, "#7f1d1d"), P(6, 7, 2, 2, "#ffffff"), P(11, 2, 2, 2, "#fca5a5")]; break;
    case "aurora": rects = [P(0, 3, 16, 2, "#34d399"), P(0, 6, 16, 2, "#7dd3fc"), P(0, 9, 16, 2, "#a78bfa"), P(2, 14, 3, 2, "#ffffff"), P(11, 13, 3, 2, "#ffffff"), P(12, 1, 2, 2, "#fef08a"), P(4, 1, 1, 1, "#ffffff")]; break;
    case "bolt": rects = [P(10, 0, 3, 4, "#facc15"), P(7, 4, 6, 3, "#facc15"), P(9, 7, 4, 3, "#facc15"), P(5, 10, 6, 3, "#facc15"), P(7, 13, 3, 3, "#facc15"), P(10, 4, 2, 2, "#ffffff"), P(2, 8, 2, 2, "#22d3ee"), P(13, 11, 2, 2, "#22d3ee")]; break;
    case "portal": rects = [P(5, 1, 6, 2, "#ff2d55"), P(3, 3, 2, 2, "#ff2d55"), P(11, 3, 2, 2, "#ff2d55"), P(2, 5, 2, 6, "#ff2d55"), P(12, 5, 2, 6, "#ff2d55"), P(3, 11, 2, 2, "#ff2d55"), P(11, 11, 2, 2, "#ff2d55"), P(5, 13, 6, 2, "#ff2d55"), P(6, 6, 4, 4, "#0b0620"), P(7, 7, 2, 2, "#ffffff"), P(7, 3, 2, 1, "#ffd23d")]; break;
    case "gear": rects = [P(6, 0, 4, 2, "#d4a017"), P(6, 14, 4, 2, "#d4a017"), P(0, 6, 2, 4, "#d4a017"), P(14, 6, 2, 4, "#d4a017"), P(2, 2, 3, 3, "#d4a017"), P(11, 2, 3, 3, "#d4a017"), P(2, 11, 3, 3, "#d4a017"), P(11, 11, 3, 3, "#d4a017"), P(4, 4, 8, 8, "#b87333"), P(6, 6, 4, 4, "#1a0f08"), P(7, 7, 2, 2, "#ffb703")]; break;
    case "glowshroom": rects = [P(2, 5, 12, 4, "#00ffff"), P(4, 6, 2, 2, "#ffffff"), P(10, 6, 2, 2, "#ffffff"), P(7, 5, 2, 1, "#a3ff00"), P(6, 9, 4, 5, "#0a1a2e"), P(0, 14, 16, 2, "#00ff88"), P(7, 2, 2, 2, "#a3ff00"), P(0, 10, 4, 2, "#00ff88")]; break;
    case "lock": rects = [P(5, 2, 6, 3, "#facc15"), P(6, 2, 4, 1, "#0d1321"), P(3, 5, 10, 9, "#facc15"), P(7, 8, 2, 4, "#0d1321"), P(6, 7, 4, 2, "#0d1321")]; break;
    default: rects = [P(7, 1, 2, 2, "#ffffff"), P(5, 4, 6, 2, "#facc15"), P(4, 7, 8, 3, "#f59e0b"), P(6, 10, 4, 3, "#b45309"), P(7, 13, 2, 2, "#78350f")]; break;
  }
  return (<svg width={size} height={size} viewBox="0 0 16 16" role="img" aria-hidden="true" style={{ display: "block", filter: `drop-shadow(0 0 ${Math.max(3, size * 0.1)}px ${glow})`, imageRendering: "pixelated" }}>{rects.map((r, i) => <rect key={i} x={r[0]} y={r[1]} width={r[2]} height={r[3]} fill={r[4]} />)}</svg>);
}
const W = 270, H = 480, START_Y = 420;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
// RNG con seed per livello: stessa disposizione a ogni partita dello stesso livello, livelli diversi tra loro.
function mulberry32(seed: number) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
// 6 pattern che ruotano ogni 8-12 piattaforme + larghezze/gap variabili, mai 5 di fila uguali.
function buildLevelPlatforms(cfg: LevelConfig): Platform[] {
  const rng = mulberry32(cfg.id * 7919 + 13);
  const plats: Platform[] = [{ x: 135, y: START_Y, w: 200, fragile: false, gone: 0, flash: 0, moving: false, baseX: 135, baseY: START_Y, movePhase: 0, moveRange: 0, moveSpeed: 0, kind: "wide", conveyorDir: 1, ghostPhase: 0, activated: 0 }];
  const finalY = START_Y - cfg.goal * 12;
  const midY = START_Y - Math.floor(cfg.goal / 2) * 12;
  let y = START_Y, prevX = 135, prevW = 90, prevGap = 0, prevKind: PlatformKind = "wide";
  let pattern = 0, patternLeft = 8 + Math.floor(rng() * 5);
  let spiralDir = 1, diagDir = 1, ladderCount = 0, ladderSide = -1, vStep = 0, clusterExtra = 0;
  const zigSeq = [32, 135, 238, 135];
  let zigIdx = 0;
  const mk = (px: number, py: number, idx: number, isCheckpoint = false): Platform => {
    let kind = pickKind(cfg, idx, prevKind);
    if (isCheckpoint) kind = "wide";
    let w = cfg.width + rng() * 4;
    if (kind === "narrow") w = 28;
    else if (kind === "wide") w = 100;
    else w = 30 + rng() * 62; // 30..92, varia sempre
    if (Math.abs(w - prevW) < 4) w = clamp(w + (rng() < 0.5 ? -14 : 14), 28, 100);
    const moving = ["slow", "fast", "vertical", "diagonal", "gear", "vine"].includes(kind);
    return { x: clamp(px, 30, 240), y: py, w, fragile: kind === "fragile", gone: 0, flash: 0, moving, baseX: clamp(px, 30, 240), baseY: py, movePhase: rng() * Math.PI * 2, moveRange: kind === "fast" ? 42 : 34, moveSpeed: cfg.moveSpeed, kind, conveyorDir: rng() < 0.5 ? -1 : 1, ghostPhase: rng() * 3, activated: 0, checkpoint: isCheckpoint };
  };
  let idx = 1;
  while (y > finalY) {
    if (patternLeft <= 0) { pattern = (pattern + 1) % 6; patternLeft = 8 + Math.floor(rng() * 5); vStep = 0; ladderCount = 0; }
    let gap = 55 + rng() * 30; // 55..85
    if (Math.abs(gap - prevGap) < 3) gap = clamp(gap + 9, 55, 85);
    prevGap = gap; y -= gap;
    if (y <= finalY) break;
    let cx = prevX;
    if (pattern === 0) { cx = zigSeq[zigIdx % zigSeq.length]; zigIdx++; }
    else if (pattern === 1) { cx = clamp(prevX + spiralDir * 40, 32, 238); if (cx <= 34 || cx >= 236) spiralDir *= -1; }
    else if (pattern === 2) { ladderCount++; if (ladderCount > 3) { ladderCount = 1; ladderSide *= -1; } cx = ladderSide < 0 ? 42 + rng() * 14 : 228 - rng() * 14; }
    else if (pattern === 3) { const vSeq = [238, 192, 135, 192, 238, 78, 135, 78]; cx = vSeq[vStep % vSeq.length]; vStep++; }
    else if (pattern === 4) { cx = 45 + rng() * 180; }
    else { cx = clamp(prevX + diagDir * (28 + rng() * 22), 32, 238); if (cx <= 34 || cx >= 236) diagDir *= -1; }
    if (Math.abs(cx - prevX) > 118) cx = clamp(prevX + Math.sign(cx - prevX) * 118, 30, 240);
    const isCheck = !plats.some(p => p.checkpoint) && Math.abs(y - midY) < gap;
    const p = mk(cx, y, idx, isCheck);
    // Mobili: attraversano tutta la larghezza (base centrata, ampio range)
    if (p.moving) { p.baseX = 135; p.x = 135; p.moveRange = 88; }
    // Fantasma in punti difficili (vicino ai muri), rimbalzante sotto un salto alto
    if (p.kind === "ghost") { p.x = rng() < 0.5 ? 38 : 232; p.baseX = p.x; }
    if (p.kind === "bounce") { p.x = clamp(prevX + (rng() < 0.5 ? -55 : 55), 40, 230); p.baseX = p.x; }
    plats.push(p); prevX = p.x; prevW = p.w; idx++; patternLeft--;
    // Grappoli: 2-3 piattaforme alla stessa altezza
    if (pattern === 4 && rng() < 0.55) {
      const extra = 1 + (rng() < 0.4 ? 1 : 0);
      for (let k = 0; k < extra; k++) {
        const ex = clamp(p.x + (k === 0 ? -95 : 95) + (rng() * 30 - 15), 30, 240);
        if (Math.abs(ex - p.x) < 55) continue;
        const ep = mk(ex, y, idx, false); plats.push(ep); idx++;
      }
      clusterExtra++;
    }
    // A volte 2 piattaforme sovrapposte con piccolo offset
    if (rng() < 0.08 && y - 28 > finalY) { const op = mk(clamp(p.x + (rng() < 0.5 ? -38 : 38), 30, 240), y - 26, idx, false); plats.push(op); idx++; }
  }
  if (!plats.some(p => p.checkpoint)) { const cp = mk(135, midY, idx, true); plats.push(cp); }
  plats.push({ x: 135, y: finalY, w: 120, fragile: false, gone: 0, flash: 0, moving: false, baseX: 135, baseY: finalY, movePhase: 0, moveRange: 0, moveSpeed: 0, kind: "wide", conveyorDir: 1, ghostPhase: 0, activated: 0 });
  plats.sort((a, b) => b.y - a.y);
  // Speciali bonus: 2 ingranaggi + 2 venti di vapore (21) oppure 2 funghi + 2 liane (22).
  if (cfg.id === 21 || cfg.id === 22) {
    const n = plats.length;
    const setSpecial = (idx: number, kind: PlatformKind, moving: boolean) => { const p = plats[idx]; if (!p || p.y === finalY) return; p.kind = kind; p.fragile = false; p.moving = moving; p.w = kind === "gear" || kind === "vine" ? 74 : 66; p.baseX = p.x; p.baseY = p.y; };
    if (cfg.id === 21) { setSpecial(Math.floor(n * 0.35), "gear", true); setSpecial(Math.floor(n * 0.55), "steam", false); setSpecial(Math.floor(n * 0.70), "gear", true); setSpecial(Math.floor(n * 0.85), "steam", false); }
    else { setSpecial(Math.floor(n * 0.35), "shroom", false); setSpecial(Math.floor(n * 0.55), "vine", true); setSpecial(Math.floor(n * 0.70), "shroom", false); setSpecial(Math.floor(n * 0.85), "vine", true); }
  }
  // Prime 6 piattaforme sempre sicure e vicine.
  for (let i = 1; i < Math.min(6, plats.length); i++) { if (plats[i].y === finalY) continue; plats[i].fragile = false; plats[i].moving = false; plats[i].kind = i % 5 === 0 ? "wide" : "normal"; plats[i].w = plats[i].kind === "wide" ? 90 : cfg.width; plats[i].x = clamp(135 + (i % 2 === 0 ? -12 : 12), 105, 165); plats[i].baseX = plats[i].x; plats[i].checkpoint = false; }
  return plats;
}

function computeGrappleTarget(px: number, py: number, dir: 1 | -1): { x: number; y: number; ok: boolean } {
  const cx = px + 8, cy = py + 8;
  const wallX = dir < 0 ? 17 : 253;
  const dx = dir * 0.866, dy = -0.5;
  const t = (wallX - cx) / dx;
  const y = cy + dy * t;
  const above = cy - y;
  if (above < 30) return { x: wallX, y, ok: false };
  return { x: wallX, y, ok: true };
}
async function api(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Errore ${res.status}`);
  return json.data;
}
function difficultyFor(m: number, cfg: LevelConfig) {
  return { level: cfg.id, label: cfg.name, minW: cfg.width, maxW: cfg.width + 2, gap: cfg.gap, fragile: cfg.fragile, moving: cfg.moving, enemyInterval: cfg.enemyInterval, maxEnemies: cfg.maxEnemies, moveSpeed: cfg.moveSpeed };
}
function pickKind(cfg: LevelConfig, idx: number, prevKind: PlatformKind): PlatformKind {
  if (idx % 5 === 0) return "wide";
  if (prevKind === "fragile" || prevKind === "timed" || prevKind === "spikes") return Math.random() < 0.6 ? "normal" : "wide";
  const r = Math.random();
  const id = cfg.id;
  if (id <= 3) {
    if (r < 0.12) return "fragile";
    if (r < 0.22) return "wide";
    return "normal";
  }
  if (id <= 7) {
    if (r < 0.12) return "fragile";
    if (r < 0.24) return "slow";
    if (r < 0.34) return "ghost";
    if (r < 0.40) return "timed";
    return "normal";
  }
  if (id <= 12) {
    if (r < 0.10) return "fragile";
    if (r < 0.20) return "slow";
    if (r < 0.29) return "fast";
    if (r < 0.38) return "vertical";
    if (r < 0.47) return "ghost";
    if (r < 0.55) return "ice";
    if (r < 0.62) return "bounce";
    if (r < 0.68) return "timed";
    return "normal";
  }
  if (id <= 17) {
    if (r < 0.08) return "fragile";
    if (r < 0.16) return "slow";
    if (r < 0.24) return "fast";
    if (r < 0.32) return "vertical";
    if (r < 0.40) return "diagonal";
    if (r < 0.49) return "ghost";
    if (r < 0.56) return "ice";
    if (r < 0.62) return "bounce";
    if (r < 0.70) return "narrow";
    if (r < 0.77) return "spikes";
    if (r < 0.85) return "conveyor";
    if (r < 0.91) return "timed";
    return "normal";
  }
  if (r < 0.07) return "fragile";
  if (r < 0.15) return "fast";
  if (r < 0.23) return "vertical";
  if (r < 0.31) return "diagonal";
  if (r < 0.39) return "ghost";
  if (r < 0.46) return "ice";
  if (r < 0.53) return "bounce";
  if (r < 0.61) return "narrow";
  if (r < 0.69) return "spikes";
  if (r < 0.77) return "conveyor";
  if (r < 0.84) return "slow";
  if (r < 0.90) return "timed";
  return "normal";
}
function makePlatform(y: number, time: number, cfg: LevelConfig, prevX?: number, prevKind: PlatformKind = "normal", idx = 0): Platform {
  const d = difficultyFor(0, cfg);
  const kind = pickKind(cfg, idx, prevKind);
  let w = d.minW + Math.random() * (d.maxW - d.minW);
  if (kind === "narrow") w = 28;
  if (kind === "wide") w = 90;
  if (kind === "bounce") w = Math.max(48, w - 8);
  let cx = 135 + (Math.random() * 60 - 30);
  if (prevX !== undefined) {
    // GIOCABILITÀ: spostamento orizzontale max 70px rispetto alla precedente.
    const maxStep = 70;
    cx = clamp(cx, prevX - maxStep, prevX + maxStep);
    // Zig-zag dolce nei livelli alti, ma sempre entro 70px.
    if (cfg.id >= 8 && Math.random() < 0.45) {
      const dir = Math.random() < 0.5 ? -1 : 1;
      cx = clamp(prevX + dir * (35 + Math.random() * 30), 60, 210);
    }
  }
  cx = clamp(cx, 60, 210);
  // Se per arrotondamento restasse un salto >70px, riportala a 70px.
  if (prevX !== undefined && Math.abs(cx - prevX) > 70) cx = clamp(prevX + Math.sign(cx - prevX) * 70, 60, 210);
  const fragile = kind === "fragile";
  const moving = ["slow","fast","vertical","diagonal","gear","vine"].includes(kind);
  return { x: cx, y, w, fragile, gone: 0, flash: 0, moving, baseX: cx, baseY: y, movePhase: Math.random() * Math.PI * 2, moveRange: kind === "fast" ? 35 : 30, moveSpeed: d.moveSpeed, kind, conveyorDir: Math.random() < 0.5 ? -1 : 1, ghostPhase: Math.random() * 3, activated: 0 };
}
function ghostVisible(p: Platform, time: number) {
  if (p.kind !== "ghost") return true;
  const c = (time + p.ghostPhase) % 3;
  return c < 1.5;
}
function ghostBlink(p: Platform, time: number) {
  if (p.kind !== "ghost") return false;
  const c = (time + p.ghostPhase) % 3;
  return c >= 1.2 && c < 1.5;
}
// --- 5 FAMIGLIE DI MATTONCINI (pixel art disegnata via canvas, nessuna immagine con sfondo) ---
type BrickFamily = "A" | "B" | "C" | "D" | "E" | "F" | "G";
type BrickPalette = { family: BrickFamily; name: string; base: string; dark: string; edge: string; glow: string; accent: string; crack: string; shard1: string; shard2: string; trail: string; dots: boolean };
function brickFamilyFor(id: number): BrickFamily {
  if (id === 21) return "F";
  if (id === 22) return "G";
  if ([1, 3, 9, 10, 18].includes(id)) return "A";
  if ([6, 11, 19, 20].includes(id)) return "B";
  if ([5, 12, 15].includes(id)) return "C";
  if ([2, 7, 14, 17].includes(id)) return "D";
  return "E";
}
function brickPaletteFor(cfg: LevelConfig): BrickPalette {
  const f = brickFamilyFor(cfg.id);
  const baseFor = (o: Partial<BrickPalette> & Pick<BrickPalette, "name" | "base" | "dark" | "edge" | "glow" | "accent" | "crack" | "shard1" | "shard2" | "trail">): BrickPalette => ({ family: f, dots: false, ...o });
  switch (cfg.id) {
    case 1: return baseFor({ name: "CRISTALLI RETRO SCI-FI", base: "#241239", dark: "#150822", edge: "#a855f7", glow: "#22d3ee", accent: "#ff8a00", crack: "#e879f9", shard1: "#c084fc", shard2: "#67e8f9", trail: "#a855f7" });
    case 3: return baseFor({ name: "CRISTALLI VERDI", base: "#0f2a18", dark: "#081a0e", edge: "#4ade80", glow: "#a7f3d0", accent: "#facc15", crack: "#86efac", shard1: "#4ade80", shard2: "#d9f99d", trail: "#4ade80" });
    case 9: return baseFor({ name: "CRISTALLI SPAZIALI", base: "#0a0614", dark: "#05030c", edge: "#a855f7", glow: "#f472b6", accent: "#22d3ee", crack: "#e879f9", shard1: "#c084fc", shard2: "#f472b6", trail: "#a855f7" });
    case 10: return baseFor({ name: "CRISTALLI GIUNGLA", base: "#122a0a", dark: "#0a1a05", edge: "#a3e635", glow: "#38f2c8", accent: "#fef08a", crack: "#bef264", shard1: "#a3e635", shard2: "#5eead4", trail: "#a3e635" });
    case 18: return baseFor({ name: "CRISTALLI AURORA", base: "#041a12", dark: "#02100c", edge: "#34d399", glow: "#7dd3fc", accent: "#f472b6", crack: "#6ee7b7", shard1: "#34d399", shard2: "#7dd3fc", trail: "#34d399" });
    case 6: return baseFor({ name: "PANNELLI TECH", base: "#1a1a2e", dark: "#0f0f1e", edge: "#22d3ee", glow: "#ff2a85", accent: "#f59e0b", crack: "#fbbf24", shard1: "#94a3b8", shard2: "#ffd23d", trail: "#22d3ee" });
    case 11: return baseFor({ name: "TECH ORO", base: "#241a05", dark: "#150e02", edge: "#facc15", glow: "#f59e0b", accent: "#22d3ee", crack: "#fde68a", shard1: "#fcd34d", shard2: "#f59e0b", trail: "#facc15" });
    case 19: return baseFor({ name: "PANNELLI ELETTRICI", base: "#0a1420", dark: "#050a12", edge: "#22d3ee", glow: "#facc15", accent: "#ff2a85", crack: "#fde68a", shard1: "#67e8f9", shard2: "#ffd23d", trail: "#22d3ee" });
    case 20: return baseFor({ name: "PANNELLI VUOTO", base: "#0d0210", dark: "#050108", edge: "#ff2d55", glow: "#a855f7", accent: "#22d3ee", crack: "#fb7185", shard1: "#94a3b8", shard2: "#ff2d55", trail: "#ff2d55" });
    case 5: return baseFor({ name: "CIBER-TRON SABBIA", base: "#3a2a0a", dark: "#241a05", edge: "#facc15", glow: "#ff5400", accent: "#22d3ee", crack: "#fde68a", shard1: "#67e8f9", shard2: "#facc15", trail: "#facc15" });
    case 12: return baseFor({ name: "CIBER-TRON NEON", base: "#1a1a3a", dark: "#0d0d22", edge: "#22d3ee", glow: "#ff2a85", accent: "#e0f2fe", crack: "#f472b6", shard1: "#67e8f9", shard2: "#ff2a85", trail: "#ff2a85" });
    case 15: return baseFor({ name: "CIBER-TRON CASTELLO", base: "#150a2a", dark: "#0a0518", edge: "#8b5cf6", glow: "#ff2a85", accent: "#22d3ee", crack: "#c4b5fd", shard1: "#67e8f9", shard2: "#a78bfa", trail: "#8b5cf6" });
    case 2: return baseFor({ name: "MAGMA CORE", base: "#1a0a0a", dark: "#0d0505", edge: "#ff5400", glow: "#ffd23d", accent: "#ff9a3d", crack: "#ff6b35", shard1: "#44403c", shard2: "#ff5400", trail: "#ff5400" });
    case 7: return baseFor({ name: "MAGMA VULCANO", base: "#1f0d0d", dark: "#120808", edge: "#ff6b35", glow: "#facc15", accent: "#ff9a3d", crack: "#fb923c", shard1: "#292524", shard2: "#ff6b35", trail: "#ff6b35" });
    case 14: return baseFor({ name: "MAGMA MINIERA", base: "#241505", dark: "#150d02", edge: "#f59e0b", glow: "#ffd23d", accent: "#ff5400", crack: "#fbbf24", shard1: "#78716c", shard2: "#f59e0b", trail: "#f59e0b" });
    case 17: return baseFor({ name: "MAGMA INFERNO", base: "#1a0505", dark: "#0d0202", edge: "#ef4444", glow: "#facc15", accent: "#ff6b35", crack: "#fca5a5", shard1: "#1c1917", shard2: "#ef4444", trail: "#ef4444" });
    case 4: return baseFor({ name: "ABISSO AZZURRO", base: "#0a2a3a", dark: "#051a26", edge: "#bae6fd", glow: "#7dd3fc", accent: "#e0f2fe", crack: "#7dd3fc", shard1: "#334155", shard2: "#7dd3fc", trail: "#7dd3fc" });
    case 8: return baseFor({ name: "ABISSO BLU", base: "#021a2e", dark: "#010d18", edge: "#00e5ff", glow: "#7dd3fc", accent: "#f472b6", crack: "#67e8f9", shard1: "#1e3a4a", shard2: "#00e5ff", trail: "#00e5ff" });
    case 13: return baseFor({ name: "ABISSO TOSSICO", base: "#0a2a0a", dark: "#051a05", edge: "#84cc16", glow: "#a3e635", accent: "#22d3ee", crack: "#a3e635", shard1: "#1a2a1a", shard2: "#84cc16", trail: "#84cc16" });
    case 16: return baseFor({ name: "ABISSO FUNGHI", base: "#2a0a10", dark: "#180508", edge: "#f87171", glow: "#fecaca", accent: "#fde68a", crack: "#fca5a5", shard1: "#44403c", shard2: "#f87171", trail: "#f87171", dots: true });
    case 21: return baseFor({ name: "RAME STEAMPUNK", base: "#2a0a2e", dark: "#1a0f08", edge: "#ffb703", glow: "#ff6b00", accent: "#d4a017", crack: "#ff6b00", shard1: "#b87333", shard2: "#ffb703", trail: "#ff6b00" });
    case 22: return baseFor({ name: "BIOLUMINESCENTE", base: "#5a2a8a", dark: "#1a0a2e", edge: "#00ff88", glow: "#00ffff", accent: "#a3ff00", crack: "#a3ff00", shard1: "#00ff88", shard2: "#00ffff", trail: "#00ff88", dots: true });
    default: return baseFor({ name: "CRISTALLI", base: "#241239", dark: "#150822", edge: "#a855f7", glow: "#22d3ee", accent: "#ff8a00", crack: "#e879f9", shard1: "#c084fc", shard2: "#67e8f9", trail: "#a855f7" });
  }
}

// --- KUBO DEL MENU: faccia animata (occhi che seguono il cursore, bocca che respira, sbadiglio, salto di gioia) ---
function MenuKubo() {
  const [now, setNow] = useState(0);
  const [gaze, setGaze] = useState({ x: 0, y: 0 });
  const [lastTouch, setLastTouch] = useState(() => Date.now());
  const [joyUntil, setJoyUntil] = useState(-1);
  const [stars, setStars] = useState<{ id: number; x: number; y: number; c: string }[]>([]);
  useEffect(() => {
    const t0 = Date.now();
    const iv = setInterval(() => setNow((Date.now() - t0) / 1000), 90);
    const move = (e: PointerEvent) => {
      const el = document.getElementById("menu-kubo");
      if (!el) return;
      const r = el.getBoundingClientRect();
      setGaze({ x: Math.max(-1, Math.min(1, ((e.clientX - (r.left + r.width / 2)) / 90))), y: Math.max(-1, Math.min(1, ((e.clientY - (r.top + r.height / 2)) / 90))) });
      setLastTouch(Date.now());
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerdown", move);
    return () => { clearInterval(iv); window.removeEventListener("pointermove", move); window.removeEventListener("pointerdown", move); };
  }, []);
  const idleSec = (Date.now() - (lastTouch || Date.now())) / 1000;
  const joy = now < joyUntil;
  const blink = !joy && (now % 2) < 0.12;
  const angry = !joy && idleSec > 3;
  const cycle = now % 9;
  const surprise = !joy && !angry && cycle > 6.2 && cycle < 6.9;
  const smiling = !joy && !angry && !surprise && (now % 4) < 0.9;
  const gx = gaze.x * 3, gy = gaze.y * 2.5;
  const bounce = joy ? Math.abs(Math.sin((joyUntil - now) * 9)) * -14 : Math.sin(now * 3.2) * 2.5;
  const tilt = gx * 2.2;
  const tap = () => {
    const t = now + 0.9; setJoyUntil(t); setLastTouch(Date.now());
    setStars(Array.from({ length: 7 }, (_, i) => ({ id: Date.now() + i, x: 10 + Math.random() * 60, y: -4 + Math.random() * 22, c: ["#ffd23d", "#38f2c8", "#ffffff", "#ff2a85"][i % 4] })));
    setTimeout(() => setStars([]), 900);
  };
  return (
    <button id="menu-kubo" type="button" onClick={tap} aria-label="Tocca Kubo: salto di gioia" className="relative mx-auto block cursor-pointer select-none bg-transparent border-0 p-0" style={{ width: 80, height: 80, transform: `translateY(${bounce}px) rotate(${tilt}deg)`, transition: "transform 90ms linear" }}>
      {stars.map((s) => <span key={s.id} className="absolute text-[14px] leading-none" style={{ left: s.x, top: s.y }}>✦</span>)}
      <div className="absolute inset-0 bg-[#ff5400] border-2 border-black rounded-[6px]" style={{ transform: joy ? "scale(1.08,0.92)" : `scale(${1 + Math.sin(now * 3.2) * 0.015},${1 - Math.sin(now * 3.2) * 0.02})` }}>
        <span className="absolute left-0 top-0 w-full h-[8px] bg-[#ff7a2d]" />
        <span className="absolute left-0 bottom-0 w-full h-[5px] bg-[#cc3300]" />
        {/* occhi */}
        {[0, 1].map((i) => {
          const ex = i === 0 ? 14 : 44;
          return (
            <span key={i} className="absolute bg-white border border-black overflow-hidden" style={{ left: ex, top: 24, width: 18, height: blink ? 2 : 18, transition: "height 60ms" }}>
              {!blink && <span className="absolute bg-black rounded-full" style={{ width: joy ? 9 : 7, height: joy ? 9 : 7, left: 5 + gx, top: 5 + gy }} />}
              {joy && !blink && <span className="absolute bg-white rounded-full" style={{ width: 3, height: 3, left: 7 + gx, top: 6 + gy }} />}
            </span>
          );
        })}
        {/* sopracciglia */}
        <span className="absolute bg-black" style={{ left: 13, top: 18, width: 20, height: 3, transform: `rotate(${angry ? 14 : -4 + gy * 3}deg)` }} />
        <span className="absolute bg-black" style={{ left: 43, top: 18, width: 20, height: 3, transform: `rotate(${angry ? -14 : 4 - gy * 3}deg)` }} />
        {/* bocca */}
        {angry ? <span className="absolute bg-black" style={{ left: 30, top: 54, width: 20, height: 4, clipPath: "polygon(0 100%, 20% 0, 40% 100%, 60% 0, 80% 100%, 100% 0, 100% 40%, 80% 100%, 60% 40%, 40% 100%, 20% 40%, 0 100%)" }} /> : surprise ? <span className="absolute bg-black rounded-full" style={{ left: 34, top: 54, width: 12, height: 12 }} /> : joy ? <span className="absolute bg-black rounded-full" style={{ left: 28, top: 50, width: 24, height: 18 }} /> : smiling ? <span className="absolute bg-black" style={{ left: 29, top: 54, width: 22, height: 5, borderRadius: "0 0 12px 12px" }} /> : <span className="absolute bg-black" style={{ left: 33, top: 55, width: 14 + Math.sin(now * 3.2) * 3, height: 3, borderRadius: 3 }} />}
        {/* segni manga da arrabbiato: venette nere a croce con puntini, sui due lati della testa */}
        {angry && (
          <>
            <span className="manga-anger absolute" aria-hidden="true" style={{ left: -6, top: 22, width: 18, height: 18 }}>
              <span className="absolute bg-black" style={{ left: 7, top: 0, width: 4, height: 18 }} /><span className="absolute bg-black" style={{ left: 0, top: 7, width: 18, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 1, top: 1, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 13, top: 1, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 1, top: 13, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 13, top: 13, width: 4, height: 4 }} />
            </span>
            <span className="manga-anger absolute" aria-hidden="true" style={{ left: 68, top: 22, width: 18, height: 18 }}>
              <span className="absolute bg-black" style={{ left: 7, top: 0, width: 4, height: 18 }} /><span className="absolute bg-black" style={{ left: 0, top: 7, width: 18, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 1, top: 1, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 13, top: 1, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 1, top: 13, width: 4, height: 4 }} /><span className="absolute bg-black rounded-full" style={{ left: 13, top: 13, width: 4, height: 4 }} />
            </span>
          </>
        )}
      </div>
      <span className="sr-only">Kubo nel menu: occhi che seguono il cursore, bocca che respira, sorriso, sorpresa e segni manga da arrabbiato dopo 3 secondi fermo. Toccalo per un salto di gioia.</span>
    </button>
  );
}

function MenuKuboExpressions() {
  type Expr = "happy" | "angry" | "surprised" | "jump" | "fall" | "sad" | "wink" | "love" | "sleepy";
  const ALL: Expr[] = ["happy", "angry", "surprised", "jump", "fall", "sad", "wink", "love", "sleepy"];
  const LABELS: Record<Expr, string> = { happy: "FELICE!", angry: "ARRABBIATO!", surprised: "SORPRESO!", jump: "SALTO!", fall: "CADUTA!", sad: "TRISTE!", wink: "FURBO!", love: "AMORE!", sleepy: "SONNOLENTO!" };
  const [expr, setExpr] = useState<Expr>("happy");
  const [squash, setSquash] = useState(false);
  const [joyUntil, setJoyUntil] = useState(-1);
  const [now, setNow] = useState(0);
  const [gaze, setGaze] = useState({ x: 0, y: 0 });
  useEffect(() => {
    const t0 = Date.now();
    const iv = setInterval(() => setNow((Date.now() - t0) / 1000), 90);
    const move = (e: PointerEvent) => {
      const el = document.getElementById("menu-kubo-expr");
      if (!el) return;
      const r = el.getBoundingClientRect();
      setGaze({ x: Math.max(-1, Math.min(1, ((e.clientX - (r.left + r.width / 2)) / 90))), y: Math.max(-1, Math.min(1, ((e.clientY - (r.top + r.height / 2)) / 90))) });
    };
    window.addEventListener("pointermove", move);
    return () => { clearInterval(iv); window.removeEventListener("pointermove", move); };
  }, []);
  useEffect(() => {
    const iv = setInterval(() => {
      setSquash(true);
      window.setTimeout(() => {
        setExpr((prev) => { const pool = ALL.filter((x) => x !== prev); return pool[Math.floor(Math.random() * pool.length)]; });
        setSquash(false);
      }, 150);
    }, 2200);
    return () => clearInterval(iv);
  }, []);
  const joy = now < joyUntil;
  const pickTap = () => {
    const pool: Expr[] = ["surprised", "happy", "jump"];
    const next = pool[Math.floor(Math.random() * pool.length)];
    setExpr(next);
    setJoyUntil(now + 0.9);
  };
  let bodyScale = "scale(1,1)", bodyRotate = 0, bodyY = 0;
  if (squash) bodyScale = "scale(1.28,0.72)";
  else if (joy) { bodyScale = "scale(1.08,0.92)"; bodyY = -Math.abs(Math.sin((joyUntil - now) * 9)) * 14; }
  else if (expr === "surprised") bodyScale = "scale(0.92,1.18)";
  else if (expr === "jump") { bodyScale = "scale(0.84,1.26)"; bodyY = -10; }
  else if (expr === "fall") { bodyScale = "scale(1.28,0.74)"; bodyRotate = 8; }
  else if (expr === "sad") { bodyScale = "scale(0.96,0.9)"; bodyY = 5; }
  else if (expr === "angry") { bodyScale = "scale(1.08,0.92)"; bodyRotate = -2; }
  else if (expr === "love") bodyScale = "scale(1.06,0.94)";
  else if (expr === "sleepy") { bodyScale = "scale(1,0.88)"; bodyY = 4; }
  else if (expr === "wink") bodyRotate = 3;
  else bodyScale = `scale(${1 + Math.sin(now * 3.2) * 0.015},${1 - Math.sin(now * 3.2) * 0.02})`;
  const gx = gaze.x * 3, gy = gaze.y * 2.5;
  const eye = (side: 0 | 1) => {
    const left = side === 0 ? 14 : 44;
    if (expr === "happy") return <span key={side} className="absolute" style={{ left, top: 27, width: 18, height: 10, borderBottom: "4px solid #000", borderRadius: "0 0 14px 14px" }} />;
    if (expr === "angry") return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 27, width: 18, height: 11 }}><span className="absolute bg-black" style={{ width: 11, height: 4, left: 3, top: 3 }} /></span>;
    if (expr === "surprised") return <span key={side} className="absolute bg-white border-2 border-black overflow-hidden rounded-full" style={{ left: left - 1, top: 20, width: 22, height: 24 }}><span className="absolute bg-black rounded-full" style={{ width: 11, height: 11, left: 4 + gx, top: 6 + gy }} /><span className="absolute bg-white rounded-full" style={{ width: 3, height: 3, left: 7 + gx, top: 7 + gy }} /></span>;
    if (expr === "jump") return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 22, width: 18, height: 18 }}><span className="absolute bg-black rounded-full" style={{ width: 7, height: 7, left: 5 + gx, top: 1 }} /></span>;
    if (expr === "fall") return <span key={side} className="absolute text-[18px] leading-none flex items-center justify-center" style={{ left, top: 24, width: 18, height: 18 }}>🌀</span>;
    if (expr === "sad") return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 27, width: 18, height: 15 }}><span className="absolute bg-black rounded-full" style={{ width: 6, height: 6, left: 6, top: 7 }} /><span className="absolute bg-[#7dd3fc]" style={{ width: 4, height: 3, left: 7, top: 0, borderRadius: "50%" }} /></span>;
    if (expr === "wink") {
      if (side === 0) return <span key={side} className="absolute" style={{ left, top: 30, width: 18, height: 8, borderBottom: "3px solid #000", borderRadius: "0 0 12px 12px" }} />;
      return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 24, width: 18, height: 18 }}><span className="absolute bg-black rounded-full" style={{ width: 7, height: 7, left: 8, top: 5 }} /></span>;
    }
    if (expr === "love") return <span key={side} className="absolute text-[20px] leading-none text-[#ff3b6b]" style={{ left, top: 23 }}>♥</span>;
    if (expr === "sleepy") return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 30, width: 18, height: 10 }}><span className="absolute bg-black rounded-full" style={{ width: 5, height: 5, left: 6, top: 4 }} /></span>;
    return <span key={side} className="absolute bg-white border border-black overflow-hidden" style={{ left, top: 24, width: 18, height: 18 }}><span className="absolute bg-black rounded-full" style={{ width: 7, height: 7, left: 5 + gx, top: 5 + gy }} /></span>;
  };
  const mouth = () => {
    if (expr === "happy") return <span className="absolute bg-black" style={{ left: 28, top: 50, width: 24, height: 18, borderRadius: "0 0 16px 16px" }}><span className="absolute bg-[#ff6b6b]" style={{ left: 4, top: 10, width: 16, height: 6, borderRadius: "0 0 10px 10px" }} /></span>;
    if (expr === "angry") return <span className="absolute bg-black" style={{ left: 30, top: 54, width: 20, height: 5, clipPath: "polygon(0 100%, 20% 0, 40% 100%, 60% 0, 80% 100%, 100% 0, 100% 40%, 80% 100%, 60% 40%, 40% 100%, 20% 40%, 0 100%)" }} />;
    if (expr === "surprised") return <span className="absolute bg-black rounded-full" style={{ left: 32, top: 52, width: 16, height: 16 }} />;
    if (expr === "jump") return <span className="absolute bg-black rounded-full" style={{ left: 35, top: 54, width: 10, height: 11 }} />;
    if (expr === "fall") return <span className="absolute text-black font-black text-[14px] leading-none" style={{ left: 27, top: 54 }}>〰〰</span>;
    if (expr === "sad") return <span className="absolute" style={{ left: 32, top: 56, width: 16, height: 8, borderTop: "3px solid #000", borderRadius: "12px 12px 0 0" }} />;
    if (expr === "wink") return <span className="absolute"><span className="absolute bg-black" style={{ left: 29, top: 54, width: 22, height: 5, borderRadius: "0 0 12px 12px" }} /><span className="absolute bg-[#ff6b6b]" style={{ left: 40, top: 58, width: 8, height: 10, borderRadius: "0 0 6px 6px" }} /></span>;
    if (expr === "love") return <span className="absolute bg-black rounded-full" style={{ left: 35, top: 54, width: 10, height: 10 }} />;
    if (expr === "sleepy") return <span className="absolute bg-black rounded-full" style={{ left: 33, top: 53, width: 14, height: 13 }} />;
    return <span className="absolute bg-black" style={{ left: 33, top: 55, width: 14, height: 3, borderRadius: 3 }} />;
  };
  const brows = () => {
    if (expr === "angry") return <><span className="absolute bg-black" style={{ left: 12, top: 19, width: 21, height: 5, transform: "rotate(18deg)" }} /><span className="absolute bg-black" style={{ left: 43, top: 19, width: 21, height: 5, transform: "rotate(-18deg)" }} /></>;
    if (expr === "sad") return <><span className="absolute bg-black" style={{ left: 12, top: 19, width: 20, height: 3, transform: "rotate(-16deg)" }} /><span className="absolute bg-black" style={{ left: 44, top: 19, width: 20, height: 3, transform: "rotate(16deg)" }} /></>;
    if (expr === "surprised") return <><span className="absolute bg-black" style={{ left: 12, top: 12, width: 20, height: 3, transform: "rotate(-8deg)" }} /><span className="absolute bg-black" style={{ left: 44, top: 12, width: 20, height: 3, transform: "rotate(8deg)" }} /></>;
    if (expr === "wink") return <><span className="absolute bg-black" style={{ left: 12, top: 20, width: 20, height: 3, transform: "rotate(-6deg)" }} /><span className="absolute bg-black" style={{ left: 44, top: 13, width: 20, height: 3, transform: "rotate(-10deg)" }} /></>;
    if (expr === "sleepy") return <><span className="absolute bg-black" style={{ left: 12, top: 23, width: 20, height: 2, transform: "rotate(4deg)", opacity: 0.7 }} /><span className="absolute bg-black" style={{ left: 44, top: 23, width: 20, height: 2, transform: "rotate(-4deg)", opacity: 0.7 }} /></>;
    if (expr === "fall") return <><span className="absolute bg-black" style={{ left: 12, top: 18, width: 20, height: 3, transform: "rotate(10deg)" }} /><span className="absolute bg-black" style={{ left: 44, top: 18, width: 20, height: 3, transform: "rotate(-10deg)" }} /></>;
    return <><span className="absolute bg-black" style={{ left: 13, top: 18, width: 20, height: 3, transform: `rotate(${-4 + gy * 3}deg)` }} /><span className="absolute bg-black" style={{ left: 43, top: 18, width: 20, height: 3, transform: `rotate(${4 - gy * 3}deg)` }} /></>;
  };
  return (
    <div className="flex flex-col items-center">
      <button id="menu-kubo-expr" type="button" onClick={pickTap} aria-label={`Kubo nel menu: ${LABELS[expr]} Toccalo per un'espressione a sorpresa`} className="relative block cursor-pointer select-none bg-transparent border-0 p-0" style={{ width: 96, height: 96, transform: `translateY(${bodyY}px) rotate(${bodyRotate}deg)`, transition: "transform 150ms ease" }}>
        {expr === "happy" && <><span className="absolute text-[16px] leading-none" style={{ left: -6, top: 2 }}>✦</span><span className="absolute text-[13px] leading-none" style={{ right: -4, top: 14 }}>✦</span><span className="absolute text-[12px] leading-none" style={{ left: 2, top: -4 }}>★</span></>}
        {expr === "surprised" && <><span className="absolute text-[18px] leading-none font-black" style={{ left: -8, top: 6 }}>!</span><span className="absolute text-[18px] leading-none font-black" style={{ right: -8, top: 6 }}>!</span></>}
        {expr === "fall" && <><span className="absolute text-[14px] leading-none" style={{ left: -10, top: 10 }}>✦</span><span className="absolute text-[14px] leading-none" style={{ right: -10, top: 30 }}>✦</span><span className="absolute text-[12px] leading-none" style={{ left: 88, top: 4 }}>★</span></>}
        {expr === "love" && <><span className="absolute text-[16px] leading-none text-[#ff3b6b]" style={{ left: -8, top: 0 }}>♥</span><span className="absolute text-[13px] leading-none text-[#ff3b6b]" style={{ right: -6, top: 8 }}>♥</span><span className="absolute text-[11px] leading-none text-[#ff8fab]" style={{ left: 90, top: 34 }}>♥</span></>}
        {expr === "sleepy" && <span className="absolute text-[16px] leading-none font-black text-[#5a6a80]" style={{ right: -2, top: -8 }}>Z</span>}
        {expr === "wink" && <span className="absolute text-[14px] leading-none" style={{ right: -8, top: 2 }}>✦</span>}
        {expr === "jump" && <><span className="absolute bg-[#00e5ff]" style={{ left: 22, top: 98, width: 14, height: 3, borderRadius: 3 }} /><span className="absolute bg-[#00e5ff]" style={{ left: 46, top: 102, width: 14, height: 3, borderRadius: 3 }} /><span className="absolute text-[14px] leading-none" style={{ left: 2, top: 20 }}>↑</span><span className="absolute text-[14px] leading-none" style={{ right: 2, top: 20 }}>↑</span></>}
        {expr === "angry" && <><span className="manga-anger absolute z-20" style={{ right: -14, top: -16, fontSize: 32, lineHeight: 1 }}>💢</span><span className="absolute text-[16px] leading-none" style={{ left: -12, top: 22 }}>💨</span><span className="absolute text-[16px] leading-none" style={{ right: -12, top: 34 }}>💨</span></>}
        <div className="absolute inset-0 bg-[#ff5400] border-2 border-black rounded-[6px] overflow-visible" style={{ transform: bodyScale, transition: "transform 150ms ease" }}>
          <span className="absolute left-0 top-0 w-full h-[8px] bg-[#ff7a2d]" />
          <span className="absolute left-0 bottom-0 w-full h-[5px] bg-[#cc3300]" />
          {brows()}
          {eye(0)}{eye(1)}
          {mouth()}
          {(expr === "happy" || expr === "love") && <><span className="absolute bg-[#ffb3c1] rounded-full" style={{ left: 4, top: 44, width: 10, height: 8, opacity: 0.9 }} /><span className="absolute bg-[#ffb3c1] rounded-full" style={{ right: 4, top: 44, width: 10, height: 8, opacity: 0.9 }} /></>}
          {expr === "angry" && <><span className="absolute bg-[#ff3b6b] rounded-full" style={{ left: 3, top: 42, width: 12, height: 10 }} /><span className="absolute bg-[#ff3b6b] rounded-full" style={{ right: 3, top: 42, width: 12, height: 10 }} /></>}
          {expr === "sad" && <span className="absolute bg-[#38bdf8] rounded-full" style={{ left: 18, top: 42, width: 6, height: 10 }} />}
          {expr === "jump" && <><span className="absolute bg-white" style={{ left: 36, top: -10, width: 3, height: 10, borderRadius: 2 }} /><span className="absolute bg-white" style={{ left: 44, top: -12, width: 3, height: 12, borderRadius: 2 }} /></>}
          {expr === "sleepy" && <span className="absolute text-[11px] leading-none text-[#5a6a80] font-black" style={{ right: 4, top: 4 }}>z</span>}
        </div>
      </button>
      <span className="sr-only">Kubo nel menu cambia espressione ogni 2,2 secondi: felice, arrabbiato, sorpreso, salto, caduta, triste, furbo, amore e sonnolento. Toccalo per un salto di gioia.</span>
    </div>
  );
}

function MenuRisingBricks() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let w = 0;
    let h = 0;
    const dpr = Math.min(1, window.devicePixelRatio || 1);
    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);
    type Brick = { x: number; y: number; w: number; speed: number; hue: number; crystal: number; alpha: number };
    type Spark = { x: number; y: number; speed: number; size: number; alpha: number };
    let seed = 1234567;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    const makeBrick = (fromBottom: boolean): Brick => ({
      x: 8 + rand() * Math.max(40, w - 110),
      y: fromBottom ? h + rand() * 140 : rand() * h,
      w: 42 + rand() * 78,
      speed: 11 + rand() * 17,
      hue: rand(),
      crystal: Math.floor(rand() * 3),
      alpha: 0.30 + rand() * 0.22,
    });
    const bricks: Brick[] = Array.from({ length: 26 }, () => makeBrick(false));
    const sparks: Spark[] = Array.from({ length: 30 }, () => ({
      x: rand() * Math.max(1, w),
      y: rand() * h,
      speed: 8 + rand() * 16,
      size: 1 + rand() * 2,
      alpha: 0.2 + rand() * 0.4,
    }));
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      ctx.clearRect(0, 0, w, h);
      for (const b of bricks) {
        b.y -= b.speed * dt;
        if (b.y < -28) Object.assign(b, makeBrick(true));
        const colors = b.hue < 0.45
          ? { base: "#241239", edge: "#a855f7", glow: "#c084fc" }
          : b.hue < 0.75
            ? { base: "#0a1a3a", edge: "#22d3ee", glow: "#7dd3fc" }
            : { base: "#0a2438", edge: "#38f2c8", glow: "#a7f3d0" };
        ctx.globalAlpha = b.alpha;
        ctx.fillStyle = "rgba(0,0,0,0.35)";
        ctx.fillRect(b.x + 2, b.y + 10, b.w, 3);
        ctx.fillStyle = colors.base;
        ctx.fillRect(b.x, b.y, b.w, 10);
        ctx.fillStyle = colors.edge;
        ctx.fillRect(b.x, b.y, b.w, 2);
        ctx.fillStyle = colors.glow;
        ctx.fillRect(b.x + b.w * 0.25, b.y + 4, 6, 2);
        ctx.fillRect(b.x + b.w * 0.62, b.y + 4, 6, 2);
        ctx.fillStyle = colors.edge;
        const cx = b.x + 10 + b.crystal * (b.w / 3);
        ctx.beginPath();
        ctx.moveTo(cx, b.y);
        ctx.lineTo(cx + 4, b.y - 6);
        ctx.lineTo(cx + 8, b.y);
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      for (const sp of sparks) {
        sp.y -= sp.speed * dt;
        if (sp.y < -6) { sp.y = h + 6; sp.x = rand() * Math.max(1, w); }
        ctx.globalAlpha = sp.alpha * (0.65 + 0.35 * Math.sin(now / 320 + sp.x));
        ctx.fillStyle = "#e0f2fe";
        ctx.fillRect(sp.x, sp.y, sp.size, sp.size);
      }
      ctx.globalAlpha = 1;
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden" style={{ background: "linear-gradient(180deg,#070313 0%,#0a0620 55%,#05070c 100%)" }}>
      <canvas ref={canvasRef} className="block h-full w-full" />
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(3,2,10,0.66) 0%, rgba(3,2,10,0.58) 55%, rgba(3,2,10,0.72) 100%)" }} />
    </div>
  );
}

function WorldScenery({ id }: { id: number }) {
  const d = "absolute";
  switch (id) {
    case 1: return (<><span className={d} style={{ left: "8%", bottom: "18%", width: "22%", height: "34%", background: "#a855f7", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "30%", bottom: "14%", width: "18%", height: "24%", background: "#22d3ee", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "58%", bottom: "20%", width: "26%", height: "38%", background: "#c084fc", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "18%", top: "14%", width: "10%", height: "10%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "72%", top: "22%", width: "7%", height: "7%", background: "#ffd23d", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "18%", background: "#1a0b2e" }} /></>);
    case 2: return (<><span className={d} style={{ left: "12%", bottom: "22%", width: "30%", height: "42%", background: "#1a0a0a", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "22%", bottom: "34%", width: "10%", height: "26%", background: "#ff5400" }} /><span className={d} style={{ left: "62%", bottom: "18%", width: "24%", height: "30%", background: "#2a0a0a", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "20%", background: "#ff5400" }} /><span className={d} style={{ left: "12%", bottom: "6%", width: "18%", height: "8%", background: "#ffd23d", borderRadius: "50%" }} /><span className={d} style={{ left: "70%", bottom: "10%", width: "12%", height: "6%", background: "#ffd23d", borderRadius: "50%" }} /></>);
    case 3: return (<><span className={d} style={{ left: "6%", bottom: "18%", width: "8%", height: "42%", background: "#14532d" }} /><span className={d} style={{ left: "0", bottom: "48%", width: "20%", height: "20%", background: "#22c55e", borderRadius: "50%" }} /><span className={d} style={{ left: "68%", bottom: "18%", width: "8%", height: "38%", background: "#14532d" }} /><span className={d} style={{ left: "62%", bottom: "44%", width: "20%", height: "20%", background: "#4ade80", borderRadius: "50%" }} /><span className={d} style={{ left: "38%", bottom: "8%", width: "24%", height: "18%", background: "#f87171", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "44%", bottom: "0", width: "10%", height: "12%", background: "#fef3c7" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "12%", background: "#0a2a12" }} /></>);
    case 4: return (<><span className={d} style={{ left: "8%", top: "6%", width: "14%", height: "30%", background: "#bae6fd", clipPath: "polygon(0 0, 100% 0, 50% 100%)" }} /><span className={d} style={{ left: "72%", top: "8%", width: "16%", height: "26%", background: "#e0f2fe", clipPath: "polygon(0 0, 100% 0, 50% 100%)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "22%", background: "#ffffff" }} /><span className={d} style={{ left: "18%", top: "34%", width: "8%", height: "8%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "58%", top: "26%", width: "10%", height: "10%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "38%", bottom: "16%", width: "22%", height: "18%", background: "#7dd3fc", borderRadius: "50%" }} /></>);
    case 5: return (<><span className={d} style={{ right: "10%", top: "10%", width: "22%", height: "22%", background: "#ffd23d", borderRadius: "50%", boxShadow: "0 0 18px #ffd23d" }} /><span className={d} style={{ left: "8%", bottom: "18%", width: "8%", height: "36%", background: "#22c55e", borderRadius: "8px" }} /><span className={d} style={{ left: "4%", bottom: "38%", width: "16%", height: "6%", background: "#22c55e", borderRadius: "6px" }} /><span className={d} style={{ left: "76%", bottom: "20%", width: "14%", height: "30%", background: "#a16207", clipPath: "polygon(20% 100%, 80% 100%, 100% 0, 0 0)" }} /><span className={d} style={{ left: "0", bottom: "8%", width: "100%", height: "22%", background: "#eab308", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "14%", background: "#ca8a04" }} /></>);
    case 6: return (<><span className={d} style={{ left: "6%", bottom: "12%", width: "20%", height: "52%", background: "#1a0a2e" }} /><span className={d} style={{ left: "30%", bottom: "12%", width: "18%", height: "66%", background: "#0a051a" }} /><span className={d} style={{ left: "56%", bottom: "12%", width: "22%", height: "44%", background: "#1a0a2e" }} /><span className={d} style={{ left: "10%", bottom: "52%", width: "10%", height: "5%", background: "#ff2a85" }} /><span className={d} style={{ left: "34%", bottom: "60%", width: "10%", height: "5%", background: "#22d3ee" }} /><span className={d} style={{ left: "60%", bottom: "42%", width: "12%", height: "5%", background: "#facc15" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "12%", background: "#05070c" }} /></>);
    case 7: return (<><span className={d} style={{ left: "18%", bottom: "18%", width: "36%", height: "48%", background: "#1a0a0a", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "32%", bottom: "42%", width: "8%", height: "24%", background: "#ff6b35" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "20%", background: "#ff5400" }} /><span className={d} style={{ left: "68%", bottom: "30%", width: "18%", height: "18%", background: "#78716c", borderRadius: "50%" }} /><span className={d} style={{ left: "8%", top: "16%", width: "10%", height: "6%", background: "#9ca3af", borderRadius: "50%" }} /><span className={d} style={{ left: "70%", top: "10%", width: "14%", height: "7%", background: "#9ca3af", borderRadius: "50%" }} /></>);
    case 8: return (<><span className={d} style={{ left: "10%", bottom: "10%", width: "26%", height: "26%", background: "#f472b6", borderRadius: "50%" }} /><span className={d} style={{ left: "62%", bottom: "14%", width: "22%", height: "22%", background: "#fb923c", borderRadius: "50%" }} /><span className={d} style={{ left: "34%", bottom: "42%", width: "18%", height: "8%", background: "#ff7ad9", borderRadius: "50%" }} /><span className={d} style={{ left: "18%", top: "18%", width: "8%", height: "8%", background: "rgba(255,255,255,.85)", borderRadius: "50%" }} /><span className={d} style={{ left: "72%", top: "30%", width: "6%", height: "6%", background: "rgba(255,255,255,.8)", borderRadius: "50%" }} /><span className={d} style={{ left: "44%", top: "12%", width: "5%", height: "5%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "10%", background: "#021a2e" }} /></>);
    case 9: return (<><span className={d} style={{ left: "14%", top: "16%", width: "26%", height: "26%", background: "#a855f7", borderRadius: "50%" }} /><span className={d} style={{ left: "10%", top: "28%", width: "34%", height: "5%", background: "#f472b6", borderRadius: "50%" }} /><span className={d} style={{ left: "64%", top: "48%", width: "18%", height: "18%", background: "#22d3ee", borderRadius: "50%" }} /><span className={d} style={{ left: "22%", top: "58%", width: "4%", height: "4%", background: "#fff" }} /><span className={d} style={{ left: "78%", top: "18%", width: "5%", height: "5%", background: "#fff" }} /><span className={d} style={{ left: "48%", top: "8%", width: "4%", height: "4%", background: "#ffd23d" }} /><span className={d} style={{ left: "8%", top: "72%", width: "4%", height: "4%", background: "#fff" }} /></>);
    case 10: return (<><span className={d} style={{ left: "4%", top: "4%", width: "8%", height: "52%", background: "#14532d", borderRadius: "8px" }} /><span className={d} style={{ left: "84%", top: "8%", width: "8%", height: "48%", background: "#14532d", borderRadius: "8px" }} /><span className={d} style={{ left: "20%", bottom: "12%", width: "18%", height: "34%", background: "#22c55e", borderRadius: "50%" }} /><span className={d} style={{ left: "58%", bottom: "16%", width: "22%", height: "28%", background: "#a3e635", borderRadius: "50%" }} /><span className={d} style={{ left: "28%", top: "20%", width: "6%", height: "6%", background: "#fef08a", borderRadius: "50%" }} /><span className={d} style={{ left: "68%", top: "32%", width: "6%", height: "6%", background: "#fef08a", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "12%", background: "#0a2a0a" }} /></>);
    case 11: return (<><span className={d} style={{ left: "10%", bottom: "16%", width: "12%", height: "52%", background: "#facc15" }} /><span className={d} style={{ left: "6%", bottom: "64%", width: "20%", height: "6%", background: "#facc15" }} /><span className={d} style={{ left: "74%", bottom: "16%", width: "12%", height: "52%", background: "#facc15" }} /><span className={d} style={{ left: "70%", bottom: "64%", width: "20%", height: "6%", background: "#facc15" }} /><span className={d} style={{ left: "40%", bottom: "22%", width: "20%", height: "30%", background: "#f59e0b", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "16%", background: "#2a1a0a" }} /></>);
    case 12: return (<><span className={d} style={{ left: "8%", top: "22%", width: "30%", height: "22%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "58%", top: "14%", width: "32%", height: "22%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "28%", top: "52%", width: "34%", height: "22%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "10%", top: "58%", width: "80%", height: "7%", background: "linear-gradient(90deg,#ff3b6b,#ffd23d,#4ade80,#22d3ee,#a855f7)", borderRadius: "8px" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "10%", background: "#1a3a5a" }} /></>);
    case 13: return (<><span className={d} style={{ left: "12%", bottom: "10%", width: "22%", height: "40%", background: "#1a2a1a" }} /><span className={d} style={{ left: "66%", bottom: "12%", width: "20%", height: "34%", background: "#1a2a1a" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "18%", background: "#84cc16" }} /><span className={d} style={{ left: "22%", top: "18%", width: "9%", height: "9%", background: "#a3e635", borderRadius: "50%" }} /><span className={d} style={{ left: "62%", top: "30%", width: "7%", height: "7%", background: "#a3e635", borderRadius: "50%" }} /><span className={d} style={{ left: "44%", top: "12%", width: "6%", height: "6%", background: "#22d3ee", borderRadius: "50%" }} /></>);
    case 14: return (<><span className={d} style={{ left: "0", bottom: "14%", width: "100%", height: "7%", background: "#78716c" }} /><span className={d} style={{ left: "12%", bottom: "21%", width: "26%", height: "18%", background: "#f59e0b", borderRadius: "6px" }} /><span className={d} style={{ left: "18%", bottom: "38%", width: "4%", height: "4%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "66%", bottom: "30%", width: "10%", height: "28%", background: "#78350f" }} /><span className={d} style={{ left: "60%", bottom: "52%", width: "22%", height: "8%", background: "#fcd34d", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "14%", background: "#241505" }} /></>);
    case 15: return (<><span className={d} style={{ left: "8%", bottom: "16%", width: "22%", height: "52%", background: "#150a2a" }} /><span className={d} style={{ left: "4%", bottom: "64%", width: "30%", height: "8%", background: "#8b5cf6", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "70%", bottom: "16%", width: "22%", height: "48%", background: "#150a2a" }} /><span className={d} style={{ left: "72%", top: "14%", width: "16%", height: "16%", background: "#fef3c7", borderRadius: "50%" }} /><span className={d} style={{ left: "42%", bottom: "12%", width: "14%", height: "20%", background: "#ff2a85", clipPath: "polygon(0 100%, 25% 0, 50% 100%, 75% 0, 100% 100%)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "14%", background: "#0a0518" }} /></>);
    case 16: return (<><span className={d} style={{ left: "14%", bottom: "16%", width: "30%", height: "22%", background: "#f87171", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "22%", bottom: "4%", width: "12%", height: "16%", background: "#fef3c7" }} /><span className={d} style={{ left: "58%", bottom: "20%", width: "24%", height: "18%", background: "#f87171", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "64%", bottom: "8%", width: "10%", height: "14%", background: "#fef3c7" }} /><span className={d} style={{ left: "20%", top: "26%", width: "6%", height: "6%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "68%", top: "22%", width: "6%", height: "6%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "10%", background: "#2a0a10" }} /></>);
    case 17: return (<><span className={d} style={{ left: "10%", bottom: "14%", width: "18%", height: "40%", background: "#ef4444", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "40%", bottom: "16%", width: "22%", height: "48%", background: "#f97316", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "68%", bottom: "14%", width: "18%", height: "36%", background: "#ef4444", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "16%", background: "#7f1d1d" }} /><span className={d} style={{ left: "30%", top: "14%", width: "10%", height: "10%", background: "#78716c", borderRadius: "50%" }} /><span className={d} style={{ left: "66%", top: "22%", width: "8%", height: "8%", background: "#78716c", borderRadius: "50%" }} /></>);
    case 18: return (<><span className={d} style={{ left: "0", top: "10%", width: "100%", height: "12%", background: "#34d399", borderRadius: "50%", opacity: 0.85, transform: "rotate(-8deg)" }} /><span className={d} style={{ left: "0", top: "28%", width: "100%", height: "10%", background: "#7dd3fc", borderRadius: "50%", opacity: 0.7, transform: "rotate(6deg)" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "22%", background: "#fff" }} /><span className={d} style={{ left: "18%", top: "52%", width: "8%", height: "8%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "62%", top: "46%", width: "9%", height: "9%", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "40%", bottom: "18%", width: "20%", height: "16%", background: "#bae6fd", clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} /></>);
    case 19: return (<><span className={d} style={{ left: "8%", bottom: "16%", width: "20%", height: "46%", background: "#0a1420", border: "2px solid #22d3ee" }} /><span className={d} style={{ left: "64%", bottom: "16%", width: "22%", height: "38%", background: "#0a1420", border: "2px solid #22d3ee" }} /><span className={d} style={{ left: "14%", bottom: "46%", width: "8%", height: "8%", background: "#facc15", borderRadius: "50%" }} /><span className={d} style={{ left: "70%", bottom: "38%", width: "8%", height: "8%", background: "#ff2a85", borderRadius: "50%" }} /><span className={d} style={{ left: "38%", bottom: "42%", width: "22%", height: "4%", background: "#22d3ee" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "14%", background: "#050a12" }} /></>);
    case 20: return (<><span className={d} style={{ left: "50%", top: "50%", width: "46%", height: "46%", transform: "translate(-50%,-50%)", border: "6px solid #ff2d55", borderRadius: "50%" }} /><span className={d} style={{ left: "50%", top: "50%", width: "26%", height: "26%", transform: "translate(-50%,-50%) rotate(45deg)", border: "4px dashed #a855f7", borderRadius: "50%" }} /><span className={d} style={{ left: "50%", top: "50%", width: "10%", height: "10%", transform: "translate(-50%,-50%)", background: "#fff", borderRadius: "50%" }} /><span className={d} style={{ left: "16%", top: "18%", width: "6%", height: "6%", background: "#ffd23d", borderRadius: "50%" }} /><span className={d} style={{ left: "76%", top: "68%", width: "6%", height: "6%", background: "#00e5ff", borderRadius: "50%" }} /></>);
    case 21: return (<><span className={d} style={{ left: "8%", bottom: "22%", width: "28%", height: "28%", background: "#b87333", borderRadius: "50%" }} /><span className={d} style={{ left: "16%", bottom: "30%", width: "12%", height: "12%", background: "#1a0f08", borderRadius: "50%" }} /><span className={d} style={{ left: "62%", bottom: "26%", width: "24%", height: "24%", background: "#d4a017", borderRadius: "50%" }} /><span className={d} style={{ left: "68%", bottom: "32%", width: "10%", height: "10%", background: "#1a0f08", borderRadius: "50%" }} /><span className={d} style={{ left: "30%", top: "14%", width: "10%", height: "14%", background: "rgba(255,255,255,.8)", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "18%", background: "#1a0f08" }} /></>);
    default: return (<><span className={d} style={{ left: "6%", top: "6%", width: "8%", height: "46%", background: "#5a2a8a", borderRadius: "8px" }} /><span className={d} style={{ left: "82%", top: "10%", width: "8%", height: "42%", background: "#5a2a8a", borderRadius: "8px" }} /><span className={d} style={{ left: "16%", bottom: "16%", width: "26%", height: "18%", background: "#00ffff", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "58%", bottom: "20%", width: "22%", height: "16%", background: "#00ff88", borderRadius: "50% 50% 0 0" }} /><span className={d} style={{ left: "26%", top: "18%", width: "7%", height: "7%", background: "#a3ff00", borderRadius: "50%" }} /><span className={d} style={{ left: "70%", top: "30%", width: "7%", height: "7%", background: "#a3ff00", borderRadius: "50%" }} /><span className={d} style={{ left: "0", bottom: "0", width: "100%", height: "12%", background: "#0a1a2e" }} /></>);
  }
}
function WorldCircle({ lv, diameter, isCenter, isLocked }: { lv: LevelConfig; diameter: number; isCenter: boolean; isLocked: boolean }) {
  const label = lv.id >= 21 ? (lv.id === 21 ? "TEMPESTA STEAMPUNK" : "FORESTA BIOLUMINESCENTE") : lv.short.toUpperCase();
  // Con UNLOCK_ALL = true il blocco è in pausa: nessun lucchetto, nessun overlay grigio.
  const showLocked = isLocked && !UNLOCK_ALL;
  const iconSize = Math.round(diameter * (isCenter ? 0.34 : 0.36));
  return (
    <div className="relative shrink-0 overflow-hidden rounded-full" style={{ width: diameter, height: diameter, background: showLocked ? "#1a2436" : `linear-gradient(180deg, ${lv.bg} 0%, ${lv.sky} 55%, ${lv.floor} 100%)`, border: `4px solid ${showLocked ? "#33415e" : lv.edge}`, boxShadow: isCenter && !showLocked ? `0 0 0 4px rgba(255,255,255,.18), 0 0 34px ${lv.edge}88, 0 16px 30px rgba(0,0,0,.55)` : "0 10px 22px rgba(0,0,0,.45)", opacity: showLocked ? 0.92 : isCenter ? 1 : 0.78, transition: "width .3s, height .3s, opacity .3s" }}>
      {!showLocked && <WorldScenery id={lv.id} />}
      {showLocked ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-[#0d1321]/60">
          <PixelWorldIcon kind="lock" size={diameter > 200 ? 56 : 30} glow="#facc15" />
          {isCenter && <span className="font-display text-white text-[13px] tracking-wide" style={{ textShadow: "0 2px 0 #000" }}>BLOCCATO</span>}
        </div>
      ) : (
        <>
          <span className="absolute left-1/2 -translate-x-1/2 top-[7%] flex items-center justify-center" style={{ width: iconSize, height: iconSize }} aria-hidden="true"><PixelWorldIcon kind={lv.icon} size={iconSize} glow={lv.edge} /></span>
          <div className="absolute left-0 right-0 bottom-0 px-2 text-center" style={{ paddingBottom: diameter * 0.07, background: "linear-gradient(180deg, transparent, rgba(0,0,0,.62) 55%)" }}>
            <div className="font-display text-white leading-none" style={{ fontSize: isCenter ? 20 : 11, textShadow: "0 2px 0 #000, 0 0 12px rgba(0,0,0,.8)" }}>{label}</div>
            {isCenter && <div className="text-white font-bold tracking-widest mt-1" style={{ fontSize: 11, textShadow: "0 2px 0 #000" }}>{lv.id >= 21 ? `BONUS ${lv.id - 20}` : `LIVELLO ${lv.id}`}</div>}
          </div>
          {isCenter && <span className="absolute left-1/2 -translate-x-1/2 flex gap-1" style={{ bottom: diameter * 0.01 }} aria-hidden="true"><span className="inline-block w-1.5 h-1.5 rotate-45 bg-white/80" /><span className="inline-block w-1.5 h-1.5 rotate-45 bg-white/80" /><span className="inline-block w-1.5 h-1.5 rotate-45 bg-white/80" /></span>}
        </>
      )}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const shellStyle = { boxSizing: "border-box" as const, paddingTop: "var(--safe-area-inset-top)" };
  const [phase, setPhase] = useState<"menu" | "playing" | "over" | "paused">("menu");
  const phaseRef = useRef(phase); phaseRef.current = phase;
  const [selectedLevel, setSelectedLevel] = useState(1);
  const selectedRef = useRef(1);
  const [bestByLevel, setBestByLevel] = useState<Record<number, number>>({});
  const bestRef = useRef<Record<number, number>>({});
  const [unlocked, setUnlocked] = useState<number[]>(UNLOCK_ALL ? [...ALL_LEVEL_IDS] : [1]);
  const unlockedRef = useRef<number[]>(UNLOCK_ALL ? [...ALL_LEVEL_IDS] : [1]);
  const [completed, setCompleted] = useState<number[]>([]);
  const completedRef = useRef<number[]>([]);
  const [progressId, setProgressId] = useState<string | null>(null);
  const progressIdRef = useRef<string | null>(null);
  const [muted, setMuted] = useState(false);
  const mutedRef = useRef(false);
  const [hud, setHud] = useState({ m: 0, hp: 3, best: 0, points: 0, level: 1, levelLabel: "GROTTA DEI CRISTALLI", floorDist: 999, straight: 0, windOn: false, windDir: 1, tongueWarn: false, grapple: 1, grappleReady: true, goal: 80 });
  const [grappleFlash, setGrappleFlash] = useState(false);
  const mouseRef = useRef<{ x: number; y: number; t: number } | null>(null);
  const aimKeysRef = useRef({ up: false, down: false, left: false, right: false });
  const [saveNote, setSaveNote] = useState("");
  const [showHelp, setShowHelp] = useState(false);
  const [levelBanner, setLevelBanner] = useState("");
  const [deathCause, setDeathCause] = useState<"floor" | "fall" | "hp" | "">("");
  const [isLegend, setIsLegend] = useState(false);
  const [isWin, setIsWin] = useState(false);
  const [winStars, setWinStars] = useState(3);
  const [resumeCount, setResumeCount] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [cssFullscreen, setCssFullscreen] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [shakeLevel, setShakeLevel] = useState<number | null>(null);
  const [lockedMsg, setLockedMsg] = useState("");
  const currentLevelId = (() => { const firstOpen = LEVELS.find((lv) => unlocked.includes(lv.id) && !completed.includes(lv.id)); return firstOpen ? firstOpen.id : Math.max(...unlocked); })();
  const scrollCarouselTo = (idx: number, smooth = true) => { const el = carouselRef.current; if (!el) return; el.scrollTo({ left: idx * 288, behavior: smooth ? "smooth" : "auto" }); };
  const handleLockedLevel = (lvId: number) => { setShakeLevel(lvId); setLockedMsg(`Completa il livello ${lvId - 1} per sbloccare`); window.setTimeout(() => setShakeLevel(null), 420); };
  const shellRef = useRef<HTMLDivElement>(null);

  const g = useRef({
    px: 135, py: START_Y - 16, vx: 0, vy: 0, stepT: 0,
    grounded: true, coyote: 0, jumpBuf: 0, dropT: 0,
    grappleCd: 0, grappleT: 0, grappleFromX: 135, grappleFromY: 0,
    grapplePhase: "idle" as "idle" | "aim" | "fly" | "pull" | "hang" | "retract", grappleTargetX: 18, grappleTargetY: 0, grappleHookX: 135, grappleHookY: 0, grappleDir: 1 as 1 | -1, grappleRopeLen: 12, grapplePlateFlash: 0, anchorFlash: 0,
    grappleAimT: 0, grappleAimDir: 1 as 1 | -1, grappleAimTargetX: 18, grappleAimTargetY: 0, grappleAimHas: false, grappleMiss: false,
    grappleAimAngle: -Math.PI / 3, grappleAngle: -Math.PI / 3, landSquash: 0, deathT: 0, deathDone: false, lastDir: 1 as 1 | -1,
    cameraY: 0, minFeet: START_Y, platforms: [] as Platform[],
    enemies: [] as Enemy[], telegraphs: [] as Telegraph[], particles: [] as Particle[],
    ghosts: [] as Ghost[], shocks: [] as Shock[],
    flashT: 0, shakeT: 0, alarmT: 0,
    hp: 3, invuln: 0, points: 0, floorY: START_Y + 200, floorWait: 4, time: 0, spawnT: 2, dead: false, lastKill: 0,
    idleT: 0, level: 1, lastMilestone: 0, bannerT: 0, deathCause: "" as "" | "floor" | "fall" | "hp",
    windT: 0, windDir: 1, windNext: 16, tongueNext: 11, tongueWarn: 0,
    straight: 0, lastJumpX: 135, won: false, winT: 0, groundKind: "normal" as PlatformKind, groundConveyor: 0 as number, groundPlat: null as Platform | null,
    portalX: 135, portalY: START_Y - 80 * 12 - 65, portalActive: false, portalEntered: false, portalT: 0, portalExploded: false, finalY: START_Y - 80 * 12, finalInserted: false, checkpointTaken: false, portalEmitAcc: 0, portalRingT: 0, barrierFlash: 0, barrierHintShown: false,
    hitT: 0, tiredT: 0, landFaceT: 0, jumpFaceT: 0, hookFaceT: 0, surpriseT: 0, winkT: 0, happyT: 0,
  });
  const input = useRef({ left: false, right: false, jumpQueued: false });
  const joy = useRef({ active: false, dx: 0, dy: 0 });
  const [joyPos, setJoyPos] = useState({ x: 0, y: 0 });
  const audioRef = useRef<AudioContext | null>(null);
  const voiceIdRef = useRef(0);
  const voicesRef = useRef(new Map<string, OscillatorNode>());

  const sfx = useCallback((kind: "jump" | "grapple" | "hit" | "boom" | "tink" | "land" | "level" | "milestone" | "alarm" | "floor" | "wind" | "zip" | "clack" | "boing" | "laser" | "whoosh" | "ding" | "bzz" | "step" | "superjump" | "thud" | "pew" | "detach" | "ui" | "ready" | "death" | "fanfare" | "portal" | "heartbreak") => {
    try {
      if (mutedRef.current) return;
      if (!audioRef.current) audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioRef.current; if (ctx.state === "suspended") ctx.resume();
      const now = ctx.currentTime;
      const mk = (type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0) => {
        const o = ctx.createOscillator(), gn = ctx.createGain();
        o.connect(gn); gn.connect(ctx.destination); o.type = type;
        o.frequency.setValueAtTime(f0, now + delay); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), now + delay + dur);
        gn.gain.setValueAtTime(vol, now + delay); gn.gain.exponentialRampToValueAtTime(0.001, now + delay + dur);
        const vid = `v${++voiceIdRef.current}`; voicesRef.current.set(vid, o);
        o.onended = () => { if (voicesRef.current.get(vid) === o) voicesRef.current.delete(vid); };
        o.start(now + delay); o.stop(now + delay + dur + 0.02);
      };
      const noiseBurst = (dur: number, vol: number, delay = 0, freq = 1200, type: BiquadFilterType = "highpass") => {
        try {
          const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
          const buf = ctx.createBuffer(1, len, ctx.sampleRate);
          const ch = buf.getChannelData(0);
          for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / len);
          const src = ctx.createBufferSource(); src.buffer = buf;
          const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
          const gn = ctx.createGain(); gn.gain.setValueAtTime(vol, now + delay); gn.gain.exponentialRampToValueAtTime(0.001, now + delay + dur);
          src.connect(f); f.connect(gn); gn.connect(ctx.destination);
          src.start(now + delay); src.stop(now + delay + dur + 0.02);
        } catch { /* silenzio */ }
      };
      if (kind === "step") { mk("triangle", 220, 140, 0.04, 0.035); }
      else if (kind === "superjump") { mk("square", 300, 900, 0.18, 0.16); mk("square", 450, 1200, 0.14, 0.08, 0.03); }
      else if (kind === "thud" || kind === "land") { mk("sine", 120, 55, 0.08, 0.18); noiseBurst(0.05, 0.05, 0, 300, "lowpass"); }
      else if (kind === "pew" || kind === "zip") { mk("sawtooth", 800, 200, 0.15, 0.14); }
      else if (kind === "detach") { mk("square", 1200, 800, 0.03, 0.12); mk("square", 900, 600, 0.04, 0.10, 0.05); }
      else if (kind === "ui") { mk("square", 880, 880, 0.05, 0.07); }
      else if (kind === "ready") { mk("square", 660, 660, 0.08, 0.10); mk("square", 660, 660, 0.08, 0.10, 0.15); mk("square", 660, 660, 0.08, 0.10, 0.30); mk("square", 990, 990, 0.25, 0.14, 0.45); }
      else if (kind === "death") { mk("sine", 440, 440, 0.22, 0.12); mk("sine", 349, 349, 0.22, 0.12, 0.22); mk("sine", 293, 293, 0.22, 0.12, 0.44); mk("sine", 220, 180, 0.45, 0.13, 0.66); }
      else if (kind === "fanfare" || kind === "portal") { mk("square", 523, 523, 0.09, 0.11); mk("square", 659, 659, 0.09, 0.11, 0.08); mk("square", 784, 784, 0.09, 0.11, 0.16); mk("square", 1046, 1046, 0.22, 0.12, 0.24); mk("sine", 1568, 1568, 0.35, 0.07, 0.30); mk("sine", 2093, 2093, 0.40, 0.06, 0.38); }
      else if (kind === "heartbreak") { mk("sine", 900, 300, 0.12, 0.10); noiseBurst(0.10, 0.10, 0.02, 2500); mk("sine", 600, 200, 0.15, 0.09, 0.08); }
      else if (kind === "jump") mk("square", 300, 600, 0.12, 0.14);
      else if (kind === "grapple") mk("triangle", 700, 1100, 0.1, 0.12);
      else if (kind === "tink") mk("sine", 1300, 1300, 0.08, 0.08);
      else if (kind === "hit") { mk("sawtooth", 400, 80, 0.3, 0.20); noiseBurst(0.15, 0.12, 0, 900); mk("sine", 900, 300, 0.12, 0.08, 0.02); try { (navigator as any).vibrate?.(60); } catch { /* nessuna vibrazione */ } }
      else if (kind === "boom") mk("square", 300, 40, 0.25, 0.14);
      else if (kind === "level") { mk("sine", 520, 520, 0.1, 0.10); mk("sine", 780, 780, 0.12, 0.10, 0.11); mk("sine", 1040, 1040, 0.18, 0.10, 0.22); }
      else if (kind === "milestone") { mk("sine", 660, 660, 0.09, 0.08); mk("sine", 990, 990, 0.14, 0.08, 0.09); }
      else if (kind === "alarm") mk("square", 880, 880, 0.07, 0.06);
      else if (kind === "wind") { mk("sawtooth", 300, 600, 0.25, 0.05); mk("sawtooth", 400, 800, 0.25, 0.04, 0.1); }
      else if (kind === "floor") { mk("sawtooth", 160, 30, 0.4, 0.18); mk("square", 90, 30, 0.4, 0.12, 0.05); }
      else if (kind === "zip") { mk("sawtooth", 400, 1600, 0.12, 0.12); mk("sine", 900, 2200, 0.09, 0.05); }
      else if (kind === "clack") { mk("square", 1800, 1200, 0.03, 0.16); mk("square", 1400, 900, 0.04, 0.14, 0.06); noiseBurst(0.03, 0.08, 0, 3000); }
      else if (kind === "boing") { mk("sine", 180, 560, 0.18, 0.14); mk("sine", 560, 180, 0.16, 0.08, 0.05); }
      else if (kind === "laser") { mk("sawtooth", 900, 220, 0.35, 0.06); mk("square", 1200, 300, 0.3, 0.04); }
      else if (kind === "whoosh") { mk("sawtooth", 300, 1800, 0.45, 0.12); mk("sine", 500, 2400, 0.4, 0.08, 0.05); }
      else if (kind === "ding") { mk("sine", 1320, 1320, 0.35, 0.12, 0.1); mk("sine", 1980, 1980, 0.45, 0.08, 0.15); }
      else if (kind === "bzz") { mk("sawtooth", 140, 90, 0.18, 0.16); mk("square", 180, 110, 0.14, 0.10, 0.02); }
      else mk("sine", 180, 180, 0.06, 0.06);
    } catch { /* silenzio */ }
  }, []);

  // --- MUSICA CHIPTUNE ANNI 90: solo Web Audio, loop perfetto 160 step a 140 BPM (~17s) ---
  const musicGainRef = useRef<GainNode | null>(null);
  const musicNoiseRef = useRef<AudioBuffer | null>(null);
  const musicStateRef = useRef<{ timer: number | null; nextTime: number; step: number; mode: "menu" | "game"; playing: boolean }>({ timer: null, nextTime: 0, step: 0, mode: "menu", playing: false });
  const startMusic = useCallback((mode: "menu" | "game") => {
    try {
      if (mutedRef.current) { musicStateRef.current.mode = mode; return; }
      if (!audioRef.current) audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioRef.current; if (ctx.state === "suspended") void ctx.resume();
      if (!musicGainRef.current) { const gg = ctx.createGain(); gg.gain.value = mode === "menu" ? 0.045 : 0.07; gg.connect(ctx.destination); musicGainRef.current = gg; }
      if (!musicNoiseRef.current) { const len = Math.floor(ctx.sampleRate * 0.2); const buf = ctx.createBuffer(1, len, ctx.sampleRate); const ch = buf.getChannelData(0); for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1; musicNoiseRef.current = buf; }
      const st = musicStateRef.current; st.mode = mode;
      if (musicGainRef.current) musicGainRef.current.gain.setTargetAtTime(mode === "menu" ? 0.045 : 0.07, ctx.currentTime, 0.1);
      if (st.playing) return;
      st.playing = true; st.nextTime = ctx.currentTime + 0.08;
      const stepDur = 60 / 140 / 4;
      // 10 battute da 16 step: melodia orecchiabile (Do-Fa-Sol), basso che cammina.
      const phrases: Record<number, number>[] = [
        { 0: 72, 2: 76, 4: 79, 6: 76, 8: 72, 10: 76, 12: 79, 14: 84 },
        { 0: 79, 2: 76, 4: 72, 6: 76, 8: 79, 10: 84, 12: 79, 14: 76 },
        { 0: 77, 2: 81, 4: 84, 6: 81, 8: 77, 10: 81, 12: 84, 14: 81 },
        { 0: 84, 2: 81, 4: 77, 6: 81, 8: 84, 10: 81, 12: 77, 14: 72 },
        { 0: 72, 2: 76, 4: 79, 6: 84, 8: 79, 10: 76, 12: 72, 14: 76 },
        { 0: 79, 2: 83, 4: 86, 6: 83, 8: 79, 10: 83, 12: 86, 14: 83 },
        { 0: 77, 2: 81, 4: 84, 6: 81, 8: 77, 10: 81, 12: 77, 14: 74 },
        { 0: 79, 2: 83, 4: 79, 6: 74, 8: 79, 10: 83, 12: 86, 14: 91 },
        { 0: 84, 2: 79, 4: 76, 6: 79, 8: 84, 10: 88, 12: 84, 14: 79 },
        { 0: 76, 2: 79, 4: 84, 6: 79, 8: 72, 10: 76, 12: 72, 14: 76 },
      ];
      const roots = [48, 48, 53, 53, 48, 55, 53, 55, 48, 48];
      const tone = (midi: number, t: number, dur: number, type: OscillatorType, vol: number) => {
        if (!musicGainRef.current) return;
        const o = ctx.createOscillator(), gn = ctx.createGain();
        o.connect(gn); gn.connect(musicGainRef.current); o.type = type;
        o.frequency.setValueAtTime(440 * Math.pow(2, (midi - 69) / 12), t);
        gn.gain.setValueAtTime(vol, t); gn.gain.exponentialRampToValueAtTime(0.001, t + dur);
        o.start(t); o.stop(t + dur + 0.02);
      };
      const drum = (t: number, dur: number, vol: number, freq: number, type: BiquadFilterType) => {
        if (!musicGainRef.current || !musicNoiseRef.current) return;
        const src = ctx.createBufferSource(); src.buffer = musicNoiseRef.current; src.loop = true;
        const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
        const gn = ctx.createGain(); gn.gain.setValueAtTime(vol, t); gn.gain.exponentialRampToValueAtTime(0.001, t + dur);
        src.connect(f); f.connect(gn); gn.connect(musicGainRef.current); src.start(t); src.stop(t + dur + 0.02);
      };
      const scheduleStep = (step: number, t: number) => {
        const bar = Math.floor(step / 16) % 10, pos = step % 16, isMenu = st.mode === "menu";
        const note = phrases[bar][pos];
        if (note) tone(note, t, stepDur * 1.8, "square", isMenu ? 0.045 : 0.065);
        if (pos % 4 === 0) tone(pos === 8 ? roots[bar] + 12 : roots[bar], t, stepDur * 3, "triangle", isMenu ? 0.07 : 0.09);
        else if (pos % 4 === 2) tone(roots[bar] + 7, t, stepDur * 1.5, "triangle", isMenu ? 0.04 : 0.055);
        if (isMenu) return;
        if (pos % 4 === 0) tone(36, t, 0.12, "sine", 0.10);
        if (pos === 4 || pos === 12) drum(t, 0.08, 0.05, 1800, "bandpass");
        if (pos % 2 === 0) drum(t, 0.03, 0.022, 7000, "highpass");
      };
      st.timer = window.setInterval(() => {
        if (mutedRef.current) return;
        const ahead = ctx.currentTime + 0.18;
        while (st.nextTime < ahead) { scheduleStep(st.step, st.nextTime); st.step = (st.step + 1) % 160; st.nextTime += stepDur; }
      }, 40);
    } catch { /* musica non disponibile */ }
  }, []);
  const pauseMusic = useCallback(() => {
    const st = musicStateRef.current;
    if (st.timer !== null) { window.clearInterval(st.timer); st.timer = null; }
    st.playing = false;
  }, []);
  const unlockAudio = useCallback(() => {
    try {
      if (!audioRef.current) audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioRef.current.state === "suspended") void audioRef.current.resume();
      startMusic(phaseRef.current === "playing" ? "game" : "menu");
    } catch { /* audio non disponibile */ }
  }, [startMusic]);

  const persistProgress = useCallback(async (nextBest: Record<number, number>, nextUnlocked: number[], nextCompleted: number[]) => {
    try {
      const value = { bestByLevel: nextBest, unlocked: nextUnlocked, completed: nextCompleted };
      if (progressIdRef.current) await api("records.replace", { collection: "caverna_levels", id: progressIdRef.current, value });
      else {
        const rec = await api("records.create", { collection: "caverna_levels", value, idempotency_key: `caverna-levels-${Date.now()}` });
        if (rec?.id) { progressIdRef.current = rec.id; setProgressId(rec.id); }
      }
      setSaveNote("Progressi salvati");
    } catch { setSaveNote("Progressi non salvati — riproverò alla prossima partita"); }
  }, []);

  const loadProgress = useCallback(async () => {
    try {
      const data = await api("records.list", { collection: "caverna_levels" });
      const rec = data?.records?.[0];
      if (rec?.value) {
        const nb = { ...(rec.value.bestByLevel || {}) } as Record<number, number>;
        // Sblocco progressivo: solo L1 + il livello dopo ogni livello completato.
        // Un vecchio salvataggio con tutto sbloccato viene ricondotto alla progressione.
        const comp = Array.isArray(rec.value.completed) ? rec.value.completed : [];
        // UNLOCK_ALL = true: sblocco in pausa, tutti i mondi aperti. La progressione sotto resta intatta.
        const un = UNLOCK_ALL ? [...ALL_LEVEL_IDS] : [1];
        if (!UNLOCK_ALL) { for (const c of comp) { if (c >= 1 && c < 22 && !un.includes(c + 1)) un.push(c + 1); } }
        bestRef.current = nb; unlockedRef.current = un; completedRef.current = comp; progressIdRef.current = rec.id;
        setBestByLevel(nb); setUnlocked(un); setCompleted(comp); setProgressId(rec.id);
        setHud(h => ({ ...h, best: Math.max(0, ...Object.values(nb)) }));
        return;
      }
      try {
        const old = await api("records.list", { collection: "caverna_best" });
        const o = old?.records?.[0];
        if (o?.value?.best) {
          const nb = { 1: Number(o.value.best) } as Record<number, number>;
          const un = UNLOCK_ALL ? [...ALL_LEVEL_IDS] : (Number(o.value.best) >= 220 ? [1, 2] : [1]);
          const comp = Number(o.value.best) >= 220 ? [1] : [];
          bestRef.current = nb; unlockedRef.current = un; completedRef.current = comp; setBestByLevel(nb); setUnlocked(un); setCompleted(comp);
          setHud(h => ({ ...h, best: Number(o.value.best) }));
          await persistProgress(nb, un, comp);
        }
      } catch { /* nessun vecchio salvataggio */ }
    } catch { /* progressi non disponibili */ }
  }, [persistProgress]);
  useEffect(() => { document.title = "KUBO RUN - Corri, salta, agganciati, entra nel portale"; loadProgress(); }, [loadProgress]);
  useEffect(() => {
    if (phase === "paused") pauseMusic();
    else if (phase === "playing") startMusic("game");
    else startMusic("menu");
  }, [phase, startMusic, pauseMusic]);
  useEffect(() => {
    const unlock = () => unlockAudio();
    const uiClick = (e: MouseEvent) => {
      const el = e.target as HTMLElement | null;
      const btn = el?.closest?.("button");
      if (!btn) return;
      if (btn.closest('[role="slider"]')) return;
      const label = btn.getAttribute("aria-label") || "";
      if (label.includes("Rampino") || label.includes("Pad")) return;
      sfx("ui");
    };
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    window.addEventListener("click", uiClick);
    return () => { window.removeEventListener("pointerdown", unlock); window.removeEventListener("keydown", unlock); window.removeEventListener("click", uiClick); };
  }, [unlockAudio, sfx]);
  useEffect(() => { if (phase !== "menu") return; const idx = Math.max(0, LEVELS.findIndex((lv) => lv.id === currentLevelId)); setCarouselIndex(idx); const t = window.setTimeout(() => { const el = carouselRef.current; if (el) el.scrollTo({ left: idx * 288, behavior: "auto" }); }, 60); return () => window.clearTimeout(t); }, [phase, currentLevelId]);

  const saveBest = useCallback(async (meters: number, levelId: number, won = false) => {
    const cur = bestRef.current[levelId] || 0;
    const nextBest = { ...bestRef.current };
    let changed = false;
    if (meters > cur) { nextBest[levelId] = meters; changed = true; }
    const nextUnlocked = [...unlockedRef.current];
    if (!nextUnlocked.includes(1)) nextUnlocked.unshift(1);
    const nextCompleted = [...completedRef.current];
    if (won && !nextCompleted.includes(levelId)) { nextCompleted.push(levelId); nextCompleted.sort((a,b)=>a-b); changed = true; }
    if (won && levelId < 22 && !nextUnlocked.includes(levelId + 1)) { nextUnlocked.push(levelId + 1); nextUnlocked.sort((a,b)=>a-b); changed = true; }
    if (meters >= (LEVELS[levelId-1]?.goal || 999) && !nextCompleted.includes(levelId)) { nextCompleted.push(levelId); nextCompleted.sort((a,b)=>a-b); changed = true; if (levelId < 22 && !nextUnlocked.includes(levelId+1)) { nextUnlocked.push(levelId+1); nextUnlocked.sort((a,b)=>a-b); } }
    if (!changed) return;
    bestRef.current = nextBest; unlockedRef.current = nextUnlocked; completedRef.current = nextCompleted;
    setBestByLevel(nextBest); setUnlocked(nextUnlocked); setCompleted(nextCompleted);
    setHud(h => ({ ...h, best: Math.max(0, ...Object.values(nextBest)) }));
    await persistProgress(nextBest, nextUnlocked, nextCompleted);
  }, [persistProgress]);

  const resetGame = useCallback((levelId?: number) => {
    const lid = levelId ?? selectedRef.current;
    const cfg = LEVELS[lid - 1];
    const plats: Platform[] = buildLevelPlatforms(cfg);
    const finalY0 = START_Y - cfg.goal * 12;
    input.current.jumpQueued = false;
    for (const [vid, osc] of Array.from(voicesRef.current.entries())) { try { osc.stop(); } catch { /* già fermo */ } if (voicesRef.current.get(vid) === osc) voicesRef.current.delete(vid); }
    g.current = { px: 135, py: START_Y - 16, vx: 0, vy: 0, stepT: 0, grounded: true, coyote: 0, jumpBuf: 0, dropT: 0, grappleCd: 0, grappleT: 0, grappleFromX: 135, grappleFromY: 0, grapplePhase: "idle" as const, grappleTargetX: 18, grappleTargetY: 0, grappleHookX: 135, grappleHookY: 0, grappleDir: 1 as const, grappleRopeLen: 12, grapplePlateFlash: 0, anchorFlash: 0, grappleAimT: 0, grappleAimDir: 1 as const, grappleAimTargetX: 18, grappleAimTargetY: 0, grappleAimHas: false, grappleMiss: false, grappleAimAngle: -Math.PI / 3, grappleAngle: -Math.PI / 3, landSquash: 0, deathT: 0, deathDone: false, lastDir: 1 as const, cameraY: 0, minFeet: START_Y, platforms: plats, enemies: [], telegraphs: [], particles: [], ghosts: [], shocks: [], flashT: 0, shakeT: 0, alarmT: 0, hp: 3, invuln: 0, points: 0, floorY: START_Y + 200, floorWait: 4, time: 0, spawnT: 2, dead: false, lastKill: 0, idleT: 0, level: lid, lastMilestone: 0, bannerT: 0, deathCause: "", windT: 0, windDir: 1, windNext: cfg.windEvery, tongueNext: cfg.tongue ? 11 : 999, tongueWarn: 0, straight: 0, lastJumpX: 135, won: false, winT: 0, groundKind: "normal", groundConveyor: 0, groundPlat: null, portalX: 135, portalY: (START_Y - cfg.goal * 12) - (lid === 20 ? 80 : lid >= 21 ? 90 : 65), portalActive: false, portalEntered: false, portalT: 0, portalExploded: false, finalY: START_Y - cfg.goal * 12, finalInserted: true, checkpointTaken: false, portalEmitAcc: 0, portalRingT: 0, barrierFlash: 0, barrierHintShown: false, hitT: 0, tiredT: 0, landFaceT: 0, jumpFaceT: 0, hookFaceT: 0, surpriseT: 0, winkT: 0, happyT: 0 };
    setHud(h => ({ ...h, m: 0, hp: 3, points: 0, level: lid, levelLabel: cfg.name, floorDist: 999, straight: 0, windOn: false, windDir: 1, tongueWarn: false, grapple: 1, grappleReady: true, best: Math.max(0, ...Object.values(bestRef.current)), goal: cfg.goal }));
    setSaveNote(""); setDeathCause(""); setIsLegend(false); setIsWin(false); setWinStars(3);
    setLevelBanner(`LIVELLO ${lid} — ${cfg.name} · OBIETTIVO ${cfg.goal}m`);
    g.current.bannerT = 2.2;
  }, []);

  const doJump = useCallback(() => { input.current.jumpQueued = true; }, []);
  const grappleDirNow = useCallback((): 1 | -1 => {
    const s = g.current;
    if (joy.current.dx < -0.25) return -1;
    if (joy.current.dx > 0.25) return 1;
    if (aimKeysRef.current.left && !aimKeysRef.current.right) return -1;
    if (aimKeysRef.current.right && !aimKeysRef.current.left) return 1;
    if (input.current.left && !input.current.right) return -1;
    if (input.current.right && !input.current.left) return 1;
    const cx = s.px + 8;
    if (Math.abs(cx - 17) < 28) return -1;
    if (Math.abs(cx - 253) < 28) return 1;
    return s.lastDir;
  }, []);
  const startGrappleAim = useCallback(() => {
    const s = g.current; if (phaseRef.current !== "playing" || s.dead || s.won) return;
    if (s.grapplePhase === "hang") { s.grapplePhase = "idle"; s.grappleT = 0; s.grappleCd = 0.3; s.grounded = false; s.grappleAngle = -Math.PI / 3; sfx("detach"); return; }
    if (s.grappleCd > 0 || s.grapplePhase !== "idle") return;
    const dir = grappleDirNow(); const target = computeGrappleTarget(s.px, s.py, dir);
    s.grapplePhase = "aim"; s.grappleAimT = 0; s.grappleAimDir = dir; s.grappleDir = dir; s.lastDir = dir;
    s.grappleAimAngle = dir < 0 ? Math.PI + Math.PI / 3 : -Math.PI / 3; s.grappleAngle = s.grappleAimAngle;
    s.grappleAimTargetX = target.x; s.grappleAimTargetY = target.y; s.grappleAimHas = target.ok;
  }, [grappleDirNow]);
  const launchGrapple = useCallback(() => {
    const s = g.current; if (s.grapplePhase !== "aim") return;
    if (phaseRef.current !== "playing" || s.dead || s.won) { s.grapplePhase = "idle"; return; }
    const dir = grappleDirNow(); const target = computeGrappleTarget(s.px, s.py, dir);
    s.grappleDir = dir; s.lastDir = dir; s.grappleCd = 0.5; s.grapplePhase = "fly"; s.grappleT = 0.16;
    s.grappleFromX = s.px; s.grappleFromY = s.py; s.grappleTargetX = target.x; s.grappleTargetY = target.y; s.grappleMiss = !target.ok; s.jumpFaceT = 0;
    s.grappleHookX = s.px; s.grappleHookY = s.py; s.grappleAimAngle = dir < 0 ? Math.PI + Math.PI / 3 : -Math.PI / 3; s.grappleAngle = s.grappleAimAngle; s.grappleRopeLen = 12; s.vx = 0; s.vy = 0; sfx("pew");
    setGrappleFlash(true); setTimeout(() => setGrappleFlash(false), 150);
  }, [sfx, grappleDirNow]);
  const realFullscreenRef = useRef(false);
  const enterFullscreen = useCallback(async () => {
    setCssFullscreen(true); setIsFullscreen(true);
    try {
      const el = document.documentElement as any;
      if (!document.fullscreenElement && el?.requestFullscreen) {
        await el.requestFullscreen({ navigationUI: "hide" });
        realFullscreenRef.current = true;
      }
    } catch { /* Fallback: resta il layout a schermo intero via CSS */ }
  }, []);
  const exitFullscreen = useCallback(async () => {
    realFullscreenRef.current = false;
    setCssFullscreen(false); setIsFullscreen(false);
    try { if (document.fullscreenElement) await document.exitFullscreen(); } catch { /* già uscito */ }
  }, []);
  const toggleFullscreen = useCallback(async () => { if (isFullscreen) await exitFullscreen(); else await enterFullscreen(); }, [isFullscreen, enterFullscreen, exitFullscreen]);
  useEffect(() => {
    const onChange = () => {
      if (document.fullscreenElement) { realFullscreenRef.current = true; setCssFullscreen(true); setIsFullscreen(true); }
      else if (realFullscreenRef.current) { realFullscreenRef.current = false; setCssFullscreen(false); setIsFullscreen(false); }
    };
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);
  const startGame = useCallback((levelId?: number) => {
    const lid = levelId ?? selectedRef.current;
    if (!unlockedRef.current.includes(lid)) return;
    selectedRef.current = lid; setSelectedLevel(lid); setIsLegend(false); setIsWin(false);
    unlockAudio(); sfx("ready"); startMusic("game");
    void enterFullscreen();
    resetGame(lid); setPhase("playing");
  }, [resetGame, enterFullscreen]);
  const goToMenu = useCallback(() => { void exitFullscreen(); setResumeCount(null); setPhase("menu"); setLevelBanner(""); }, [exitFullscreen]);
  const goToLevels = useCallback(async () => {
    if (phaseRef.current === "playing" || phaseRef.current === "paused") {
      const s = g.current; const meters = Math.max(0, Math.floor((START_Y - s.minFeet) / 12));
      if (meters > 0) { try { await saveBest(meters, s.level || selectedRef.current, meters >= (LEVELS[(s.level||1)-1]?.goal||999)); } catch { /* BEST in memoria */ } }
    }
    await exitFullscreen();
    setResumeCount(null); setPhase("menu"); setLevelBanner("");
  }, [saveBest, exitFullscreen]);
  const menuTouchRef = useRef(false);
  useEffect(() => { if (phase === "menu") menuTouchRef.current = false; }, [phase]);
  const tryMenuFullscreen = useCallback(() => {
    if (phaseRef.current !== "menu") return;
    if (menuTouchRef.current) return;
    menuTouchRef.current = true;
    void enterFullscreen();
  }, [enterFullscreen]);
  const startResumeCountdown = useCallback(() => { if (phaseRef.current !== "paused") return; setResumeCount(3); }, []);
  const restartFromPause = useCallback(() => { setResumeCount(null); resetGame(selectedRef.current); const s = g.current; s.invuln = 1; s.floorWait = 0.5; setLevelBanner("VIA!"); s.bannerT = 0.8; setPhase("playing"); }, [resetGame]);
  useEffect(() => {
    if (resumeCount === null) return;
    if (resumeCount === 0) { const s = g.current; s.invuln = Math.max(s.invuln, 1); s.floorWait = Math.max(s.floorWait, 0.5); setLevelBanner("VIA!"); s.bannerT = 0.8; setResumeCount(null); setPhase("playing"); return; }
    const t = setTimeout(() => setResumeCount((c) => (c === null ? c : c - 1)), 450);
    return () => clearTimeout(t);
  }, [resumeCount]);
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Space"].includes(e.code)) e.preventDefault();
      if (e.code === "KeyA" || e.code === "ArrowLeft") { input.current.left = true; aimKeysRef.current.left = true; }
      if (e.code === "KeyD" || e.code === "ArrowRight") { input.current.right = true; aimKeysRef.current.right = true; }
      if (e.code === "KeyW" || e.code === "ArrowUp") aimKeysRef.current.up = true;
      if (e.code === "KeyS" || e.code === "ArrowDown") aimKeysRef.current.down = true;
      if (e.code === "KeyW" || e.code === "ArrowUp" || e.code === "Space") { if (!e.repeat) doJump(); }
      if (e.code === "KeyE" || e.code === "KeyQ") { if (!e.repeat) startGrappleAim(); }
      if (e.code === "KeyF") { if (!e.repeat) { e.preventDefault(); toggleFullscreen(); } }
      if (e.code === "KeyM") { if (!e.repeat) { const v = !mutedRef.current; mutedRef.current = v; setMuted(v); } }
      if (e.code === "KeyR" && phaseRef.current === "over") startGame(selectedRef.current);
      if (e.code === "Enter" && phaseRef.current === "menu") startGame(selectedRef.current);
      if (e.code === "KeyP" && phaseRef.current === "playing") setPhase("paused");
      if (e.code === "KeyP" && phaseRef.current === "paused") setResumeCount(3);
      if (e.code === "Escape") { if (phaseRef.current === "playing") setPhase("paused"); else if (phaseRef.current === "paused") setResumeCount(3); }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "KeyA" || e.code === "ArrowLeft") { input.current.left = false; aimKeysRef.current.left = false; }
      if (e.code === "KeyD" || e.code === "ArrowRight") { input.current.right = false; aimKeysRef.current.right = false; }
      if (e.code === "KeyW" || e.code === "ArrowUp") aimKeysRef.current.up = false;
      if (e.code === "KeyS" || e.code === "ArrowDown") aimKeysRef.current.down = false;
      if (e.code === "KeyE" || e.code === "KeyQ") launchGrapple();
    };
    window.addEventListener("keydown", down); window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [doJump, startGame, goToMenu, startGrappleAim, launchGrapple, toggleFullscreen]);

  useEffect(() => {
    let raf = 0; let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dtRaw = Math.min((now - last) / 1000, 0.05); last = now;
      const canvas = canvasRef.current; if (!canvas) return;
      const ctx = canvas.getContext("2d"); if (!ctx) return;
      const s = g.current;
      const cfg = LEVELS[(selectedRef.current - 1)] || LEVELS[0];
      const playing = phaseRef.current === "playing";
      const step = dtRaw * 60;

      if (playing && !s.dead && !s.won) {
        s.time += dtRaw;
        // --- Piattaforme mobili: aggiorna + trascina chi ci sta sopra ---
        for (const p of s.platforms) {
          if (!p.moving || p.gone > 0) continue;
          const oldX = p.x, oldY = p.y;
          if (p.kind === "slow") p.x = p.baseX + Math.sin(s.time * 1.0 + p.movePhase) * p.moveRange;
          else if (p.kind === "fast") p.x = p.baseX + Math.sin(s.time * 2.57 + p.movePhase) * p.moveRange;
          else if (p.kind === "vertical") p.y = p.baseY + Math.sin(s.time * 1.2 + p.movePhase) * 40;
          else if (p.kind === "diagonal") { p.x = p.baseX + Math.sin(s.time * 1.1 + p.movePhase) * 30; p.y = p.baseY + Math.cos(s.time * 1.1 + p.movePhase) * 30; }
          else if (p.kind === "gear") { p.x = p.baseX + Math.sin(s.time * 0.8 + p.movePhase) * 22; p.y = p.baseY + Math.cos(s.time * 0.8 + p.movePhase) * 8; }
          else if (p.kind === "vine") { p.x = p.baseX + Math.sin(s.time * 1.4 + p.movePhase) * 30; p.y = p.baseY + Math.sin(s.time * 1.4 + p.movePhase) * 4; }
          if (s.groundPlat === p && s.grounded) { s.px += (p.x - oldX); s.py += (p.y - oldY); }
          if (p.moving && Math.random() < 0.55) { const bp = brickPaletteFor(cfg); const isAbyss = bp.family === "E"; s.particles.push({ x: p.x + (Math.random() - 0.5) * p.w, y: p.y + 5, vx: (Math.random() - 0.5) * 0.6, vy: isAbyss ? -0.9 : 0.5, life: isAbyss ? 0.6 : 0.3, max: isAbyss ? 0.6 : 0.3, color: bp.trail, size: isAbyss ? 2 : 2 }); }
        }
        // --- Particelle ambientali ---
        if (Math.random() < 0.35) {
          const ax = 20 + Math.random() * 230, ay = s.cameraY + Math.random() * 480;
          if (cfg.ambient === "snow") s.particles.push({ x: ax, y: ay, vx: -0.3, vy: 0.8, life: 1.2, max: 1.2, color: "#ffffff", size: 2 });
          else if (cfg.ambient === "embers") s.particles.push({ x: ax, y: ay, vx: 0.2, vy: -0.6, life: 0.9, max: 0.9, color: "#ff9a3d", size: 2 });
          else if (cfg.ambient === "bubbles") s.particles.push({ x: ax, y: ay, vx: 0, vy: -1, life: 1, max: 1, color: "#7dd3fc", size: 2 });
          else if (cfg.ambient === "fireflies") s.particles.push({ x: ax, y: ay, vx: (Math.random()-0.5)*0.6, vy: (Math.random()-0.5)*0.6, life: 1.4, max: 1.4, color: "#fef08a", size: 2 });
          else if (cfg.ambient === "rain") s.particles.push({ x: ax, y: ay, vx: -1, vy: 3, life: 0.4, max: 0.4, color: "#67e8f9", size: 1 });
          else if (cfg.ambient === "sparks") s.particles.push({ x: ax, y: ay, vx: (Math.random()-0.5)*2, vy: (Math.random()-0.5)*2, life: 0.3, max: 0.3, color: "#fde68a", size: 1 });
          else if (cfg.ambient === "ash") s.particles.push({ x: ax, y: ay, vx: 0.3, vy: 0.4, life: 1, max: 1, color: "#9ca3af", size: 2 });
          else if (cfg.ambient === "spores") s.particles.push({ x: ax, y: ay, vx: 0.2, vy: -0.3, life: 1.2, max: 1.2, color: "#fecaca", size: 2 });
          else if (cfg.ambient === "dust") s.particles.push({ x: ax, y: ay, vx: 0.1, vy: 0.2, life: 1, max: 1, color: cfg.particle, size: 1 });
        }
        const joyDX = joy.current.dx, joyDY = joy.current.dy;
        const left = input.current.left || joyDX < -0.25;
        const right = input.current.right || joyDX > 0.25;
        const padUp = joyDY < -0.55 || aimKeysRef.current.up;
        const padDown = joyDY > 0.55 || aimKeysRef.current.down;
        const analog = Math.abs(joyDX) > 0.12 ? Math.abs(joyDX) : (left || right ? 1 : 0);
        const speed = 3.0 * clamp(analog, 0.25, 1);
        const onIce = s.grounded && s.groundKind === "ice";
        if (left && !right) { s.vx = -speed; s.lastDir = -1; }
        else if (right && !left) { s.vx = speed; s.lastDir = 1; }
        else if (onIce) { s.vx *= Math.pow(0.985, step); if (Math.abs(s.vx) < 0.05) s.vx = 0; }
        else { s.vx *= Math.pow(0.85, step); if (Math.abs(s.vx) < 0.05) s.vx = 0; }
        if (s.grounded && s.groundKind === "conveyor") s.px += s.groundConveyor * 42 * dtRaw;
        if (s.grounded && Math.abs(s.vx) > 0.5 && s.grapplePhase === "idle") { s.stepT += Math.abs(s.vx) * dtRaw; if (s.stepT > 2.2) { s.stepT = 0; sfx("step"); } } else s.stepT = 0;
        if (!left && !right && Math.abs(joyDX) < 0.12) s.idleT += dtRaw; else s.idleT = 0;
        if (padUp) input.current.jumpQueued = true;
        if (input.current.jumpQueued) { s.jumpBuf = 0.12; input.current.jumpQueued = false; }
        if (s.jumpBuf > 0) s.jumpBuf -= dtRaw;
        if (s.grounded) s.coyote = 0.1; else if (s.coyote > 0) s.coyote -= dtRaw;
        if (padDown && s.grounded && s.grapplePhase === "idle") { s.dropT = 0.22; s.grounded = false; s.groundPlat = null; s.vy = 2.5; }
        if (s.dropT > 0) s.dropT -= dtRaw;
        if (padDown && !s.grounded && s.grapplePhase === "idle") { s.vy = Math.max(s.vy, 5); }
        if (s.jumpBuf > 0 && (s.grounded || s.coyote > 0) && s.grapplePhase !== "pull" && s.grapplePhase !== "fly") {
          const lateral = Math.abs(s.px - s.lastJumpX);
          if (lateral < 20) s.straight += 1; else s.straight = 0;
          s.lastJumpX = s.px;
          if (s.straight >= 4) {
            const feetNow = s.py + 16;
            const under = s.platforms.find(p => p.gone <= 0 && Math.abs(p.y - feetNow) < 10 && s.px + 9 > p.x - p.w / 2 && s.px - 9 < p.x + p.w / 2);
            if (under && under.kind === "normal") { under.fragile = true; under.kind = "fragile"; under.flash = 0.35; }
            s.bannerT = 1.6; setLevelBanner("MUOVITI! SALTA DI LATO"); sfx("alarm"); s.straight = 0;
          }
          s.vy = -11; s.grounded = false; s.groundPlat = null; s.coyote = 0; s.jumpBuf = 0; s.jumpFaceT = 0.55; sfx("jump");
          for (let i = 0; i < 5; i++) s.particles.push({ x: s.px + (Math.random() - 0.5) * 12, y: s.py + 16, vx: (Math.random() - 0.5) * 1.5, vy: Math.random() * 1.5, life: 0.35, max: 0.35, color: "#cbb59a", size: 2 });
        }
        if (s.grapplePhase === "aim") {
          s.grappleAimT += dtRaw; const dir = grappleDirNow(); const target = computeGrappleTarget(s.px, s.py, dir);
          s.grappleAimDir = dir; s.grappleDir = dir; s.lastDir = dir; s.grappleAimAngle = dir < 0 ? Math.PI + Math.PI / 3 : -Math.PI / 3; s.grappleAngle = s.grappleAimAngle;
          s.grappleAimTargetX = target.x; s.grappleAimTargetY = target.y; s.grappleAimHas = target.ok;
        }
        if (s.grapplePhase === "fly" || s.grapplePhase === "pull" || s.grapplePhase === "hang" || s.grapplePhase === "retract") {
          if (s.grapplePhase === "fly") {
            const p = 1 - Math.max(0, s.grappleT) / 0.16; s.grappleHookX = s.grappleFromX + (s.grappleTargetX - s.grappleFromX) * p; s.grappleHookY = s.grappleFromY + (s.grappleTargetY - s.grappleFromY) * p;
            s.vx = 0; s.vy = 0; s.grappleT -= dtRaw;
            if (s.grappleT <= 0) {
              if (s.grappleMiss) { s.grapplePhase = "retract"; s.grappleT = 0.12; s.grappleFromX = s.grappleHookX; s.grappleFromY = s.grappleHookY; sfx("tink"); }
              else { s.grapplePhase = "pull"; s.grappleFromX = s.px; s.grappleFromY = s.py; s.grapplePlateFlash = 0.35; s.shakeT = 0.12; s.hookFaceT = 0.7; s.winkT = 0.8; sfx("clack"); for (let i = 0; i < 10; i++) s.particles.push({ x: s.grappleTargetX, y: s.grappleTargetY + (Math.random() - 0.5) * 14, vx: -s.grappleDir * (1 + Math.random() * 3), vy: (Math.random() - 0.5) * 3, life: 0.35, max: 0.35, color: i % 2 ? "#ffd23d" : "#fff7cc", size: 2 + (i % 2) }); }
            }
          } else if (s.grapplePhase === "pull") {
            const cx = s.px + 8, cy = s.py + 8; const dx = s.grappleTargetX - cx, dy = s.grappleTargetY - cy; const dist = Math.hypot(dx, dy);
            if (dist <= 12) { s.grapplePhase = "hang"; s.grappleRopeLen = Math.max(10, dist); s.vx = 0; s.vy = 0; s.grounded = false; }
            else { const speed2 = 6.2; s.vx = (dx / dist) * speed2; s.vy = (dy / dist) * speed2; s.px += s.vx * step; s.py += s.vy * step; s.px = clamp(s.px, 0, 238); }
          } else if (s.grapplePhase === "hang") {
            s.vx = 0; s.vy = 0;
            const opposite = (left && s.grappleDir === 1) || (right && s.grappleDir === -1) || (joyDX !== 0 && Math.sign(joyDX) === -s.grappleDir && Math.abs(joyDX) > 0.45);
            const jumpAway = padUp || s.jumpBuf > 0;
            if (jumpAway) { s.grapplePhase = "idle"; s.jumpBuf = 0; s.grappleCd = 0.3; s.vx = -s.grappleDir * 2.2; s.vy = -11; s.grounded = false; sfx("superjump"); }
            else if (padDown) { s.grapplePhase = "idle"; s.grappleCd = 0.3; s.vy = 1; s.grounded = false; sfx("detach"); }
            else if (opposite) { const push = s.grappleDir === 1 ? -1 : 1; s.grapplePhase = "idle"; s.grappleCd = 0.3; s.vx = push * 3.6; s.vy = -5; s.grounded = false; sfx("detach"); }
          } else {
            const p = 1 - Math.max(0, s.grappleT) / 0.12; s.grappleHookX = s.grappleFromX + (s.px - s.grappleFromX) * p; s.grappleHookY = s.grappleFromY + (s.py - s.grappleFromY) * p;
            s.vx = 0; s.vy = 0; s.grappleT -= dtRaw; if (s.grappleT <= 0) { s.grapplePhase = "idle"; s.grappleT = 0; }
          }
        } else if (s.grapplePhase !== "hang") {
          s.vy += 0.45 * step; if (s.vy > 12) s.vy = 12;
          const prevFeet = s.py + 16; s.px += s.vx * step;
          if (s.windT > 0) { s.px += s.windDir * 42 * dtRaw; if (Math.random() < 0.6) s.particles.push({ x: s.px + (s.windDir > 0 ? -20 : 40), y: s.py + Math.random() * 22, vx: s.windDir * (4 + Math.random() * 3), vy: (Math.random() - 0.5) * 0.8, life: 0.35, max: 0.35, color: "#bfe9ff", size: 2 }); }
          s.py += s.vy * step; s.px = clamp(s.px, 18, 236);
          const newFeet = s.py + 16; let landed: Platform | null = null;
          if (s.vy >= 0 && s.dropT <= 0) {
            for (const p of s.platforms) {
              if (p.gone > 0) continue; if (!ghostVisible(p, s.time)) continue;
              if (prevFeet <= p.y + 2 && newFeet >= p.y && s.px + 9 > p.x - p.w / 2 - 2 && s.px - 9 < p.x + p.w / 2 + 2) { landed = p; break; }
            }
          }
          if (landed) {
            const wasAir = !s.grounded;
            // Spuntoni: danno + rimbalzo, non resti sopra.
            if (landed.kind === "spikes") {
              if (s.invuln <= 0) { s.hp -= 1; s.invuln = 1.2; s.hitT = 0.3; sfx("hit"); if (s.hp <= 0) { s.dead = true; s.deathCause = "hp"; } }
              s.py = landed.y - 16; s.vy = -7; s.grounded = false; s.groundPlat = null;
            } else if (landed.kind === "steam") {
              s.py = landed.y - 16; s.vy = -17; s.grounded = false; s.groundPlat = null; sfx("whoosh");
              for (let i = 0; i < 10; i++) s.particles.push({ x: s.px + 8, y: s.py + 16, vx: (Math.random()-0.5)*2, vy: -1 - Math.random()*2, life: 0.5, max: 0.5, color: i % 2 ? "#ffffff" : "#ffd23d", size: 3 });
            } else if (landed.kind === "shroom") {
              s.py = landed.y - 16; s.vy = -19.8; s.grounded = false; s.groundPlat = null; sfx("boing");
              for (let i = 0; i < 10; i++) s.particles.push({ x: s.px + 8, y: s.py + 16, vx: (Math.random()-0.5)*3, vy: Math.random()*2, life: 0.4, max: 0.4, color: i % 2 ? "#00ffff" : "#00ff88", size: 3 });
            } else if (landed.kind === "bounce") {
              s.py = landed.y - 16; s.vy = -19.8; s.grounded = false; s.groundPlat = null; sfx("boing");
              for (let i = 0; i < 8; i++) s.particles.push({ x: s.px + 8, y: s.py + 16, vx: (Math.random()-0.5)*3, vy: Math.random()*2, life: 0.35, max: 0.35, color: "#4ade80", size: 2 });
            } else {
              s.py = landed.y - 16; s.vy = 0; s.grounded = true; s.groundPlat = landed; s.groundKind = landed.kind; s.groundConveyor = landed.conveyorDir;
              if (landed.checkpoint && !s.checkpointTaken) { s.checkpointTaken = true; if (s.hp < 3) { s.hp += 1; } s.happyT = 1.2; setLevelBanner("❤️ CHECKPOINT — +1 CUORE"); s.bannerT = 2; sfx("ding"); for (let ci = 0; ci < 14; ci++) s.particles.push({ x: s.px + 8, y: s.py + 8, vx: (Math.random() - 0.5) * 3, vy: -Math.random() * 3, life: 0.6, max: 0.6, color: ci % 2 ? "#ff3b6b" : "#ffd23d", size: 2 }); }
              if (wasAir) { sfx("land"); s.anchorFlash = 0.5; s.landSquash = 0.12; s.landFaceT = 0.18; s.happyT = 0.9; landed.activated = 0.3; const bpL = brickPaletteFor(cfg); for (let i = 0; i < 8; i++) s.particles.push({ x: s.px + 8, y: s.py + 16, vx: (Math.random() - 0.5) * 3, vy: -Math.random() * 1.5, life: 0.35, max: 0.35, color: i % 2 ? bpL.glow : bpL.shard1, size: 2 }); }
              if (landed.kind === "fragile" && landed.flash <= 0) landed.flash = 0.7;
              if (landed.kind === "timed" && landed.flash <= 0) landed.flash = 0.5;
            }
          } else { if (s.grounded) { s.grounded = false; s.groundPlat = null; s.groundKind = "normal"; } }
        }
        if (s.landSquash > 0) s.landSquash -= dtRaw;
        if (s.grappleCd > 0) s.grappleCd -= dtRaw;
        if (s.grapplePlateFlash > 0) s.grapplePlateFlash -= dtRaw;
        if (s.anchorFlash > 0) s.anchorFlash -= dtRaw;
        if (s.invuln > 0) s.invuln -= dtRaw;
        if (s.hitT > 0) { s.hitT -= dtRaw * 0.5; if (s.hitT <= 0) s.tiredT = 0.5; }
        if (s.tiredT > 0) s.tiredT -= dtRaw;
        if (s.landFaceT > 0) s.landFaceT -= dtRaw;
        if (s.jumpFaceT > 0) s.jumpFaceT -= dtRaw;
        if (s.hookFaceT > 0) s.hookFaceT -= dtRaw;
        if (s.surpriseT > 0) s.surpriseT -= dtRaw;
        if (s.winkT > 0) s.winkT -= dtRaw;
        if (s.happyT > 0) s.happyT -= dtRaw;
        if (s.flashT > 0) s.flashT -= dtRaw;
        if (s.shakeT > 0) s.shakeT -= dtRaw;
        if (s.bannerT > 0) { s.bannerT -= dtRaw; if (s.bannerT <= 0) setLevelBanner(""); }
        if (s.windT > 0) s.windT -= dtRaw;
        else { s.windNext -= dtRaw; if (s.windNext <= 0) { const metersW = Math.max(0, Math.floor((START_Y - s.minFeet) / 12)); if (metersW >= 30 && cfg.windEvery < 100) { s.windT = 2; s.windDir = Math.random() < 0.5 ? -1 : 1; s.windNext = cfg.windEvery + Math.random() * 5; sfx("wind"); } else s.windNext = 5; } }
        if (s.tongueWarn > 0) { s.tongueWarn -= dtRaw; if (s.tongueWarn <= 0) { s.floorY -= 30; s.shakeT = 0.25; sfx("floor"); for (let i = 0; i < 10; i++) s.particles.push({ x: 30 + Math.random() * 210, y: s.floorY, vx: (Math.random() - 0.5) * 2, vy: -Math.random() * 3, life: 0.5, max: 0.5, color: "#ff5400", size: 3 }); s.tongueNext = 12 + Math.random() * 6; } }
        else { s.tongueNext -= dtRaw; if (s.tongueNext <= 0) { const mT = Math.max(0, Math.floor((START_Y - s.minFeet) / 12)); if (mT >= 30 && cfg.tongue) { s.tongueWarn = 0.9; sfx("alarm"); } else s.tongueNext = 6; } }
        for (const p of s.platforms) { if (p.activated > 0) p.activated -= dtRaw; if (p.flash > 0) { const wasBreaking = p.flash > 0; p.flash -= dtRaw; if (wasBreaking && p.flash > 0 && p.flash < 0.25 && Math.random() < 0.5) { const bpB = brickPaletteFor(cfg); s.particles.push({ x: p.x + (Math.random() - 0.5) * p.w, y: p.y + 3, vx: (Math.random() - 0.5) * 2, vy: -Math.random() * 2, life: 0.3, max: 0.3, color: Math.random() < 0.5 ? bpB.shard1 : "#ffd23d", size: 2 }); } if (p.flash <= 0) { if (Math.abs((s.px + 8) - p.x) < 46 && Math.abs((s.py + 16) - p.y) < 34) s.surpriseT = 0.8; p.gone = 999; const bpB = brickPaletteFor(cfg); for (let i = 0; i < 12; i++) s.particles.push({ x: p.x + (Math.random() - 0.5) * p.w, y: p.y + 4, vx: (Math.random() - 0.5) * 4, vy: -Math.random() * 3, life: 0.55, max: 0.55, color: [bpB.shard1, bpB.shard2, bpB.crack, "#ffffff"][i % 4], size: 2 + (i % 3) }); } } }
        let top = Math.min(...s.platforms.map(p => p.y));
        while (top > s.cameraY - 400 && top > s.finalY) {
          const d = difficultyFor(Math.max(0, Math.floor((START_Y - top) / 12)), cfg); top -= d.gap;
          if (top <= s.finalY) break;
          const prev = s.platforms[s.platforms.length - 1]; const prevX2 = prev?.x ?? 135; const prevK = prev?.kind ?? "normal";
          s.platforms.push(makePlatform(top, s.time, cfg, prevX2, prevK, s.platforms.length));
        }
        if (!s.finalInserted && top <= s.finalY + cfg.gap + 5) {
          s.finalInserted = true;
          s.platforms.push({ x: 135, y: s.finalY, w: 110, fragile: false, gone: 0, flash: 0, moving: false, baseX: 135, baseY: s.finalY, movePhase: 0, moveRange: 0, moveSpeed: 0, kind: "wide", conveyorDir: 1, ghostPhase: 0, activated: 0 });
          s.platforms.sort((a, b) => b.y - a.y);
        }
        s.platforms = s.platforms.filter(p => p.y < s.cameraY + 620 && p.gone < 900);
        const targetCam = s.py - 190; if (targetCam < s.cameraY) s.cameraY = targetCam;
        const feet = s.py + 16; if (feet < s.minFeet) s.minFeet = feet;
        const meters = Math.max(0, Math.floor((START_Y - s.minFeet) / 12)); s.points = meters + s.lastKill;
        // PORTALE FINALE: appare a 15m dall'obiettivo, si entra solo toccandolo
        if (meters >= cfg.goal - 15 && !s.portalActive) { s.portalActive = true; setLevelBanner("IL PORTALE È APERTO — ENTRA!"); s.bannerT = 2; sfx("ding"); }
        if (s.portalActive && !s.won && !s.dead) {
          const pc = portalColorFor(cfg.id);
          const halfW = cfg.id === 20 ? 70 : cfg.id >= 21 ? 78 : 55; const halfH = cfg.id === 20 ? 80 : cfg.id >= 21 ? 88 : 65;
          const distP = Math.hypot((s.px + 8) - s.portalX, (s.py + 8) - s.portalY);
          const near = distP < 60;
          // Pixel che escono dal buco in continuazione: 8-12/s, raddoppiano vicino al portale.
          s.portalEmitAcc += dtRaw * (near ? 22 : 11);
          while (s.portalEmitAcc >= 1) {
            s.portalEmitAcc -= 1;
            const ang = Math.random() * Math.PI * 2;
            const spd = (0.6 + Math.random() * 2.2) * (near ? 1.6 : 1);
            const roll = Math.random();
            if (roll < 0.12) s.particles.push({ x: s.portalX + (Math.random() - 0.5) * 20, y: s.portalY + (Math.random() - 0.5) * 20, vx: Math.cos(ang) * spd * 0.6, vy: Math.sin(ang) * spd * 0.6 - 0.8, life: 0.6 + Math.random() * 0.4, max: 1, color: "#ffffff", size: 6, rot: Math.random() * Math.PI, spin: (Math.random() - 0.5) * 0.4, kind: "star", split: false });
            else if (roll < 0.24) s.particles.push({ x: s.portalX, y: s.portalY, vx: (Math.random() - 0.5) * 0.8, vy: -0.6 - Math.random() * 0.8, life: 0.9 + Math.random() * 0.5, max: 1.4, color: Math.random() < 0.5 ? "#ffffff" : "#67e8f9", size: 3 + Math.random() * 3, rot: 0, spin: 0, kind: "bubble", split: false });
            else s.particles.push({ x: s.portalX + (Math.random() - 0.5) * halfW * 0.7, y: s.portalY + (Math.random() - 0.5) * halfH * 0.7, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd, life: 0.8 + Math.random() * 0.7, max: 1.5, color: Math.random() < 0.4 ? pc : Math.random() < 0.5 ? "#ffffff" : "#00e5ff", size: [4, 6, 8][Math.floor(Math.random() * 3)], rot: Math.random() * Math.PI, spin: (Math.random() - 0.5) * 0.5, kind: "pixel", split: Math.random() < 0.3 });
          }
          // Anelli concentrici che si espandono dal portale ogni 1s.
          s.portalRingT += dtRaw;
          if (s.portalRingT >= 1) { s.portalRingT = 0; s.particles.push({ x: s.portalX, y: s.portalY, vx: 0, vy: 0, life: 0.8, max: 0.8, color: pc, size: 72, rot: 0, spin: 0, kind: "ring", split: false }); }
          // BARRIERA ENERGETICA: non si può superare il portale salendo di più.
          const barrierY = s.portalY - 10;
          const pCx = s.px + 8, pCy = s.py + 8;
          if (pCy < barrierY && Math.abs(pCx - s.portalX) >= halfW) {
            s.py = barrierY - 8; s.vy = 5; s.vx *= 0.4; s.grapplePhase = "idle"; s.grappleCd = 0.25; s.barrierFlash = 0.3; s.shakeT = 0.12; sfx("bzz");
            for (let i = 0; i < 10; i++) s.particles.push({ x: pCx + (Math.random() - 0.5) * 30, y: barrierY, vx: (Math.random() - 0.5) * 4, vy: Math.random() * 2 + 0.5, life: 0.3 + Math.random() * 0.3, max: 0.6, color: Math.random() < 0.5 ? pc : "#ffd23d", size: 2 + Math.random() * 3, rot: 0, spin: 0, kind: "pixel", split: false });
            if (!s.barrierHintShown) { s.barrierHintShown = true; setLevelBanner("ENTRA NEL PORTALE!"); s.bannerT = 1.5; }
          }
          if (s.barrierFlash > 0) s.barrierFlash -= dtRaw;
          const overlap = Math.abs(pCx - s.portalX) < halfW && Math.abs(pCy - s.portalY) < halfH;
          if (overlap) {
            s.portalEntered = true; s.won = true; s.winT = 0; s.portalT = 0; s.portalExploded = false; s.vx = 0; s.vy = 0; s.grapplePhase = "idle"; s.flashT = 0.18; s.shocks.push({ x: s.portalX, y: s.portalY, t: 0, max: 0.6 }); sfx("whoosh"); sfx("portal"); setLevelBanner("NEL PORTALE!");
            // Esplosione finale: 80 pixel che escono tutti insieme dal buco e si disperdono.
            for (let i = 0; i < 80; i++) { const a = (i / 80) * Math.PI * 2 + Math.random() * 0.3; const sp = 1.5 + Math.random() * 3.5; s.particles.push({ x: s.portalX, y: s.portalY, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 0.5, life: 0.8 + Math.random() * 0.7, max: 1.5, color: [pc, "#ffffff", "#00e5ff", "#ffd23d"][i % 4], size: [4, 6, 8][i % 3], rot: Math.random() * Math.PI, spin: (Math.random() - 0.5) * 0.6, kind: "pixel", split: false }); }
          }
        }
        const diff = difficultyFor(meters, cfg);
        const ms = Math.floor(meters / 50);
        if (ms > s.lastMilestone && meters > 0) { s.lastMilestone = ms; sfx("milestone"); for (let i = 0; i < 16; i++) s.particles.push({ x: s.px + 8, y: s.py + 8, vx: (Math.random() - 0.5) * 3, vy: -Math.random() * 2, life: 0.6, max: 0.6, color: i % 2 ? "#ffd23d" : cfg.particle, size: 2 }); }
        if (s.floorWait > 0) s.floorWait -= dtRaw;
        else { let spd = cfg.floorSpeed; if (s.idleT > 1) spd *= 1.3; if (s.idleT > 2) spd *= 1 + Math.min(0.6, (s.idleT - 2) * 0.15); s.floorY -= spd * dtRaw; }
        if (meters >= cfg.goal && !s.dead && !s.won) { if (s.floorY < s.finalY + 20) s.floorY = s.finalY + 20; }
        const floorDist = s.floorY - feet;
        if (floorDist < 80 && floorDist > 0) { s.alarmT += dtRaw; const interval = clamp(floorDist / 80, 0.2, 1) * 0.7; if (s.alarmT >= interval) { s.alarmT = 0; sfx("alarm"); } } else s.alarmT = 0;
        const spawnFrom = cfg.id === 1 ? 20 : 15;
        const enemyBoost = cfg.id >= 15 ? 1.3 : cfg.id === 20 ? 1.5 : 1;
        if (meters >= spawnFrom) {
          s.spawnT -= dtRaw;
          if (s.spawnT <= 0 && s.enemies.length + s.telegraphs.length < diff.maxEnemies) {
            s.spawnT = diff.enemyInterval; let type: "hunter" | "gunner" = "hunter";
            if (cfg.id >= 3) { const hasGunner = s.enemies.some(e => e.type === "gunner") || s.telegraphs.some(t => t.type === "gunner"); type = !hasGunner && Math.random() < 0.45 ? "gunner" : "hunter"; }
            let tx = 135 + (Math.random() * 60 - 30);
            const above = s.platforms.filter(p => p.gone <= 0 && p.y !== s.finalY && p.y < s.py && p.y > s.cameraY - 60).sort((a, b) => b.y - a.y)[0];
            if (above) tx = clamp(above.x, 60, 210);
            s.telegraphs.push({ x: tx, y: s.cameraY - 20, type, t: 0.5 });
          }
        }
        for (const t of s.telegraphs) t.t -= dtRaw;
        for (const t of s.telegraphs.filter(t => t.t <= 0)) {
          const plat = s.platforms.filter(p => p.gone <= 0 && p.y !== s.finalY && Math.abs(p.x - t.x) < 70 && p.y > s.cameraY - 40 && p.y < s.cameraY + 220).sort((a, b) => Math.abs(a.y - (s.cameraY + 60)) - Math.abs(b.y - (s.cameraY + 60)))[0];
          const ex = plat ? clamp(t.x, plat.x - plat.w / 2 + 12, plat.x + plat.w / 2 - 12) : t.x; const ey = plat ? plat.y - 16 : t.y;
          if (t.type === "hunter") s.enemies.push({ x: ex, y: ey, type: "hunter", t: 0, vx: 0, vy: 0, state: "hover", stateT: 0, homeX: ex, homeY: ey, laserAngle: 0, laserOn: false, fireT: 0 });
          else s.enemies.push({ x: ex, y: ey, type: "gunner", t: 0, vx: 0, vy: 0, state: "idle", stateT: 0, homeX: ex, homeY: ey, laserAngle: 0, laserOn: false, fireT: 0 });
        }
        s.telegraphs = s.telegraphs.filter(t => t.t > 0);
        for (const e of s.enemies) {
          e.t += dtRaw;
          if (e.type === "hunter") {
            const distP = Math.hypot((s.px + 8) - (e.x + 10), (s.py + 8) - (e.y + 8));
            if (e.state === "hover") { e.y = e.homeY + Math.sin(e.t * 3) * 3; e.x += clamp(e.homeX - e.x, -0.4, 0.4) * step * 0.4; if (distP < 90) { e.state = "charge"; e.stateT = 0.4; s.surpriseT = 0.7; } }
            else if (e.state === "charge") { e.stateT -= dtRaw; if (e.stateT <= 0) { e.state = "leap"; e.vx = clamp(((s.px + 8) - (e.x + 10)) * 0.07, -3.6, 3.6) * enemyBoost; e.vy = -6.2 * enemyBoost; for (let i = 0; i < 6; i++) s.particles.push({ x: e.x + 10, y: e.y + 8, vx: -e.vx * 0.5 + (Math.random() - 0.5) * 2, vy: 1 + Math.random() * 2, life: 0.3, max: 0.3, color: "#ff2a85", size: 2 }); } }
            else if (e.state === "leap") { e.vy += 0.45 * step; e.x += e.vx * step; e.y += e.vy * step; e.x = clamp(e.x, 18, 232); if (Math.random() < 0.7) s.particles.push({ x: e.x + 10, y: e.y + 8, vx: (Math.random() - 0.5), vy: (Math.random() - 0.5), life: 0.28, max: 0.28, color: "#ff2a85", size: 2 }); if (e.vy > 0 && e.y >= e.homeY) { e.y = e.homeY; e.state = "recover"; e.stateT = 0.6; } }
            else if (e.state === "recover") { e.stateT -= dtRaw; if (e.stateT <= 0) e.state = "hover"; }
          } else {
            e.x = e.homeX; e.y = e.homeY; const ang = Math.atan2((s.py + 8) - (e.y + 8), (s.px + 8) - (e.x + 10)); const distP = Math.hypot((s.px + 8) - (e.x + 10), (s.py + 8) - (e.y + 8));
            if (e.state === "idle") { e.laserAngle = ang; if (distP < 175) { e.state = "charge"; e.stateT = 0.5 / enemyBoost; } }
            else if (e.state === "charge") { e.laserAngle = ang; e.stateT -= dtRaw; if (e.stateT <= 0) { e.state = "fire"; e.fireT = 0.6; e.laserOn = true; sfx("laser"); } }
            else if (e.state === "fire") { e.fireT -= dtRaw; if (e.fireT <= 0) { e.state = "cool"; e.stateT = 1.4 / enemyBoost; e.laserOn = false; } }
            else if (e.state === "cool") { e.stateT -= dtRaw; if (e.stateT <= 0) e.state = "idle"; }
          }
        }
        s.enemies = s.enemies.filter(e => e.y < s.cameraY + 560);
        const deadEnemies = new Set<Enemy>();
        for (const e of s.enemies) {
          const overlapX = Math.abs((e.x + 10) - (s.px + 8)) < 18; const overlapY = Math.abs((e.y + 8) - (s.py + 8)) < 17; if (!overlapX || !overlapY) continue;
          const stomp = s.vy > 0 && (feet - e.y) > -2 && (feet - e.y) < 18;
          if (stomp) { deadEnemies.add(e); s.lastKill += 50; s.points = meters + s.lastKill; s.vy = -9; s.grounded = false; sfx("boom"); const cols = e.type === "hunter" ? ["#ffffff", "#2a1a4a", "#ff2a85", "#c9b8ff"] : ["#ff1a1a", "#2a2a2a", "#ff6a3d", "#fff2f2"]; for (let i = 0; i < 18; i++) s.particles.push({ x: e.x + 10, y: e.y + 8, vx: (Math.random() - 0.5) * 5, vy: -Math.random() * 4 - 0.5, life: 0.6, max: 0.6, color: cols[i % cols.length], size: 2 + (i % 3) }); continue; }
          if (s.invuln <= 0) { s.hp -= 1; s.invuln = 1.2; s.hitT = 0.3; sfx("hit"); s.vy = -7; s.vx = (s.px + 8 < e.x + 10 ? -2.5 : 2.5); if (s.hp <= 0) { s.dead = true; s.deathCause = "hp"; } }
        }
        for (const e of s.enemies) {
          if (e.type !== "gunner" || !e.laserOn) continue;
          const x0 = e.x + 10, y0 = e.y + 8; const x1 = x0 + Math.cos(e.laserAngle) * 110, y1 = y0 + Math.sin(e.laserAngle) * 110;
          const px = s.px + 8, py = s.py + 8; const dx = x1 - x0, dy = y1 - y0; const len2 = dx * dx + dy * dy || 1; const tt = clamp(((px - x0) * dx + (py - y0) * dy) / len2, 0, 1); const dist = Math.hypot(px - (x0 + dx * tt), py - (y0 + dy * tt));
          if (dist < 8 && s.invuln <= 0) { s.hp -= 1; s.invuln = 1.2; s.hitT = 0.3; sfx("hit"); s.vy = -6; if (s.hp <= 0) { s.dead = true; s.deathCause = "hp"; } }
        }
        if (deadEnemies.size) s.enemies = s.enemies.filter(e => !deadEnemies.has(e));
        const spawnedPortal: Particle[] = [];
        for (const p of s.particles) { p.x += p.vx * step; p.y += p.vy * step; if (p.kind !== "ring") p.vy += 0.1 * step; if (p.rot !== undefined) p.rot += (p.spin || 0) * step; p.life -= dtRaw; if (p.life <= 0 && p.split && p.kind === "pixel") { for (let k = 0; k < 3; k++) spawnedPortal.push({ x: p.x, y: p.y, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3, life: 0.35, max: 0.35, color: p.color, size: 2, rot: Math.random() * Math.PI, spin: (Math.random() - 0.5) * 0.5, kind: "pixel", split: false }); } }
        if (spawnedPortal.length) s.particles.push(...spawnedPortal);
        s.particles = s.particles.filter(p => p.life > 0);
        for (const gh of s.ghosts) gh.life -= dtRaw; s.ghosts = s.ghosts.filter(gh => gh.life > 0);
        for (const sh of s.shocks) sh.t += dtRaw; s.shocks = s.shocks.filter(sh => sh.t < sh.max);
        if (feet >= s.floorY) { s.dead = true; s.deathCause = "floor"; sfx("floor"); for (let i = 0; i < 18; i++) s.particles.push({ x: s.px + 8, y: s.py + 8, vx: (Math.random() - 0.5) * 5, vy: (Math.random() - 0.5) * 5, life: 0.6, max: 0.6, color: i % 2 ? "#ff5400" : "#ffd23d", size: 3 }); }
        else if (s.py - s.cameraY > H + 20) { s.dead = true; if (!s.deathCause) s.deathCause = "fall"; }
        if (s.dead && !s.deathDone) { if (s.deathT <= 0) { sfx("boom"); for (let i = 0; i < 22; i++) s.particles.push({ x: s.px + 8, y: s.py + 8, vx: (Math.random() - 0.5) * 5, vy: -Math.random() * 4 - 1, life: 0.7, max: 0.7, color: i % 3 === 0 ? "#ffffff" : i % 3 === 1 ? "#ff5400" : "#1a0a00", size: 2 + (i % 3) }); } }
        setHud(h => {
          const nm = meters; const nFloor = Math.round(s.floorY - feet); const nWind = s.windT > 0, nTongue = s.tongueWarn > 0; const nGrapple = clamp(1 - Math.max(0, s.grappleCd) / 0.5, 0, 1);
          if (h.m === nm && h.hp === s.hp && h.points === s.points && h.level === s.level && Math.abs(h.floorDist - nFloor) < 4 && h.straight === s.straight && h.windOn === nWind && h.windDir === s.windDir && h.tongueWarn === nTongue && Math.abs(h.grapple - nGrapple) < 0.03 && h.grappleReady === (s.grappleCd <= 0)) return h;
          return { ...h, m: nm, hp: s.hp, points: s.points, level: s.level, levelLabel: cfg.name, floorDist: nFloor, straight: s.straight, windOn: nWind, windDir: s.windDir, tongueWarn: nTongue, grapple: nGrapple, grappleReady: s.grappleCd <= 0, goal: cfg.goal };
        });
      }
      if (playing && s.won && !s.dead) {
        s.winT += dtRaw; s.time += dtRaw; s.portalT = s.winT;
        for (const p of s.particles) { p.x += p.vx * step; p.y += p.vy * step; p.vy += 0.1 * step; p.life -= dtRaw; }
        s.particles = s.particles.filter(p => p.life > 0);
        if (s.portalEntered && !s.portalExploded && s.winT >= 0.65) { s.portalExploded = true; const pc = portalColorFor(cfg.id); for (let i = 0; i < 28; i++) s.particles.push({ x: s.portalX, y: s.portalY, vx: (Math.random() - 0.5) * 6, vy: (Math.random() - 0.5) * 6, life: 0.7, max: 0.7, color: [pc, "#ffffff", "#ffd23d", pc][i % 4], size: 2 + (i % 3) }); sfx("boom"); }
        if (s.winT >= 1.0) {
          const finalM = Math.max(0, Math.floor((START_Y - s.minFeet) / 12));
          const stars = s.hp >= 3 && s.time < 120 ? 3 : s.hp >= 2 ? 2 : 1;
          sfx("fanfare");
          setWinStars(stars);
          setIsWin(true); if (cfg.id === 20) { setIsLegend(true); sfx("level"); }
          setPhase("over"); setHud(h => ({ ...h, m: finalM, hp: s.hp, points: s.points }));
          saveBest(finalM, cfg.id, true);
        }
      }
      if (playing && s.dead && !s.deathDone) {
        s.deathT += dtRaw; s.time += dtRaw;
        for (const p of s.particles) { p.x += p.vx * step; p.y += p.vy * step; p.vy += 0.1 * step; p.life -= dtRaw; }
        s.particles = s.particles.filter(p => p.life > 0);
        if (s.deathT >= 0.8) {
          s.deathDone = true; const finalM = Math.max(0, Math.floor((START_Y - s.minFeet) / 12));
          sfx("death");
          setDeathCause(s.deathCause || "fall"); if (cfg.id === 5 && finalM >= 100) { setIsLegend(true); sfx("level"); }
          setPhase("over"); setHud(h => ({ ...h, m: finalM, hp: s.hp, points: s.points })); saveBest(finalM, cfg.id);
        }
      }

      // ---------- DISEGNO ----------
      ctx.imageSmoothingEnabled = false;
      // Sfondo: gradiente verticale ricco per mondo + god rays + vignetta
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, cfg.bg); grad.addColorStop(0.55, cfg.sky); grad.addColorStop(1, cfg.floor);
      ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.globalAlpha = 0.10; ctx.fillStyle = "#ffffff";
      const rayX = ((s.time * 12) % 340) - 40;
      ctx.beginPath(); ctx.moveTo(rayX, 0); ctx.lineTo(rayX + 70, 0); ctx.lineTo(rayX + 20, H); ctx.lineTo(rayX - 50, H); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(rayX + 140, 0); ctx.lineTo(rayX + 180, 0); ctx.lineTo(rayX + 120, H); ctx.lineTo(rayX + 80, H); ctx.closePath(); ctx.fill();
      ctx.restore();
      // Nebbia che si muove (strato medio trasparente)
      ctx.save(); ctx.globalAlpha = 0.08; ctx.fillStyle = cfg.particle;
      const fogY = ((s.time * 9) % 260) - 60; ctx.fillRect(0, fogY, W, 46); ctx.fillRect(0, fogY + 170, W, 36); ctx.restore();
      ctx.save();
      if (s.shakeT > 0) ctx.translate((Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6);
      // Parallasse: 2 strati decorativi per mondo
      const off1 = Math.floor(s.cameraY * 0.25) % 600, off2 = Math.floor(s.cameraY * 0.55) % 600;
      ctx.fillStyle = cfg.sky;
      // Strato lontano: puntini / stelle / bolle
      for (let i = 0; i < 18; i++) { const sx = (i * 67) % W, sy = ((i * 43) % 600 - off1 + 600) % 600 - 60; ctx.fillRect(sx, sy, 2, 2); }
      // Strato vicino: decor per mondo
      for (let i = 0; i < 7; i++) {
        const bx = (i * 41 + 8) % W, by = ((i * 91) % 600 - off2 + 600) % 600 - 40;
        if (cfg.id === 1) { ctx.fillStyle = "rgba(168,85,247,0.35)"; ctx.beginPath(); ctx.moveTo(bx, by + 18); ctx.lineTo(bx + 7, by); ctx.lineTo(bx + 14, by + 18); ctx.closePath(); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.fillRect(bx + 5, by + 4, 3, 3); }
        else if (cfg.id === 2 || cfg.id === 7 || cfg.id === 17) { ctx.fillStyle = "rgba(255,84,0,0.28)"; ctx.fillRect(bx, by, 10, 14); ctx.fillStyle = "rgba(255,154,61,0.5)"; ctx.fillRect(bx + 3, by + 2, 4, 4); }
        else if (cfg.id === 3 || cfg.id === 10) { ctx.fillStyle = "rgba(74,222,128,0.35)"; ctx.fillRect(bx, by, 3, 22); ctx.fillRect(bx - 6, by + 4, 16, 3); ctx.fillStyle = "rgba(254,240,138,0.6)"; ctx.fillRect(bx + 8, by + 8, 3, 3); }
        else if (cfg.id === 4 || cfg.id === 18) { ctx.fillStyle = "rgba(125,211,252,0.45)"; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + 6, by + 18); ctx.lineTo(bx + 12, by); ctx.closePath(); ctx.fill(); }
        else if (cfg.id === 5) { ctx.fillStyle = "rgba(250,204,21,0.3)"; ctx.beginPath(); ctx.arc(bx + 7, by + 10, 9, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(bx + 5, by + 10, 4, 12); }
        else if (cfg.id === 6) { ctx.fillStyle = "rgba(255,42,133,0.28)"; ctx.fillRect(bx, by, 16, 26); ctx.fillStyle = "rgba(0,229,255,0.5)"; ctx.fillRect(bx + 2, by + 4, 12, 2); ctx.fillRect(bx + 2, by + 9, 8, 2); }
        else if (cfg.id === 8 || cfg.id === 13) { ctx.fillStyle = "rgba(125,211,252,0.35)"; ctx.beginPath(); ctx.arc(bx + 7, by + 10, 7, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 9) { ctx.fillStyle = "rgba(255,255,255,0.6)"; ctx.fillRect(bx, by, 2, 2); ctx.fillStyle = "rgba(168,85,247,0.4)"; ctx.beginPath(); ctx.arc(bx + 18, by + 12, 10, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 11) { ctx.fillStyle = "rgba(250,204,21,0.35)"; ctx.fillRect(bx, by, 6, 26); ctx.fillRect(bx - 3, by, 12, 4); ctx.fillRect(bx - 3, by + 22, 12, 4); }
        else if (cfg.id === 12) { ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.arc(bx, by + 10, 12, 0, Math.PI * 2); ctx.arc(bx + 14, by + 10, 12, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 14) { ctx.fillStyle = "rgba(245,158,11,0.35)"; ctx.fillRect(bx, by + 12, 22, 3); ctx.fillRect(bx + 4, by + 4, 6, 8); }
        else if (cfg.id === 15) { ctx.fillStyle = "rgba(139,92,246,0.35)"; ctx.fillRect(bx, by, 10, 30); ctx.beginPath(); ctx.moveTo(bx - 2, by); ctx.lineTo(bx + 5, by - 8); ctx.lineTo(bx + 12, by); ctx.closePath(); ctx.fill(); }
        else if (cfg.id === 16) { ctx.fillStyle = "rgba(248,113,113,0.4)"; ctx.beginPath(); ctx.arc(bx + 7, by + 8, 9, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(bx + 4, by + 14, 6, 10); ctx.fillStyle = "#fff"; ctx.fillRect(bx + 3, by + 4, 3, 3); ctx.fillRect(bx + 9, by + 8, 3, 3); }
        else if (cfg.id === 19) { ctx.fillStyle = "rgba(34,211,238,0.3)"; ctx.fillRect(bx, by, 18, 3); ctx.fillRect(bx, by + 8, 18, 3); ctx.fillRect(bx + 8, by, 3, 18); }
        else if (cfg.id === 20) { ctx.fillStyle = "rgba(255,45,85,0.35)"; ctx.beginPath(); ctx.arc(bx + 7, by + 10, 9, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.beginPath(); ctx.arc(bx + 7, by + 10, 4, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 21) { const rot = s.time * 0.6 + i; ctx.save(); ctx.translate(bx + 7, by + 10); ctx.rotate(rot); ctx.fillStyle = "rgba(184,115,51,0.4)"; ctx.fillRect(-10, -10, 20, 20); ctx.fillStyle = "rgba(212,160,23,0.5)"; ctx.fillRect(-13, -3, 26, 6); ctx.fillRect(-3, -13, 6, 26); ctx.fillStyle = "rgba(255,183,3,0.6)"; ctx.fillRect(-3, -3, 6, 6); ctx.restore(); ctx.fillStyle = "rgba(255,255,255,0.25)"; ctx.fillRect(bx + 16, by + 2, 4, 4); }
        else if (cfg.id === 22) { ctx.fillStyle = "rgba(10,30,20,0.6)"; ctx.fillRect(bx, by, 4, 26); ctx.fillRect(bx + 12, by + 6, 4, 20); ctx.fillStyle = "rgba(0,255,136,0.5)"; ctx.beginPath(); ctx.arc(bx + 7, by + 6, 7, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "rgba(0,255,255,0.55)"; ctx.fillRect(bx + 10, by + 12, 3, 3); }
      }
      // Terzo strato parallasse: dettagli per mondo (stalattiti, radici, funghi, ghiaccioli, cactus, grattacieli, nuvole, coralli, stelle, pianeti, liane, colonne, torce, bolle, pesci)
      const off3 = Math.floor(s.cameraY * 0.8) % 600;
      for (let i = 0; i < 5; i++) { const dx3 = (i * 53 + 10) % W, dy3 = ((i * 127) % 600 - off3 + 600) % 600 - 30;
        if (cfg.id === 1 || cfg.id === 9) { ctx.fillStyle = "rgba(168,85,247,0.5)"; ctx.beginPath(); ctx.moveTo(dx3, dy3); ctx.lineTo(dx3 + 6, dy3 + 16); ctx.lineTo(dx3 + 12, dy3); ctx.closePath(); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillRect(dx3 + 5, dy3 + 4, 2, 2); }
        else if (cfg.id === 2 || cfg.id === 7 || cfg.id === 17) { ctx.fillStyle = "rgba(20,5,5,0.65)"; ctx.fillRect(dx3, dy3, 14, 30); ctx.fillStyle = "#ff5400"; ctx.fillRect(dx3 + 2, dy3 + 26, 10, 3); }
        else if (cfg.id === 3 || cfg.id === 10) { ctx.fillStyle = "rgba(34,197,94,0.5)"; ctx.fillRect(dx3 + 5, dy3, 3, 28); ctx.fillRect(dx3, dy3 + 6, 13, 3); ctx.fillStyle = "#facc15"; ctx.fillRect(dx3 + 9, dy3 + 12, 3, 3); }
        else if (cfg.id === 4 || cfg.id === 18) { ctx.fillStyle = "rgba(186,230,253,0.55)"; ctx.beginPath(); ctx.moveTo(dx3, dy3); ctx.lineTo(dx3 + 5, dy3 + 20); ctx.lineTo(dx3 + 10, dy3); ctx.closePath(); ctx.fill(); }
        else if (cfg.id === 5) { ctx.fillStyle = "rgba(250,204,21,0.5)"; ctx.fillRect(dx3 + 4, dy3, 4, 18); ctx.fillRect(dx3 + 1, dy3 + 4, 10, 2); ctx.fillStyle = "#ff5400"; ctx.fillRect(dx3 + 5, dy3 + 8, 2, 2); }
        else if (cfg.id === 6 || cfg.id === 19) { ctx.fillStyle = "rgba(34,211,238,0.35)"; ctx.fillRect(dx3, dy3, 16, 34); ctx.fillStyle = "#ffd23d"; ctx.fillRect(dx3 + 2, dy3 + 4, 4, 4); ctx.fillRect(dx3 + 10, dy3 + 10, 4, 4); }
        else if (cfg.id === 8 || cfg.id === 13) { ctx.fillStyle = "rgba(125,211,252,0.5)"; ctx.beginPath(); ctx.arc(dx3 + 7, dy3 + 10, 5, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#ff7ad9"; ctx.fillRect(dx3 + 12, dy3 + 6, 8, 3); }
        else if (cfg.id === 11) { ctx.fillStyle = "rgba(250,204,21,0.45)"; ctx.fillRect(dx3 + 4, dy3, 5, 30); ctx.fillRect(dx3, dy3, 13, 4); ctx.fillStyle = "#ff5400"; ctx.fillRect(dx3 + 5, dy3 + 6, 3, 4); }
        else if (cfg.id === 12) { ctx.fillStyle = "rgba(255,255,255,0.45)"; ctx.beginPath(); ctx.arc(dx3, dy3 + 10, 10, 0, Math.PI * 2); ctx.arc(dx3 + 12, dy3 + 10, 10, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 14) { ctx.fillStyle = "rgba(245,158,11,0.5)"; ctx.fillRect(dx3 + 5, dy3, 4, 24); ctx.fillStyle = "#78350f"; ctx.fillRect(dx3, dy3 + 20, 14, 4); }
        else if (cfg.id === 15) { ctx.fillStyle = "rgba(139,92,246,0.45)"; ctx.fillRect(dx3, dy3, 12, 32); ctx.fillStyle = "#ffd23d"; ctx.fillRect(dx3 + 4, dy3 + 4, 4, 4); }
        else if (cfg.id === 16) { ctx.fillStyle = "rgba(248,113,113,0.5)"; ctx.beginPath(); ctx.arc(dx3 + 7, dy3 + 8, 8, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillRect(dx3 + 4, dy3 + 5, 2, 2); ctx.fillRect(dx3 + 9, dy3 + 8, 2, 2); }
        else if (cfg.id === 20) { ctx.fillStyle = "rgba(255,45,85,0.4)"; ctx.beginPath(); ctx.arc(dx3 + 7, dy3 + 10, 8, 0, Math.PI * 2); ctx.fill(); }
        else if (cfg.id === 21) { ctx.fillStyle = "rgba(184,115,51,0.65)"; ctx.fillRect(dx3, dy3 + 10, 16, 3); ctx.fillRect(dx3 + 4, dy3 + 4, 3, 14); ctx.fillStyle = "rgba(255,183,3,0.7)"; ctx.fillRect(dx3 + 2, dy3 + 2, 3, 3); ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.fillRect(dx3 + 10, dy3 - 2, 4, 4); }
        else if (cfg.id === 22) { ctx.fillStyle = "rgba(90,42,138,0.6)"; ctx.fillRect(dx3 + 5, dy3, 3, 26); ctx.fillStyle = "rgba(0,255,136,0.6)"; ctx.fillRect(dx3, dy3 + 10, 14, 3); ctx.fillStyle = "rgba(163,255,0,0.7)"; ctx.fillRect(dx3 + 8, dy3 + 4, 3, 3); }
      }
      if (cfg.id === 4 && Math.sin(s.time * 1.3) > 0.96) { ctx.fillStyle = "rgba(0,229,255,0.18)"; ctx.fillRect(0, 0, W, H); }
      if (cfg.id === 18) { const aur = Math.sin(s.time * 0.8) * 20; ctx.fillStyle = "rgba(52,211,153,0.12)"; ctx.fillRect(0, 60 + aur, W, 60); ctx.fillStyle = "rgba(96,165,250,0.10)"; ctx.fillRect(0, 90 + aur, W, 50); }
      if (cfg.id === 20) { ctx.fillStyle = "rgba(168,85,247,0.08)"; ctx.fillRect(0, H - 140, W, 140); }
      ctx.fillStyle = "#0d1321"; ctx.fillRect(0, 0, 16, H); ctx.fillRect(W - 16, 0, 16, H);
      ctx.fillStyle = "#161f33"; ctx.fillRect(14, 0, 3, H); ctx.fillRect(W - 17, 0, 3, H);
      ctx.fillStyle = "#1d2947";
      for (let yy = -((Math.floor(s.cameraY / 40) * 40 - s.cameraY) % 40); yy < H; yy += 40) { ctx.fillRect(4, yy, 8, 3); ctx.fillRect(W - 12, yy, 8, 3); }
      for (let py = Math.floor(s.cameraY / 60) * 60 - 60; py < s.cameraY + H + 60; py += 60) {
        const y = py - s.cameraY; if (y < -20 || y > H + 20) continue;
        const isTarget = (s.grapplePhase === "pull" || s.grapplePhase === "hang") && Math.abs(s.grappleTargetY - py) < 30;
        const isAim = s.grapplePhase === "aim" && s.grappleAimT >= 0.1 && s.grappleAimHas && Math.abs(s.grappleAimTargetY - py) < 30;
        const glow = isTarget || isAim; ctx.fillStyle = glow ? "#ffffff" : "#00e5ff"; ctx.fillRect(2, y - 7, 12, 14); ctx.fillRect(W - 14, y - 7, 12, 14);
        ctx.fillStyle = glow ? "#00e5ff" : "#0b2a3a"; ctx.fillRect(5, y - 3, 6, 6); ctx.fillRect(W - 11, y - 3, 6, 6);
      }
      // Pareti bonus: 21 tubi di rame + manometri, 22 liane + funghi.
      if (cfg.id === 21 || cfg.id === 22) {
        for (let wy = -((Math.floor(s.cameraY / 48) * 48 - s.cameraY) % 48); wy < H; wy += 48) {
          if (cfg.id === 21) {
            ctx.fillStyle = "#b87333"; ctx.fillRect(1, wy, 5, 48); ctx.fillRect(W - 6, wy, 5, 48);
            ctx.fillStyle = "#d4a017"; ctx.fillRect(2, wy + 6, 3, 3); ctx.fillRect(W - 5, wy + 6, 3, 3); ctx.fillRect(2, wy + 38, 3, 3); ctx.fillRect(W - 5, wy + 38, 3, 3);
            const needle = Math.sin(s.time * 3 + wy) * 2; ctx.fillStyle = "#ffb703"; ctx.beginPath(); ctx.arc(8, wy + 24, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#1a0f08"; ctx.fillRect(7, wy + 23, 2, 2); ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(8, wy + 24); ctx.lineTo(8 + needle, wy + 20); ctx.stroke();
            ctx.fillStyle = "#ffb703"; ctx.beginPath(); ctx.arc(W - 8, wy + 24, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#1a0f08"; ctx.fillRect(W - 9, wy + 23, 2, 2); ctx.strokeStyle = "#ffffff"; ctx.beginPath(); ctx.moveTo(W - 8, wy + 24); ctx.lineTo(W - 8 - needle, wy + 20); ctx.stroke();
          } else {
            ctx.fillStyle = "#5a2a8a"; ctx.fillRect(2, wy, 4, 48); ctx.fillRect(W - 6, wy, 4, 48);
            ctx.fillStyle = "#00ff88"; ctx.fillRect(3, wy + 8, 2, 2); ctx.fillRect(W - 5, wy + 30, 2, 2); ctx.fillRect(3, wy + 34, 3, 3); ctx.fillRect(W - 6, wy + 10, 3, 3);
            ctx.fillStyle = "#00ffff"; ctx.beginPath(); ctx.arc(8, wy + 16, 4, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(7, wy + 20, 2, 5);
            ctx.fillStyle = "#00ffff"; ctx.beginPath(); ctx.arc(W - 8, wy + 34, 4, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(W - 9, wy + 38, 2, 5);
          }
        }
      }
      const sy = (wy: number) => wy - s.cameraY;
      // PIATTAFORME — 5 famiglie, pixel art via canvas
      const bpAll = brickPaletteFor(cfg);
      for (const p of s.platforms) {
        let y = sy(p.y); if (y < -20 || y > H + 20) continue;
        const breaking = (p.kind === "fragile" || p.kind === "timed") && p.flash > 0;
        const breakStage = !breaking ? 0 : p.flash > 0.45 ? 1 : p.flash > 0.2 ? 2 : 3;
        let drawX = p.x; if (breakStage >= 2) drawX += (Math.random() - 0.5) * 3;
        else if (p.flash > 0) drawX += (Math.random() - 0.5) * 1.5;
        let alpha = 1;
        if (p.kind === "ghost") { if (!ghostVisible(p, s.time)) alpha = 0.15; else if (ghostBlink(p, s.time)) alpha = Math.sin(s.time * 30) > 0 ? 1 : 0.35; }
        else if (p.flash > 0) alpha = Math.sin(p.flash * 30) > 0 ? 1 : 0.45;
        ctx.globalAlpha = alpha;
        const bp = bpAll; const left = drawX - p.w / 2; const right = drawX + p.w / 2;
        const activated = p.activated > 0; const actGlow = activated ? bp.glow : bp.edge;
        // Ombra sotto + riflesso sopra la piattaforma
        ctx.fillStyle = "rgba(0,0,0,0.38)"; ctx.fillRect(left + 2, y + 12, p.w, 3);
        ctx.fillStyle = "rgba(255,255,255,0.18)"; ctx.fillRect(left + 2, y - 1, p.w - 4, 1);
        // Varianti per lunghezza: corta = 1 cristallo/dettaglio, lunga = 3
        const detailCount = p.w < 45 ? 1 : p.w < 75 ? 2 : 3;
        // Corpo base della famiglia
        ctx.fillStyle = bp.dark; ctx.fillRect(left - 1, y - 1, p.w + 2, 12);
        ctx.fillStyle = bp.base; ctx.fillRect(left, y, p.w, 10);
        if (bp.family === "A") {
          ctx.fillStyle = bp.dark; ctx.fillRect(left, y + 6, p.w, 4);
          ctx.fillStyle = bp.shard1; ctx.beginPath(); ctx.moveTo(left + 8, y); ctx.lineTo(left + 12, y - 6); ctx.lineTo(left + 16, y); ctx.closePath(); ctx.fill();
          ctx.fillStyle = bp.shard2; ctx.beginPath(); ctx.moveTo(right - 16, y); ctx.lineTo(right - 12, y - 5); ctx.lineTo(right - 8, y); ctx.closePath(); ctx.fill();
          ctx.fillStyle = bp.shard2; ctx.beginPath(); ctx.moveTo(drawX - 2, y + 10); ctx.lineTo(drawX + 2, y + 10); ctx.lineTo(drawX, y + 15); ctx.closePath(); ctx.fill();
          ctx.fillStyle = bp.accent; ctx.fillRect(left + 4, y + 3, 3, 3); ctx.fillRect(right - 7, y + 3, 3, 3);
        } else if (bp.family === "B") {
          ctx.fillStyle = "#0b0b14"; ctx.fillRect(left + 2, y + 6, p.w - 4, 3);
          ctx.fillStyle = bp.accent; ctx.fillRect(left + 4, y + 3, 6, 2); ctx.fillRect(right - 10, y + 3, 6, 2);
          ctx.fillStyle = bp.shard2; ctx.beginPath(); ctx.arc(drawX, y + 5, 3, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = bp.edge; ctx.fillRect(left + 2, y + 8, 3, 2); ctx.fillRect(right - 5, y + 8, 3, 2);
          ctx.fillStyle = "#ffffff"; ctx.fillRect(drawX - 1, y + 4, 2, 2);
        } else if (bp.family === "C") {
          ctx.fillStyle = "#0a0614"; ctx.fillRect(left, y + 2, p.w, 6);
          ctx.strokeStyle = bp.edge; ctx.lineWidth = 1; ctx.strokeRect(left + 1, y + 1, p.w - 2, 8);
          ctx.fillStyle = bp.glow; ctx.fillRect(left + 5, y + 3, 8, 2); ctx.fillRect(drawX - 4, y + 5, 8, 2); ctx.fillRect(right - 13, y + 3, 8, 2);
          ctx.fillStyle = bp.shard1; ctx.fillRect(left + 2, y + 2, 2, 2); ctx.fillRect(right - 4, y + 6, 2, 2);
        } else if (bp.family === "D") {
          ctx.fillStyle = bp.dark; ctx.fillRect(left, y + 5, p.w, 5);
          ctx.fillStyle = bp.crack; ctx.fillRect(left + 6, y + 7, 10, 2); ctx.fillRect(drawX - 2, y + 8, 14, 2); ctx.fillRect(right - 16, y + 6, 8, 2);
          ctx.fillStyle = bp.glow; ctx.fillRect(left + 8, y + 7, 3, 2); ctx.fillRect(drawX + 4, y + 8, 3, 2);
          ctx.fillStyle = "#000"; ctx.fillRect(left + 3, y + 2, 4, 3); ctx.fillRect(right - 8, y + 3, 3, 3);
        } else {
          ctx.fillStyle = bp.dark; ctx.fillRect(left, y + 6, p.w, 4);
          const pulse = 0.55 + 0.45 * Math.sin(s.time * 4 + p.x * 0.1);
          ctx.globalAlpha = alpha * pulse; ctx.fillStyle = bp.edge; ctx.fillRect(left, y + 1, p.w, 2); ctx.globalAlpha = alpha;
          ctx.fillStyle = bp.accent; ctx.fillRect(left + 6, y + 4, 2, 2); ctx.fillRect(drawX + 6, y + 4, 2, 2);
          if (bp.dots) { ctx.fillStyle = "#ffffff"; ctx.fillRect(left + 10, y + 4, 2, 2); ctx.fillRect(right - 12, y + 4, 2, 2); }
        }
        // Bordo superiore famiglia + bagliore ACTIVATED
        ctx.shadowColor = actGlow; ctx.shadowBlur = activated ? 12 : 6; ctx.fillStyle = activated ? bp.glow : bp.edge; ctx.fillRect(left, y, p.w, activated ? 3 : 2); ctx.shadowBlur = 0;
        if (activated) { ctx.globalAlpha = alpha * 0.35; ctx.fillStyle = bp.glow; ctx.fillRect(left - 2, y + 10, p.w + 4, 3); ctx.globalAlpha = alpha; if (bp.family === "D") { ctx.fillStyle = "#ffd23d"; ctx.beginPath(); ctx.moveTo(drawX - 6, y); ctx.lineTo(drawX - 3, y - 5); ctx.lineTo(drawX, y); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(drawX + 2, y); ctx.lineTo(drawX + 5, y - 5); ctx.lineTo(drawX + 8, y); ctx.closePath(); ctx.fill(); } }
        // Dettagli ripetuti in base alla lunghezza (cristalli / luci / chiodi)
        for (let di = 0; di < detailCount; di++) { const dx2 = left + (p.w * (di + 1)) / (detailCount + 1); ctx.fillStyle = bp.glow; ctx.fillRect(dx2 - 1, y + 2, 3, 2); ctx.fillStyle = bp.accent; ctx.fillRect(dx2, y + 5, 1, 2); }
        // Piattaforme bonus ATTORCIGLIATE / ONDULATE (hitbox rettangolare invariata, solo grafica).
        if (cfg.id === 21 || cfg.id === 22) {
          const steam = cfg.id === 21; const variant = Math.abs(Math.floor(p.y / 60)) % 4;
          const inner = steam ? "#2a0a2e" : "#5a2a8a"; const topC = steam ? "#ffb703" : "#00ff88"; const glowC = steam ? "#ff6b00" : "#00ffff";
          ctx.save(); ctx.shadowColor = glowC; ctx.shadowBlur = 8;
          ctx.fillStyle = inner; ctx.beginPath(); ctx.moveTo(left, y + 10); ctx.lineTo(left, y + 4);
          for (let wx = 0; wx <= p.w; wx += 6) { const wy = y + (variant === 0 ? Math.sin(wx * 0.25 + p.y) * 2 : variant === 1 ? Math.sin(wx * 0.35) * 3 : variant === 2 ? (wx % 12 < 6 ? 0 : 3) : Math.cos(wx * 0.2) * 2); ctx.lineTo(left + wx, wy); }
          ctx.lineTo(right, y + 10); ctx.closePath(); ctx.fill(); ctx.shadowBlur = 0;
          ctx.fillStyle = topC; ctx.fillRect(left, y + 1, p.w, 2); ctx.fillStyle = glowC; ctx.fillRect(left, y, 3, 3); ctx.fillRect(right - 3, y - 2, 3, 5); ctx.fillRect(drawX - 2, y + 3, 4, 2);
          if (!steam) { ctx.fillStyle = "#a3ff00"; ctx.fillRect(left + 8, y + 5, 2, 2); ctx.fillRect(right - 12, y + 5, 2, 2); ctx.fillRect(drawX + 8, y + 6, 2, 2); }
          if (p.kind === "gear") { const gr = s.time * 1.2 + p.x; ctx.save(); ctx.translate(drawX, y + 13); ctx.rotate(gr); ctx.fillStyle = "#b87333"; ctx.fillRect(-8, -8, 16, 16); ctx.fillStyle = "#d4a017"; ctx.fillRect(-11, -3, 22, 6); ctx.fillRect(-3, -11, 6, 22); ctx.fillStyle = "#1a0f08"; ctx.fillRect(-3, -3, 6, 6); ctx.restore(); }
          if (p.kind === "steam") { ctx.fillStyle = "rgba(255,255,255,0.85)"; ctx.fillRect(drawX - 8, y - 8, 6, 4); ctx.fillRect(drawX - 2, y - 11, 6, 4); ctx.fillRect(drawX + 4, y - 8, 6, 4); ctx.fillStyle = "#ffb703"; ctx.fillRect(drawX - 3, y - 3, 6, 2); }
          if (p.kind === "shroom") { const sc = 1 + 0.1 * Math.sin(s.time * 3 + p.x); ctx.save(); ctx.translate(drawX, y); ctx.scale(sc, sc); ctx.fillStyle = "#00ffff"; ctx.fillRect(-12, -8, 24, 8); ctx.fillStyle = "#ffffff"; ctx.fillRect(-8, -6, 3, 3); ctx.fillRect(2, -6, 3, 3); ctx.fillStyle = "#0a1a2e"; ctx.fillRect(-3, -1, 6, 3); ctx.restore(); }
          if (p.kind === "vine") { ctx.strokeStyle = "#00ff88"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(left, y + 2); ctx.quadraticCurveTo(drawX, y + 8, right, y + 2); ctx.stroke(); ctx.fillStyle = "#a3ff00"; ctx.fillRect(drawX - 2, y + 4, 4, 3); }
          ctx.restore();
        }
        // Checkpoint: cuore grande + bagliore
        if (p.checkpoint && !s.checkpointTaken) { ctx.save(); ctx.shadowColor = "#ff3b6b"; ctx.shadowBlur = 14; ctx.fillStyle = "#ff3b6b"; ctx.fillRect(drawX - 5, y - 14, 10, 8); ctx.fillStyle = "#ffffff"; ctx.fillRect(drawX - 3, y - 12, 2, 2); ctx.fillRect(drawX + 1, y - 12, 2, 2); ctx.restore(); ctx.fillStyle = "#ffd23d"; ctx.font = "bold 8px 'Space Grotesk',sans-serif"; ctx.textAlign = "center"; ctx.fillText("♥ CHECKPOINT", drawX, y - 18); }
        // Effetti per tipo, sopra la grafica della famiglia
        if (p.kind === "ghost") { ctx.fillStyle = "#67e8f9"; ctx.fillRect(drawX - 6, y + 4, 12, 2); }
        if (p.kind === "bounce") { ctx.fillStyle = "#4ade80"; ctx.fillRect(drawX - p.w / 4, y + 3, p.w / 2, 3); ctx.fillRect(drawX - 2, y + 5, 4, 3); }
        if (p.kind === "ice") { ctx.fillStyle = "rgba(255,255,255,0.65)"; ctx.fillRect(left + 2, y + 1, p.w - 4, 2); ctx.fillStyle = "#7dd3fc"; ctx.fillRect(left, y + 8, p.w, 2); }
        if (p.kind === "spikes") { ctx.fillStyle = "#ef4444"; for (let si = 0; si < 4; si++) { const sx = left + 4 + si * ((p.w - 8) / 3); ctx.beginPath(); ctx.moveTo(sx, y); ctx.lineTo(sx + 4, y - 7); ctx.lineTo(sx + 8, y); ctx.closePath(); ctx.fill(); } }
        if (p.kind === "conveyor") { ctx.fillStyle = bp.accent; const dir = p.conveyorDir; ctx.fillRect(drawX - 8, y + 4, 16, 2); ctx.beginPath(); ctx.moveTo(drawX + dir * 10, y + 2); ctx.lineTo(drawX + dir * 10, y + 8); ctx.lineTo(drawX + dir * 14, y + 5); ctx.closePath(); ctx.fill(); }
        if (p.kind === "slow" || p.kind === "fast" || p.kind === "vertical" || p.kind === "diagonal") { ctx.fillStyle = bp.trail; ctx.fillRect(left, y + 8, 4, 2); ctx.fillRect(right - 4, y + 8, 4, 2); }
        // Rottura in 3 step: 1 crepe luminose, 2 tremolio + bordo rosso, 3 quasi sparita
        if (breaking) {
          ctx.fillStyle = bp.crack; ctx.fillRect(left + p.w * 0.25, y + 2, 1, 6); ctx.fillRect(drawX, y + 1, 1, 7); ctx.fillRect(left + p.w * 0.65, y + 3, 1, 5);
          if (breakStage >= 2) { ctx.fillStyle = "#ef4444"; ctx.fillRect(left, y, p.w, 1); ctx.fillRect(left, y + 9, p.w, 1); ctx.fillStyle = "#ffd23d"; ctx.fillRect(left + 3, y + 2, 2, 2); ctx.fillRect(right - 5, y + 2, 2, 2); }
          if (breakStage >= 3) { ctx.fillStyle = bp.shard1; ctx.fillRect(left + 6, y + 2, 3, 3); ctx.fillRect(right - 9, y + 5, 3, 3); }
        }
        ctx.globalAlpha = 1;
      }
      // BARRIERA ENERGETICA: linea orizzontale da muro a muro all'altezza del portale.
      if (s.portalActive && !s.portalExploded) {
        const pcB = portalColorFor(cfg.id); const bY = sy(s.portalY - 10);
        ctx.save(); ctx.globalAlpha = 0.9; ctx.fillStyle = pcB; ctx.fillRect(0, bY - 2, W, 4); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, bY - 1, W, 1);
        for (let i = 0; i < 14; i++) { const sx = ((i * 23 + s.time * 46) % W); const sy2 = bY - 4 + Math.sin(s.time * 8 + i) * 3; ctx.fillStyle = i % 2 ? "#ffd23d" : "#ffffff"; ctx.fillRect(sx, sy2, 3, 3); }
        if (s.barrierFlash > 0 && Math.floor(s.time * 20) % 2 === 0) { ctx.fillStyle = "rgba(255,255,255,0.7)"; ctx.fillRect(0, bY - 4, W, 8); }
        ctx.restore();
      }
      // PORTALE FINALE — ovale luminoso, vortice, fascio, stelle orbitanti
      if (s.portalActive && !s.portalExploded) {
        const pc = portalColorFor(cfg.id);
        const is20 = cfg.id === 20;
        const isBonus = cfg.id >= 21;
        const pw = is20 ? 70 : isBonus ? 78 : 55, ph = is20 ? 80 : isBonus ? 88 : 65;
        const pulse = 1.06 + 0.06 * Math.sin(s.time * 4);
        const pScale = s.portalEntered ? Math.max(0, 1 - Math.max(0, (s.winT - 0.35) / 0.35)) * pulse : pulse;
        const py = sy(s.portalY);
        if (pScale > 0.02) {
          ctx.save(); ctx.translate(s.portalX, py); ctx.scale(pScale, pScale);
          const beamA = 0.10 + 0.05 * Math.sin(s.time * 5);
          ctx.fillStyle = pc; ctx.globalAlpha = beamA * 1.6; ctx.fillRect(-28, -180, 56, 180); ctx.fillStyle = "#ffffff"; ctx.globalAlpha = beamA * 1.2; ctx.fillRect(-10, -180, 20, 180); ctx.fillStyle = pc; ctx.globalAlpha = beamA * 0.5; ctx.fillRect(-28, ph, 56, 30); ctx.globalAlpha = 1;
          ctx.shadowColor = pc; ctx.shadowBlur = 18;
          ctx.fillStyle = pc; ctx.beginPath(); ctx.ellipse(0, 0, pw + 6, ph + 6, 0, 0, Math.PI * 2); ctx.fill();
          ctx.save(); ctx.rotate(s.time * 1.2); ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 6; ctx.setLineDash([18, 12]); ctx.beginPath(); ctx.ellipse(0, 0, pw + 6, ph + 6, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
          ctx.save(); ctx.rotate(-s.time * 1.6); ctx.strokeStyle = pc; ctx.lineWidth = 6; ctx.setLineDash([12, 18]); ctx.beginPath(); ctx.ellipse(0, 0, pw - 8, ph - 8, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
          if (is20) { ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.ellipse(0, 0, pw + 9, ph + 8, 0, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = pc; ctx.beginPath(); ctx.ellipse(0, 0, pw + 6, ph + 5, 0, 0, Math.PI * 2); ctx.fill(); }
          ctx.shadowBlur = 0; ctx.fillStyle = "#0b0620"; ctx.beginPath(); ctx.ellipse(0, 0, pw - 1, ph - 1, 0, 0, Math.PI * 2); ctx.fill();
          for (let i = 0; i < 8; i++) { const a0 = s.time * 3 + i * 0.8; const a1 = a0 + 1.1; ctx.strokeStyle = i % 2 ? pc : "#ffffff"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, pw - 4 - i, ph - 4 - i * 0.8, 0, a0, a1); ctx.stroke(); }
          ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.ellipse(0, 0, 10, 13, 0, 0, Math.PI * 2); ctx.fill();
          for (let i = 0; i < 3; i++) { const oa = s.time * 2.2 + i * (Math.PI * 2 / 3); const ox = Math.cos(oa) * (pw + 8); const oy = Math.sin(oa) * (ph + 8); ctx.fillStyle = "#ffd23d"; ctx.fillRect(ox - 1, oy - 1, 3, 3); ctx.fillStyle = "#ffffff"; ctx.fillRect(ox, oy, 1, 1); }
          ctx.restore();
          for (let i = 0; i < 6; i++) { const sa = s.time * 4 + i * 1.2; const sxp = s.portalX + Math.cos(sa) * (pw + 14); const syp = py + Math.sin(sa) * (ph + 14); ctx.fillStyle = Math.random() < 0.5 ? pc : "#ffd23d"; ctx.fillRect(sxp, syp, 2, 2); }
          if (cfg.id === 21) { for (let i = 0; i < 3; i++) { const ga = s.time * 1.4 + i * 2.1; const gx = s.portalX + Math.cos(ga) * (pw + 16); const gy = py + Math.sin(ga) * (ph + 16); ctx.save(); ctx.translate(gx, gy); ctx.rotate(s.time * 2 + i); ctx.fillStyle = "#b87333"; ctx.fillRect(-6, -6, 12, 12); ctx.fillStyle = "#d4a017"; ctx.fillRect(-8, -2, 16, 4); ctx.fillRect(-2, -8, 4, 16); ctx.fillStyle = "#1a0f08"; ctx.fillRect(-2, -2, 4, 4); ctx.restore(); } }
          if (cfg.id === 22) { for (let i = 0; i < 3; i++) { const ma = s.time * 1.4 + i * 2.1; const mx = s.portalX + Math.cos(ma) * (pw + 16); const my = py + Math.sin(ma) * (ph + 16); const msc = 1 + 0.1 * Math.sin(s.time * 3 + i); ctx.save(); ctx.translate(mx, my); ctx.scale(msc, msc); ctx.fillStyle = "#00ffff"; ctx.fillRect(-6, -5, 12, 5); ctx.fillStyle = "#ffffff"; ctx.fillRect(-3, -4, 2, 2); ctx.fillStyle = "#0a1a2e"; ctx.fillRect(-2, 0, 4, 3); ctx.restore(); } }
        }
      }
      if (s.portalActive && !s.portalEntered && !s.won && !s.dead) {
        const distM = (s.py + 8 - s.portalY) / 12;
        if (distM > 0 && distM < 60 && Math.floor(s.time * 4) % 2 === 0) {
          ctx.fillStyle = "#ffffff"; ctx.font = "bold 11px 'Space Grotesk',sans-serif"; ctx.textAlign = "center";
          ctx.fillText("↑ PORTALE", s.px + 8, sy(s.py) - 22);
          ctx.fillStyle = portalColorFor(cfg.id); ctx.fillRect(s.px + 5, sy(s.py) - 18, 6, 2);
        }
      }
      ctx.fillStyle = "#ffd23d"; ctx.font = "bold 18px 'Space Grotesk',sans-serif"; ctx.textAlign = "center";
      for (const t of s.telegraphs) { const y = sy(t.y); if (y > -20 && y < H) ctx.fillText("!", t.x, y + 16); }
      for (const e of s.enemies) {
        const y = sy(e.y); if (y < -30 || y > H + 30) continue;
        if (e.type === "hunter") {
          const bonusEye = cfg.id === 21 ? "#ff6b00" : cfg.id === 22 ? "#00ff88" : "#ff2a85";
          const squash = e.state === "charge" ? 0.72 : 1; const leapTilt = e.state === "leap" ? (e.vx >= 0 ? 0.18 : -0.18) : 0;
          ctx.save(); ctx.translate(e.x + 10, y + 8); ctx.rotate(leapTilt); ctx.scale(1, squash);
          if (e.state === "leap") { ctx.fillStyle = "rgba(255,42,133,0.55)"; ctx.fillRect(-16, -2, 6, 4); ctx.fillRect(-20, 2, 5, 3); }
          ctx.fillStyle = "#000"; ctx.fillRect(-11, -9, 22, 18); ctx.fillStyle = "#2a1a4a"; ctx.fillRect(-10, -8, 20, 16); ctx.fillStyle = "#3d2a6a"; ctx.fillRect(-10, -8, 20, 4); ctx.fillStyle = "#1a0f33"; ctx.fillRect(-10, 5, 20, 3);
          const blink = e.state === "charge" && Math.floor(s.time * 18) % 2 === 0; ctx.fillStyle = blink ? "#ffffff" : bonusEye; ctx.fillRect(-7, -3, 5, 5); ctx.fillRect(2, -3, 5, 5); ctx.fillStyle = "#000"; ctx.fillRect(-5, -1, 2, 2); ctx.fillRect(4, -1, 2, 2);
          ctx.fillStyle = "#ff2a85"; if (e.state === "leap") { ctx.fillRect(-12, 2, 4, 8); ctx.fillRect(-2, 4, 4, 8); ctx.fillRect(7, 2, 4, 8); } else { ctx.fillRect(-9, 7, 3, 4); ctx.fillRect(-1, 7, 3, 4); ctx.fillRect(7, 7, 3, 4); }
          if (e.state === "charge") { ctx.fillStyle = "#ffd23d"; ctx.fillRect(-2, -13, 4, 3); }
          ctx.restore();
        } else {
          const charging = e.state === "charge"; const firing = e.state === "fire";
          if (charging) { const x0 = e.x + 10, y0 = y + 8; const x1 = x0 + Math.cos(e.laserAngle) * 110, y1 = y0 + Math.sin(e.laserAngle) * 110; if (Math.floor(s.time * 10) % 2 === 0) { ctx.strokeStyle = "rgba(255,26,26,0.85)"; ctx.lineWidth = 2; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = "#ffd23d"; ctx.fillRect(x1 - 2, y1 - 2, 4, 4); } }
          if (firing) { const x0 = e.x + 10, y0 = y + 8; const x1 = x0 + Math.cos(e.laserAngle) * 110, y1 = y0 + Math.sin(e.laserAngle) * 110; ctx.strokeStyle = "rgba(255,26,26,0.45)"; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.strokeStyle = "#ff6a6a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.fillStyle = "#ffffff"; ctx.fillRect(x1 - 1, y1 - 1, 2, 2); ctx.globalAlpha = clamp(e.fireT / 0.6, 0, 1); ctx.fillStyle = "#ffd23d"; ctx.fillRect(x1 - 3, y1 - 3, 6, 6); ctx.fillStyle = "#ffffff"; ctx.fillRect(x1 - 1, y1 - 1, 2, 2); ctx.globalAlpha = 1; }
          ctx.save(); ctx.translate(e.x + 10, y + 8); ctx.fillStyle = "#111"; ctx.fillRect(-11, 6, 22, 6); ctx.fillStyle = "#2a2a2a"; ctx.fillRect(-9, 8, 4, 4); ctx.fillRect(5, 8, 4, 4); ctx.fillStyle = "#000"; ctx.fillRect(-10, -9, 20, 18); ctx.fillStyle = "#3a3a3a"; ctx.fillRect(-9, -8, 18, 16); ctx.fillStyle = "#555"; ctx.fillRect(-9, -8, 18, 3);
          const rot = (s.time * 2 + e.t) % (Math.PI * 2); ctx.fillStyle = "#ff1a1a"; ctx.fillRect(-9, -2 + Math.sin(rot) * 2, 3, 3); ctx.fillRect(6, -2 + Math.cos(rot) * 2, 3, 3);
          ctx.save(); ctx.rotate(e.laserAngle); ctx.fillStyle = charging || firing ? "#ff4d4d" : "#222"; ctx.fillRect(6, -2, 12, 4); ctx.fillStyle = cfg.id === 21 ? "#d4a017" : cfg.id === 22 ? "#00ff88" : "#ff1a1a"; ctx.fillRect(14, -2, 4, 4); ctx.restore();
          const eye = charging || firing ? "#ffffff" : "#3a0a0a"; ctx.fillStyle = eye; ctx.fillRect(-3, -3, 6, 6); ctx.fillStyle = "#000"; ctx.fillRect(-1, -1, 2, 2); if (charging) { ctx.fillStyle = "#ffd23d"; ctx.fillRect(-2, -13, 4, 3); } ctx.restore();
        }
      }
      const drawAnchor = (ax: number, ay: number, ang: number, col: string) => { ctx.save(); ctx.translate(ax, ay); ctx.rotate(ang + Math.PI / 2); ctx.fillStyle = col; ctx.fillRect(-1, -6, 2, 12); ctx.fillRect(-5, -4, 10, 2); ctx.fillRect(-6, 2, 3, 4); ctx.fillRect(3, 2, 3, 4); ctx.fillRect(-6, 5, 6, 2); ctx.fillRect(0, 5, 6, 2); ctx.restore(); };
      const drawWavyRope = (x0: number, y0: number, x1: number, y1: number) => { ctx.strokeStyle = "#38f2c8"; ctx.lineWidth = 2; ctx.beginPath(); for (let i = 0; i <= 12; i++) { const t = i / 12; const bx = x0 + (x1 - x0) * t, by = y0 + (y1 - y0) * t; const perpX = -(y1 - y0), perpY = (x1 - x0); const len = Math.hypot(perpX, perpY) || 1; const off = Math.sin(t * Math.PI * 3 + s.time * 12) * 2; const wx = bx + (perpX / len) * off, wy = by + (perpY / len) * off; if (i === 0) ctx.moveTo(wx, wy); else ctx.lineTo(wx, wy); } ctx.stroke(); };
      if (s.grapplePhase === "aim") { const tx = s.grappleAimTargetX, ty = sy(s.grappleAimTargetY); ctx.strokeStyle = s.grappleAimHas ? "#38f2c8" : "#ff3b6b"; ctx.lineWidth = 2; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.moveTo(s.px + 8, sy(s.py) + 8); ctx.lineTo(tx, ty); ctx.stroke(); ctx.setLineDash([]); if (s.grappleAimHas) { ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(tx, ty, 9, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = "#ffffff"; ctx.fillRect(tx - 1, ty - 1, 2, 2); } else { ctx.strokeStyle = "#ff3b6b"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tx - 7, ty - 7); ctx.lineTo(tx + 7, ty + 7); ctx.moveTo(tx + 7, ty - 7); ctx.lineTo(tx - 7, ty + 7); ctx.stroke(); } const ang = Math.atan2(s.grappleAimTargetY - (s.py + 8), s.grappleAimTargetX - (s.px + 8)); drawAnchor(tx, ty, ang, s.grappleAimHas ? "#38f2c8" : "#ff3b6b"); }
      if (s.grapplePhase === "fly" || s.grapplePhase === "retract") { drawWavyRope(s.px + 8, sy(s.py) + 8, s.grappleHookX, sy(s.grappleHookY)); const ang = Math.atan2(s.grappleTargetY - (s.py + 8), s.grappleTargetX - (s.px + 8)); drawAnchor(s.grappleHookX, sy(s.grappleHookY), ang, s.grappleMiss ? "#ff9a3d" : "#38f2c8"); }
      else if (s.grapplePhase === "pull" || s.grapplePhase === "hang") { drawWavyRope(s.px + 8, sy(s.py) + 8, s.grappleTargetX, sy(s.grappleTargetY)); const ang = Math.atan2(s.grappleTargetY - (s.py + 8), s.grappleTargetX - (s.px + 8)); const flash = s.grapplePlateFlash > 0 && Math.floor(s.time * 20) % 2 === 0; drawAnchor(s.grappleTargetX, sy(s.grappleTargetY), ang, flash ? "#ffffff" : "#38f2c8"); }
      if (s.anchorFlash > 0 && s.grappleCd <= 0 && phaseRef.current === "playing") { const blink = Math.floor(s.time * 10) % 2 === 0; if (blink) { const ax = s.px + 8, ay = sy(s.py) - 14; ctx.fillStyle = "#00e5ff"; ctx.fillRect(ax - 1, ay, 2, 6); ctx.fillRect(ax - 5, ay, 10, 2); ctx.fillRect(ax - 4, ay + 4, 3, 3); ctx.fillRect(ax + 1, ay + 4, 3, 3); } }
      for (const gh of s.ghosts) { const a = Math.max(0, gh.life / gh.max); ctx.globalAlpha = a * 0.75; ctx.strokeStyle = "#00e5ff"; ctx.lineWidth = 2; ctx.strokeRect(gh.x, sy(gh.y), 16, 16); ctx.fillStyle = "rgba(0,229,255,0.18)"; ctx.fillRect(gh.x, sy(gh.y), 16, 16); }
      ctx.globalAlpha = 1;
      for (const sh of s.shocks) { const p = sh.t / sh.max; ctx.globalAlpha = 1 - p; ctx.strokeStyle = "#00e5ff"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(sh.x, sy(sh.y), 6 + p * 34, 0, Math.PI * 2); ctx.stroke(); }
      ctx.globalAlpha = 1;
      for (const p of s.particles) {
        const a = Math.max(0, p.life / p.max); ctx.globalAlpha = a; ctx.fillStyle = p.color;
        if (p.kind === "ring") { const prog = 1 - a; ctx.strokeStyle = p.color; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(p.x, sy(p.y), Math.max(2, prog * p.size), Math.max(2, prog * p.size * 1.15), 0, 0, Math.PI * 2); ctx.stroke(); }
        else if (p.kind === "star") { const sz = p.size; ctx.fillRect(p.x - 1, sy(p.y) - sz, 2, sz * 2); ctx.fillRect(p.x - sz, sy(p.y) - 1, sz * 2, 2); ctx.fillStyle = "#ffffff"; ctx.fillRect(p.x - 1, sy(p.y) - 1, 2, 2); }
        else if (p.kind === "bubble") { const sz = Math.max(2, p.size * a); ctx.fillRect(p.x - sz / 2, sy(p.y) - sz / 2, sz, sz); ctx.fillStyle = "#ffffff"; ctx.fillRect(p.x - sz / 2 + 1, sy(p.y) - sz / 2 + 1, 1, 1); }
        else if (p.kind === "pixel") { const disp = Math.max(1, 1 + (p.size - 1) * a); ctx.save(); ctx.translate(p.x, sy(p.y)); ctx.rotate(p.rot || 0); ctx.fillRect(-disp / 2, -disp / 2, disp, disp); ctx.fillStyle = "rgba(255,255,255,0.6)"; ctx.fillRect(-disp / 2, -disp / 2, disp, 1); ctx.restore(); }
        else ctx.fillRect(p.x - p.size / 2, sy(p.y) - p.size / 2, p.size, p.size);
      }
      ctx.globalAlpha = 1;
      if (s.dead) { if (s.deathT < 0.15) { ctx.save(); ctx.translate(s.px + 8, sy(s.py) + 6); ctx.rotate(s.deathT * 3); ctx.fillStyle = "#ffffff"; ctx.fillRect(-10, -10, 20, 20); ctx.fillStyle = "#ff5400"; ctx.fillRect(-9, -9, 18, 18); ctx.fillStyle = "#fff"; ctx.fillRect(-6, -3, 5, 5); ctx.fillRect(2, -3, 5, 5); ctx.fillStyle = "#000"; ctx.fillRect(-5, -2, 2, 2); ctx.fillRect(3, -2, 2, 2); ctx.fillStyle = "#38bdf8"; ctx.fillRect(-5, 1, 3, 3); ctx.fillRect(3, 1, 3, 3); ctx.fillStyle = "#000"; ctx.fillRect(-4, 6, 8, 1); ctx.fillRect(-5, 5, 2, 1); ctx.fillRect(3, 5, 2, 1); ctx.restore(); } }
      else if (s.won) {
        if (s.portalEntered) {
          const t = Math.min(1, s.winT / 0.7); const cx = (s.px + 8) + (s.portalX - (s.px + 8)) * t; const cy = (s.py + 8) + (s.portalY - (s.py + 8)) * t; const sc = Math.max(0.1, 1 - t * 0.9);
          ctx.save(); ctx.translate(cx, sy(cy)); ctx.rotate(t * Math.PI * 4); ctx.scale(sc, sc);
          ctx.fillStyle = "#ffd23d"; ctx.fillRect(-10, -10, 20, 20); ctx.fillStyle = "#ff5400"; ctx.fillRect(-8, -8, 16, 16); ctx.fillStyle = "#fff"; ctx.fillRect(-6, -3, 5, 5); ctx.fillRect(2, -3, 5, 5); ctx.fillStyle = "#000"; ctx.fillRect(-5, -2, 2, 2); ctx.fillRect(3, -2, 2, 2); ctx.fillStyle = "#ff3b6b"; ctx.fillRect(-6, -3, 1, 1); ctx.fillRect(2, -3, 1, 1); ctx.fillStyle = "#000"; ctx.fillRect(-2, 4, 4, 4); ctx.restore();
          ctx.fillStyle = portalColorFor(cfg.id); for (let i = 0; i < 4; i++) { const a = s.time * 10 + i * 1.6; ctx.fillRect(cx + Math.cos(a) * 12, sy(cy) + Math.sin(a) * 12, 2, 2); }
        } else { ctx.save(); ctx.translate(s.px + 8, sy(s.py) + 8); ctx.fillStyle = "#ffd23d"; ctx.fillRect(-10, -10, 20, 20); ctx.fillStyle = "#ff5400"; ctx.fillRect(-8, -8, 16, 16); ctx.fillStyle = "#ffffff"; ctx.fillRect(-6, -3, 5, 5); ctx.fillRect(2, -3, 5, 5); ctx.fillStyle = "#000"; ctx.fillRect(-5, -2, 2, 2); ctx.fillRect(3, -2, 2, 2); ctx.restore(); }
      }
      else {
        const blink = s.invuln > 0 && Math.floor(s.time * 14) % 2 === 0;
        if (!blink) {
          const px = s.px, py = sy(s.py); const isIdle = s.grounded && Math.abs(s.vx) < 0.2 && s.grapplePhase === "idle"; const idleFrame = Math.floor(s.time / 0.6) % 3; const breathe = isIdle ? 1 + 0.05 * Math.sin(s.time * (Math.PI / 0.6)) : 1;
          let sx = 1, sy2 = 1; if (s.landSquash > 0) { sx = 1.2; sy2 = 0.8; } else if (!s.grounded && s.vy < -2) { sx = 0.85; sy2 = 1.15; } else if (!s.grounded && s.vy > 3) { sx = 0.9; sy2 = 1.1; } else if (!s.grounded) { sx = 0.92; sy2 = 1.08; }
          if (isIdle) { sx *= breathe; sy2 *= breathe; }
          const bounce = (!s.grounded && Math.abs(s.vx) > 0.5) || (s.grounded && Math.abs(s.vx) > 0.5) ? Math.abs(Math.sin(s.time * 14)) * 1.5 : 0;
          if (!s.grounded && s.vy < 0) { ctx.fillStyle = "rgba(120,120,120,0.5)"; ctx.fillRect(px + 2, py + 18, 12, 2); }
          ctx.save(); ctx.translate(px + 8, py + 6 - bounce); const grappling = s.grapplePhase === "aim" || s.grapplePhase === "fly" || s.grapplePhase === "pull" || s.grapplePhase === "hang";
          if (grappling) ctx.rotate(s.grappleAngle + Math.PI / 2); else if (s.vx !== 0) ctx.rotate(s.vx > 0 ? 0.08 : -0.08); ctx.scale(sx, sy2);
          ctx.fillStyle = "#000000"; ctx.fillRect(-10, -10, 20, 20); ctx.fillStyle = "#ff5400"; ctx.fillRect(-9, -9, 18, 18); ctx.fillStyle = "#ff7a2d"; ctx.fillRect(-9, -9, 18, 4); ctx.fillRect(-9, -9, 3, 18); ctx.fillStyle = "#cc3300"; ctx.fillRect(-9, 6, 18, 3); ctx.fillRect(6, -9, 3, 18);
          // --- FACCIA ESPRESSIVA: una per ogni azione, poi torna a IDLE ---
          const nearPortal = s.portalActive && Math.hypot((s.px + 8) - s.portalX, (s.py + 8) - s.portalY) < 70;
          const falling = !s.grounded && s.vy > 4 && s.grapplePhase === "idle";
          const running = s.grounded && Math.abs(s.vx) > 0.5;
          const aiming = s.grapplePhase === "aim" || s.grapplePhase === "fly";
          const hanging = s.grapplePhase === "hang";
          const idleCycle = Math.floor(s.time / 3) % 3;
          const idleFace = idleCycle === 0 ? "happy" : idleCycle === 1 ? "wink" : "sleepy";
          const face = s.hitT > 0 ? "hit" : s.surpriseT > 0 ? "surprised" : s.winkT > 0 ? "wink" : nearPortal ? "love" : s.happyT > 0 ? "happy" : aiming ? "aim" : s.hookFaceT > 0 ? "wink" : hanging ? "hang" : s.jumpFaceT > 0 ? "jump" : falling ? "fall" : s.landFaceT > 0 ? "happy" : s.hp === 1 ? "sad" : isIdle ? idleFace : running ? "run" : s.tiredT > 0 ? "tired" : "idle";
          const shakeX = face === "hit" ? (Math.random() - 0.5) * 3 : 0;
          let lookX = 0, lookY = 0;
          if (grappling) { const d = { x: Math.cos(s.grappleAngle), y: Math.sin(s.grappleAngle) }; lookX = Math.round(d.x * 1.5); lookY = Math.round(d.y * 1.5); }
          else if (face === "run") lookX = s.vx > 0 ? 1 : -1;
          else if (face === "fall") lookY = 1;
          else if (face === "jump") lookY = -1;
          else if (face === "idle") { const cyc = Math.floor(s.time / 1.4) % 4; lookX = cyc === 1 ? -1 : cyc === 3 ? 1 : 0; lookY = cyc === 2 ? -1 : 0; }
          const eyeY = grappling && Math.abs(Math.sin(s.grappleAngle)) > 0.7 ? -2 : 0;
          const drawEye = (ex: number, mode: "normal" | "x" | "closed" | "star" | "heart" | "happy" | "spiral" | "half" | "angry" | "surprised" | "sad" | "sleepy") => {
            // FACCIA BASE IN GIOCO — SEMPRE occhi bianchi 5x5 + pupilla nera 2x2, mai occhi neri pieni.
            // Ogni stato parte dalla stessa base bianca; gli accenti restano sottili e non coprono mai tutto l'occhio.
            const ey = -2 + eyeY + lookY;
            ctx.fillStyle = "#fff"; ctx.fillRect(ex, ey, 5, 5);
            const px = ex + 1 + lookX; const py = ey + 1;
            ctx.fillStyle = "#000"; ctx.fillRect(px, py, 2, 2);
            if (mode === "x") { ctx.fillStyle = "#000"; for (let xi = 0; xi < 5; xi++) { ctx.fillRect(ex + xi, ey + xi, 1, 1); ctx.fillRect(ex + 4 - xi, ey + xi, 1, 1); } }
            else if (mode === "happy") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey + 4, 5, 1); }
            else if (mode === "closed") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey + 4, 5, 1); }
            else if (mode === "surprised") { ctx.fillStyle = "#fff"; ctx.fillRect(px, py, 1, 1); }
            else if (mode === "sad") { ctx.fillStyle = "#38bdf8"; ctx.fillRect(ex + 1, ey + 5, 2, 2); }
            else if (mode === "sleepy") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey, 5, 1); }
            else if (mode === "half") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey, 5, 1); }
            else if (mode === "star") { ctx.fillStyle = "#ffd23d"; ctx.fillRect(ex, ey, 1, 1); ctx.fillRect(ex + 4, ey, 1, 1); }
            else if (mode === "heart") { ctx.fillStyle = "#ff3b6b"; ctx.fillRect(ex, ey, 1, 1); ctx.fillRect(ex + 4, ey, 1, 1); }
            else if (mode === "spiral") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey, 5, 1); ctx.fillRect(ex, ey + 4, 5, 1); }
            else if (mode === "angry") { ctx.fillStyle = "#000"; ctx.fillRect(ex, ey, 5, 1); }
          };
          if (face === "hit") { drawEye(-6, "x"); drawEye(3, "x"); }
          else if (face === "tired") { drawEye(-6, "half"); drawEye(3, "half"); }
          else if (face === "surprised") { drawEye(-6, "surprised"); drawEye(3, "surprised"); ctx.fillStyle = "#ffd23d"; ctx.fillRect(-8, -8, 2, 2); ctx.fillRect(7, -8, 2, 2); }
          else if (face === "happy") { drawEye(-6, "happy"); drawEye(3, "happy"); ctx.fillStyle = "#ffd23d"; ctx.fillRect(-9, -8, 2, 2); ctx.fillRect(8, -8, 2, 2); ctx.fillStyle = "#ffb3c1"; ctx.fillRect(-9, 2, 3, 2); ctx.fillRect(7, 2, 3, 2); }
          else if (face === "sad") { drawEye(-6, "sad"); drawEye(3, "sad"); }
          else if (face === "sleepy") { drawEye(-6, "sleepy"); drawEye(3, "sleepy"); ctx.fillStyle = "#5a6a80"; ctx.fillRect(8, -9, 2, 2); }
          else if (face === "wink") { drawEye(-6, "happy"); drawEye(3, "normal"); ctx.fillStyle = "#ffd23d"; ctx.fillRect(8, -8, 2, 2); }
          else if (face === "love") { drawEye(-6, "heart"); drawEye(3, "heart"); ctx.fillStyle = "#ff3b6b"; ctx.fillRect(-9, -8, 2, 2); ctx.fillRect(8, -8, 2, 2); ctx.fillStyle = "#ffb3c1"; ctx.fillRect(-9, 2, 3, 2); ctx.fillRect(7, 2, 3, 2); }
          else if (face === "aim") { drawEye(-6, "closed"); drawEye(3, "normal"); ctx.fillStyle = "#ffd23d"; ctx.fillRect(7, -12, 2, 5); ctx.fillRect(7, -6, 2, 2); }
          else if (face === "hook" || face === "portal") { drawEye(-6, face === "portal" ? "heart" : "star"); drawEye(3, face === "portal" ? "heart" : "star"); }
          else if (face === "hang") { drawEye(-6, "normal"); drawEye(3, "normal"); ctx.fillStyle = "rgba(255,59,107,0.7)"; ctx.fillRect(-9, 2, 3, 2); ctx.fillRect(6, 2, 3, 2); }
          else if (face === "jump") { drawEye(-6, "normal"); drawEye(3, "normal"); }
          else if (face === "fall") { drawEye(-6, "spiral"); drawEye(3, "spiral"); }
          else if (face === "land") { drawEye(-6, "happy"); drawEye(3, "happy"); }
          else if (face === "run") { drawEye(-6, "normal"); drawEye(3, "normal"); ctx.fillStyle = "#000"; const bx = s.vx > 0 ? 1 : -1; ctx.fillRect(-7 + bx, -5 + eyeY, 5, 1); ctx.fillRect(2 + bx, -5 + eyeY, 5, 1); }
          else { drawEye(-6, "normal"); drawEye(3, "normal"); }
          if (face === "hit") { const veinPulse = 1 + 0.25 * Math.sin(s.time * 14); ctx.save(); ctx.translate(9, -12); ctx.scale(veinPulse, veinPulse); ctx.fillStyle = "#000"; ctx.fillRect(-5, -5, 10, 10); ctx.fillRect(-8, -2, 4, 4); ctx.fillRect(4, -2, 4, 4); ctx.fillRect(-2, -8, 4, 4); ctx.fillRect(-2, 4, 4, 4); ctx.fillStyle = "#8b1a1a"; ctx.fillRect(-4, -4, 8, 8); ctx.fillRect(-7, -1, 3, 3); ctx.fillRect(4, -1, 3, 3); ctx.fillRect(-1, -7, 3, 3); ctx.fillRect(-1, 4, 3, 3); ctx.restore(); ctx.save(); ctx.translate(-3, -6); ctx.rotate(0.32); ctx.fillStyle = "#000"; ctx.fillRect(-3, -1, 7, 3); ctx.restore(); ctx.save(); ctx.translate(4, -6); ctx.rotate(-0.32); ctx.fillStyle = "#000"; ctx.fillRect(-4, -1, 7, 3); ctx.restore(); ctx.fillStyle = "#ff3b6b"; ctx.fillRect(-8, 2, 3, 3); ctx.fillRect(5, 2, 3, 3); const steamWiggle = Math.sin(s.time * 12) * 1.5; ctx.fillStyle = "rgba(255,255,255,0.85)"; ctx.fillRect(-13, -3 + steamWiggle, 4, 3); ctx.fillRect(-11, -6 + steamWiggle, 3, 3); ctx.fillRect(10, -3 - steamWiggle, 4, 3); ctx.fillRect(8, -6 - steamWiggle, 3, 3); ctx.fillStyle = "#000"; ctx.fillRect(-3, 4, 2, 1); ctx.fillRect(-1, 5, 2, 1); ctx.fillRect(1, 4, 2, 1); ctx.fillRect(3, 5, 2, 1); }
          else if (face === "tired") { ctx.fillStyle = "#000"; ctx.fillRect(-2, 5, 4, 1); }
          else if (face === "surprised") { ctx.fillStyle = "#000"; ctx.fillRect(-3, 4, 6, 6); ctx.fillStyle = "#7a1a00"; ctx.fillRect(-2, 8, 4, 1); }
          else if (face === "happy") { ctx.fillStyle = "#000"; ctx.fillRect(-4, 4, 8, 2); ctx.fillRect(-3, 6, 6, 2); ctx.fillStyle = "#ff6b6b"; ctx.fillRect(-2, 6, 4, 2); }
          else if (face === "sad") { ctx.fillStyle = "#000"; ctx.fillRect(-3, 6, 6, 1); ctx.fillRect(-4, 5, 2, 1); ctx.fillRect(2, 5, 2, 1); }
          else if (face === "sleepy") { ctx.fillStyle = "#000"; ctx.fillRect(-2, 4, 4, 4); }
          else if (face === "wink") { ctx.fillStyle = "#000"; ctx.fillRect(-4, 4, 8, 2); ctx.fillRect(-3, 6, 5, 1); ctx.fillStyle = "#ff6b6b"; ctx.fillRect(3, 5, 2, 3); }
          else if (face === "love") { ctx.fillStyle = "#000"; ctx.fillRect(-2, 4, 4, 4); }
          else if (face === "aim" || face === "hang" || face === "jump" || face === "fall") { ctx.fillStyle = "#000"; const sz = face === "fall" ? 7 : face === "jump" ? 5 : 3; ctx.fillRect(-sz / 2, 4, sz, face === "aim" ? 1 : sz); if (face === "aim") { ctx.fillStyle = "#000"; ctx.fillRect(-3, 4, 6, 1); } }
          else if (face === "land" || face === "hook" || face === "portal") { ctx.fillStyle = "#000"; ctx.fillRect(-3, 4, 6, 1); ctx.fillRect(-4, 3, 2, 1); ctx.fillRect(2, 3, 2, 1); }
          else if (face === "run") { ctx.fillStyle = "#000"; ctx.fillRect(-3, 4, 5, 1); ctx.fillRect(1, 3, 2, 1); }
          else { ctx.fillStyle = "#000"; const bw = 3 + Math.sin(s.time * 3.2) * 1; ctx.fillRect(-2, 4, 4, 1); ctx.fillStyle = "#7a1a00"; ctx.fillRect(-1, 5, bw, 1); }
          if (isIdle && idleFrame === 1) { ctx.fillStyle = "#38f2c8"; ctx.fillRect(-11, -4, 2, 3); ctx.fillRect(-10, -1, 2, 2); }
          ctx.restore();
        }
      }
      const floorScreen = sy(s.floorY);
      if (floorScreen < H + 40) {
        const pulse = 0.7 + 0.3 * Math.sin(s.time * 6);
        for (let i = 0; i < 8; i++) { const sx2 = (i * 41 + 7) % W; const sy2 = floorScreen - 6 - ((i * 17 + Math.floor(s.time * 22)) % 22); ctx.globalAlpha = 0.18; ctx.fillStyle = cfg.id === 20 ? "#a855f7" : "#7a5a8a"; ctx.fillRect(sx2, sy2, 5, 4); }
        ctx.globalAlpha = 1; ctx.fillStyle = cfg.floor; ctx.fillRect(0, Math.max(0, floorScreen), W, H - Math.max(0, floorScreen) + 40);
        for (let i = 0; i < 10; i++) { const bx = (i * 29 + 7) % W; const by = Math.max(0, floorScreen) + 12 + ((i * 23 + Math.floor(s.time * 18)) % 70); if (by <= H) { ctx.fillStyle = cfg.particle; ctx.globalAlpha = 0.7; ctx.fillRect(bx, by, 4, 4); ctx.globalAlpha = 1; } }
        ctx.fillStyle = cfg.floor; for (let x = 0; x < W; x += 18) { ctx.beginPath(); ctx.moveTo(x, Math.max(0, floorScreen) + 2); ctx.lineTo(x + 9, Math.max(0, floorScreen) - 10); ctx.lineTo(x + 18, Math.max(0, floorScreen) + 2); ctx.closePath(); ctx.fill(); }
        ctx.globalAlpha = pulse; ctx.fillStyle = cfg.floor2; ctx.fillRect(0, Math.max(0, floorScreen) - 2, W, 4); ctx.fillStyle = "#ffd23d"; ctx.fillRect(0, Math.max(0, floorScreen) - 1, W, 1); ctx.globalAlpha = 1;
      }
      ctx.restore();
      // Vignetta scura ai bordi + bagliore attorno al cubetto
      const vig = ctx.createRadialGradient(135, 240, 120, 135, 240, 320);
      vig.addColorStop(0, "rgba(0,0,0,0)"); vig.addColorStop(1, "rgba(0,0,0,0.42)");
      ctx.fillStyle = vig; ctx.fillRect(0, 0, W, H);
      if (!s.dead && !s.won && phaseRef.current === "playing") { ctx.save(); ctx.globalAlpha = 0.22; ctx.fillStyle = "#ff9a3d"; ctx.beginPath(); ctx.arc(s.px + 8, sy(s.py) + 8, 26, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
      // Barra progresso verso il portale in alto (sempre visibile in gioco)
      if (phaseRef.current === "playing") { const curM = Math.max(0, Math.floor((START_Y - s.minFeet) / 12)); const prog = clamp(curM / Math.max(1, cfg.goal), 0, 1); ctx.fillStyle = "rgba(0,0,0,0.55)"; ctx.fillRect(18, 4, W - 36, 7); ctx.fillStyle = "#38f2c8"; ctx.fillRect(18, 4, (W - 36) * prog, 7); ctx.fillStyle = "#ffffff"; ctx.font = "bold 8px 'Space Grotesk',sans-serif"; ctx.textAlign = "center"; ctx.fillText(`${curM}m / ${cfg.goal}m`, 135, 22); }
      if (s.flashT > 0) { ctx.fillStyle = "rgba(180,255,255,0.45)"; ctx.fillRect(0, 0, W, H); }
      if (s.portalEntered && s.winT > 0.7) { const fa = Math.min(1, (s.winT - 0.7) / 0.3); ctx.globalAlpha = fa; ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H); ctx.fillStyle = portalColorFor(cfg.id); ctx.globalAlpha = fa * 0.45; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
      ctx.fillStyle = "rgba(0,0,0,0.18)"; ctx.fillRect(0, 0, W, 8); ctx.fillRect(0, H - 8, W, 8);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sfx, saveBest]);

  useEffect(() => {
    const onMove = (e: MouseEvent) => { const c = canvasRef.current; if (!c) return; const r = c.getBoundingClientRect(); if (r.width > 0) mouseRef.current = { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H, t: Date.now() }; };
    window.addEventListener("mousemove", onMove); return () => window.removeEventListener("mousemove", onMove);
  }, []);
  const joyStart = (e: React.PointerEvent) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); joy.current.active = true; updateJoy(e); };
  const updateJoy = (e: React.PointerEvent) => { const rect = (e.currentTarget as HTMLElement).getBoundingClientRect(); const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2; let dx = clamp((e.clientX - cx) / 36, -1, 1), dy = clamp((e.clientY - cy) / 36, -1, 1); joy.current.dx = dx; joy.current.dy = dy; setJoyPos({ x: dx * 27, y: dy * 27 }); if (dy < -0.55) { doJump(); } };
  const joyEnd = () => { joy.current = { active: false, dx: 0, dy: 0 }; setJoyPos({ x: 0, y: 0 }); input.current.left = false; input.current.right = false; };
  const floorDanger = phase === "playing" && hud.floorDist < 80 && hud.floorDist > 0;
  const totalBest = Math.max(0, ...Object.values(bestByLevel));
  const currentCfg = LEVELS[selectedLevel - 1];
  const bonusPad = selectedLevel === 21 ? "#ffb703" : selectedLevel === 22 ? "#00ff88" : "#38f2c8";
  const bonusRamp = selectedLevel === 21 ? "#d4a017" : selectedLevel === 22 ? "#00ffff" : "#00e5ff";
  const toggleMute = () => {
    // Ogni click prova a riprodurre un feedback sonoro (anche quando si silenzia,
    // il click si sente prima del cambio) così il controllo audio è sempre attivo.
    try {
      if (!audioRef.current) audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioRef.current; if (ctx.state === "suspended") void ctx.resume();
      const o = ctx.createOscillator(), gn = ctx.createGain(); o.connect(gn); gn.connect(ctx.destination);
      o.type = "sine"; o.frequency.setValueAtTime(1300, ctx.currentTime);
      gn.gain.setValueAtTime(0.08, ctx.currentTime); gn.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      o.start(ctx.currentTime); o.stop(ctx.currentTime + 0.1);
    } catch { /* feedback visivo sotto */ }
    const v = !muted; mutedRef.current = v; setMuted(v);
    if (v) { pauseMusic(); if (musicGainRef.current && audioRef.current) musicGainRef.current.gain.setTargetAtTime(0, audioRef.current.currentTime, 0.05); }
    else { unlockAudio(); }
    setSaveNote(v ? "🔇 Audio disattivato" : "🔊 Audio attivo");
  };
  const completedCount = completed.length;

  return (
    <>
    {isFullscreen && phase !== "menu" && (
      <button type="button" className="kubo-menu-exit-btn"
        onPointerDown={(e) => { e.stopPropagation(); }} onTouchStart={(e) => { e.stopPropagation(); }}
        onClick={(e) => { e.stopPropagation(); void goToLevels(); }}
        style={{ position: "fixed", top: "calc(var(--safe-area-inset-top) + 6px)", right: "8px", zIndex: 999999, display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", height: "28px", minHeight: "28px", padding: "0 10px", fontSize: "10px", fontWeight: 800, lineHeight: 1, letterSpacing: "0.02em", color: "#ffffff", background: "rgba(0,0,0,0.55)", border: "1px solid rgba(255,255,255,0.35)", borderRadius: "999px", boxShadow: "0 2px 8px rgba(0,0,0,0.35)", whiteSpace: "nowrap", cursor: "pointer", touchAction: "manipulation" }}
        aria-label="Torna al menu principale">🏠 TORNA AL MENU</button>
    )}
    <div ref={shellRef} data-safe-area-inset-root style={shellStyle} className={`${isFullscreen ? "fullscreen fixed inset-0 z-[999] h-[100dvh] h-[100svh] w-[100vw] bg-[#05070c]" : "h-[100dvh] h-[100svh] w-full bg-[var(--bg)]"} text-[var(--ink)] flex flex-col overflow-hidden overflow-x-clip ${cssFullscreen ? "fullscreen fixed inset-0 z-[999]" : ""}`}>
      {phase === "menu" ? (
        <>
        <MenuRisingBricks />
        <div onPointerDown={tryMenuFullscreen} className="relative z-10 flex-1 min-h-0 w-full max-w-[980px] mx-auto px-0 pb-3 overflow-y-auto">
          <div className="text-center pt-1 pb-3">
            <h1 className="font-display leading-[0.88] text-center w-full px-1 select-none" style={{ fontSize: "clamp(64px, 20vw, 132px)", textShadow: "0 0 28px rgba(255,84,0,0.65), 0 0 58px rgba(56,242,200,0.45), 0 5px 0 rgba(0,0,0,0.45)" }} aria-label="Kubo Run"><span className="block text-[#ff5400]">KUBO</span><span className="block text-white">RUN</span></h1>
            <div className="mt-6 mb-6 py-2"><MenuKuboExpressions /></div>
            <p className="font-playful mt-2 text-center text-[clamp(22px,6.2vw,30px)] font-extrabold leading-[1.15] px-3" style={{ textShadow: "0 2px 0 rgba(255,84,0,0.55), 0 4px 14px rgba(255,84,0,0.45)" }}><span className="text-[#ff5400]">Corri</span><span className="text-white">, </span><span className="text-[#00e5ff]">salta</span><span className="text-white">, </span><span className="text-[#4ade80]">agganciati</span><span className="text-white">, entra nel </span><span className="text-[#ff2a85]">portale</span></p>
            <div className="mt-4 px-3 flex flex-wrap items-center justify-center gap-2" aria-label="Azioni menu">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-black bg-[#ffd23d] border-2 border-[#b8860b] px-3 py-2 rounded-full whitespace-nowrap shadow-[0_2px_0_#b8860b]"><Trophy size={14} className="shrink-0 text-[#8a5a00] fill-[#fff3b0]" /> BEST {totalBest}m · {completedCount}/22</span>
              <button onClick={toggleMute} className="w-9 h-9 rounded-full bg-[#ff5400] border-2 border-[#7a1a00] text-white flex items-center justify-center active:scale-95 shadow-[0_2px_0_#7a1a00]" aria-label={muted ? "Riattiva audio" : "Silenzia audio"}>{muted ? <VolumeX size={18} /> : <Volume2 size={18} />}</button>
              <button onClick={() => setShowHelp(true)} className="inline-flex items-center gap-1.5 h-9 px-3 rounded-[8px] bg-[#38f2c8] text-black text-[11px] font-bold active:scale-95 shadow-[0_3px_0_#0f8a6d,0_6px_14px_rgba(56,242,200,0.45)]"><HelpCircle size={16} /> COME SI GIOCA</button>
            </div>
          </div>
          <div className="mt-1 px-2">
            <div className="flex items-center justify-between gap-2 px-2">
              <span className="font-display text-[12px] text-white tracking-wide">SELEZIONA MONDO</span>
              <span className="text-[11px] font-bold text-[#ffd23d]">{carouselIndex + 1} / 22</span>
            </div>
            {lockedMsg && !UNLOCK_ALL && <div className="mt-2 text-center text-[12px] font-bold text-[#ff3b6b] bg-[#2a0a12] border border-[#ff3b6b]/40 rounded-full px-3 py-1.5" role="status">{lockedMsg}</div>}
            <div className="mt-1 relative flex items-center">
              <button type="button" onClick={() => { const n = Math.max(0, carouselIndex - 1); setCarouselIndex(n); scrollCarouselTo(n); }} className="absolute left-1 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-10 sm:h-10 shrink-0 rounded-full bg-[#161f33]/90 border border-[#2a3a5e] text-white flex items-center justify-center active:scale-95 z-20" aria-label="Livelli precedenti">‹</button>
              <div ref={carouselRef} onScroll={(e) => { const x = e.currentTarget.scrollLeft; setCarouselIndex(Math.min(21, Math.max(0, Math.round(x / 288)))); }} className="flex-1 min-w-0 flex overflow-x-auto py-3" style={{ scrollSnapType: "x mandatory", scrollBehavior: "smooth", WebkitOverflowScrolling: "touch", scrollbarWidth: "none", paddingLeft: "calc(50% - 144px)", paddingRight: "calc(50% - 144px)" }}>
                {LEVELS.map((lv, i) => {
                  const isLocked = !unlocked.includes(lv.id);
                  const dist = Math.abs(i - carouselIndex);
                  const isCenter = dist === 0;
                  const diameter = isCenter ? 268 : dist === 1 ? 168 : 112;
                  return (
                    <div key={lv.id} className="shrink-0 flex items-center justify-center" style={{ width: 288, scrollSnapAlign: "center" }}>
                      <button type="button" onClick={() => { if (isLocked) { setCarouselIndex(i); scrollCarouselTo(i); handleLockedLevel(lv.id); } else if (isCenter) startGame(lv.id); else { setCarouselIndex(i); scrollCarouselTo(i); } }} aria-label={isLocked ? `${lv.name}, bloccato` : isCenter ? `Gioca ${lv.name}` : `Seleziona ${lv.name}`} className={`bg-transparent border-0 p-0 cursor-pointer active:scale-[0.97] transition-transform ${shakeLevel === lv.id ? "kubo-shake" : ""} ${lv.id === currentLevelId && !isCenter ? "opacity-90" : ""}`}>
                        <WorldCircle lv={lv} diameter={diameter} isCenter={isCenter} isLocked={isLocked} />
                      </button>
                    </div>
                  );
                })}
              </div>
              <button type="button" onClick={() => { const n = Math.min(21, carouselIndex + 1); setCarouselIndex(n); scrollCarouselTo(n); }} className="absolute right-1 top-1/2 -translate-y-1/2 w-9 sm:w-10 h-9 sm:h-10 shrink-0 rounded-full bg-[#161f33]/90 border border-[#2a3a5e] text-white flex items-center justify-center active:scale-95 z-20" aria-label="Livelli successivi">›</button>
            </div>
            <div className="flex items-center justify-center gap-1.5 flex-wrap mt-1" aria-label={`Posizione ${carouselIndex + 1} di 22`}>
              {LEVELS.map((lv, i) => (
                <button key={lv.id} type="button" onClick={() => { setCarouselIndex(i); scrollCarouselTo(i); }} aria-label={`Vai al livello ${lv.id}`} className={`rounded-full transition-all ${i === carouselIndex ? "w-5 h-2 bg-[#38f2c8]" : "w-2 h-2 bg-[#33415e] hover:bg-[#8fa3b8]"}`} />
              ))}
            </div>
            {(() => { const lv = LEVELS[carouselIndex]; const isLocked = !unlocked.includes(lv.id); const best = bestByLevel[lv.id] || 0; const done = completed.includes(lv.id); const stars = Array.from({ length: 5 }, (_, i2) => i2 < lv.stars); return (
              <div className="mt-3 px-3 pb-1 text-center">
                <div className="text-[16px] leading-none tracking-wide" style={{ color: lv.edge }} aria-label={`${lv.stars} stelle su 5`}>{stars.map((f, i2) => <span key={i2}>{f ? "★" : "☆"}</span>)}</div>
                <div className="font-display text-[13px] mt-2 flex items-center justify-center gap-2" style={{ color: brickPaletteFor(lv).edge }}><PixelWorldIcon kind={lv.icon} size={20} glow={lv.edge} /><span>{brickPaletteFor(lv).name}</span></div>
                <p className="text-[13px] text-[#cbd5e1] leading-snug mt-1 max-w-[420px] mx-auto">{lv.desc}</p>
                <div className="flex items-center justify-center gap-3 mt-2 text-[13px] font-bold text-[#ffd23d]"><span className="inline-flex items-center gap-1.5"><span className="inline-block w-2.5 h-2.5 rotate-45 bg-[#ffd23d]" aria-hidden="true" /> {lv.goal}m</span><span>BEST {best}m</span>{done && <span className="text-[#4ade80]">✓ Completato</span>}</div>
                {isLocked ? <p className="text-[11px] font-bold text-[#8fa3b8] mt-2">Completa il livello {lv.id - 1} per sbloccare</p> : <button type="button" onClick={() => startGame(lv.id)} className="mt-3 inline-flex items-center gap-2 rounded-full bg-[#38f2c8] text-black font-display text-[16px] px-8 py-3 active:scale-95 shadow-[0_4px_0_#0f8a6d,0_8px_18px_rgba(56,242,200,.45)]">GIOCA <ChevronRight size={18} /></button>}
              </div>
            ); })()}
          </div>
          <div className="mt-5 mb-2 rounded-2xl border border-[#1e2a44] bg-[#0d1321]/70 px-3 py-3 opacity-80">
            <div className="flex items-center justify-between gap-2"><span className="font-display text-[11px] text-[#38f2c8]">COME SI GIOCA</span><span className="text-[10px] font-bold text-[#8fa3b8]">LEGENDA</span></div>
            <p className="text-[11px] text-[#cbd5e1] leading-snug mt-1.5">Tutti i mondi sbloccati per prova - alla fine torneranno bloccati in sequenza. Solo PAD + RAMPINO.</p>
            <div className="mt-2 grid grid-cols-3 gap-1.5 text-[9px] font-bold">
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 bg-[#a16207] align-middle mr-1" />Fragile = si rompe</span>
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 rotate-45 bg-[#67e8f9] align-middle mr-1" />Fantasma = appare/scompare</span>
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 bg-[#4ade80] align-middle mr-1" />Rimbalzo = salto x1.8</span>
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 bg-[#7dd3fc] align-middle mr-1" />Ghiaccio = scivola</span>
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 rotate-45 bg-[#ef4444] align-middle mr-1" />Spuntoni = −1 cuore</span>
              <span className="bg-[#161f33] text-[#cbd5e1] px-1.5 py-1.5 rounded-full text-center leading-tight"><span className="inline-block w-2 h-2 rotate-45 bg-[#facc15] align-middle mr-1" />Conveyor = ti spinge</span>
            </div>
          </div>
          <p className="text-center text-[10px] text-[#8fa3b8] pb-1 pt-1">{saveNote || "Progressi e BEST salvati per livello."}</p>
        </div>
        {showHelp && (
          <div className="absolute inset-0 z-[80] bg-black/80 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Come si gioca">
            <div className="w-full max-w-[360px] max-h-[88dvh] overflow-y-auto bg-[#0d1321] border border-[#1e2a44] rounded-2xl p-4">
              <div className="flex items-start justify-between gap-2"><div className="font-display text-white text-[16px]">COME SI GIOCA</div><button onClick={() => setShowHelp(false)} className="w-8 h-8 rounded-full bg-[#161f33] text-white flex items-center justify-center" aria-label="Chiudi aiuto"><X size={16} /></button></div>
              <div className="text-[13px] leading-relaxed text-[#cbd5e1] mt-3 space-y-2">
                <p><b className="text-white">PAD (sinistra):</b> trascina a sinistra / destra per muoverti — più lo spingi, più vai veloce. SU = salta (su-sinistra / su-destra = salta di lato). GIÙ = scendi veloce / lasci la piattaforma.</p>
                <p><b className="text-white">RAMPINO (destra):</b> un solo tasto. Spara solo su-sinistra o su-destra a ~60° verso i muri laterali. Si aggancia solo alle pareti sopra di te.</p>
                <p><b className="text-white">Da appeso:</b> PAD SU = salti via verso l’alto / centro · PAD GIÙ = ti sganci e cadi · PAD lato opposto = ti sganci con spinta. Se non premi niente, resti appeso fermo.</p>
                <p><b className="text-white">Piattaforme:</b> Fragile si rompe dopo 0.7s, Fantasma appare/scompare, A tempo sparisce dopo il salto, Rimbalzo ti lancia x1.8, Ghiaccio scivola, Spuntoni tolgono 1 cuore, Conveyor ti spinge, Mobile si muove.</p>
                <p><b className="text-white">Tastiera:</b> A/D o frecce = muovi · W / Freccia Su / Spazio = salta · E/Q = rampino · P/Esc = pausa · R = rigioca · M = audio · F = tutto schermo.</p>
                <p className="text-[11px] text-[#8fa3b8]">Il pavimento sale sempre (12px/s a L1 fino a 32px/s a L20). Se resti fermo, accelera. Niente dash: solo salto + rampino.</p>
              </div>
              <button onClick={() => setShowHelp(false)} className="mt-4 w-full bg-[#38f2c8] text-black font-display text-[13px] py-2.5 rounded-full">HO CAPITO</button>
            </div>
          </div>
        )}
        </>
      ) : (
        <>
      {!isFullscreen && (
      <header className="w-full max-w-[420px] mx-auto px-3 pt-2 pb-2 shrink-0 relative z-40">
        <div className="flex items-center justify-center gap-1.5 pb-1" aria-label="Kubo Run"><span className="w-[14px] h-[14px] bg-[#ff5400] border border-black rounded-[2px] relative shrink-0 animate-bounce"><span className="absolute left-[2px] top-[3px] w-[3px] h-[3px] bg-white" /><span className="absolute right-[2px] top-[3px] w-[3px] h-[3px] bg-white" /></span><span className="font-display text-[11px] leading-none"><span className="text-[#ff5400]">KUBO</span> <span className="text-white">RUN</span></span></div>
        <div className="flex items-center justify-between gap-2 h-[28px] min-h-0">
          <div className="flex items-baseline gap-2 min-w-0">
            <div className="font-display leading-none text-[26px] text-white whitespace-nowrap">{hud.m}<span className="text-[15px] text-[#38f2c8]"> m</span><span className="text-[12px] text-[#8fa3b8]"> / {hud.goal}m</span></div>
            <div className="inline-flex items-center gap-1 text-[9px] font-bold tracking-widest px-1.5 py-0.5 rounded-full bg-[#161f33] whitespace-nowrap min-w-0" style={{ color: currentCfg.edge }}><Gauge size={10} className="shrink-0" /><span className="truncate">LIVELLO {hud.level} · {currentCfg.short.toUpperCase()}</span></div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex gap-0.5" aria-label={`${hud.hp} cuori`}>{[0, 1, 2].map(i => <Heart key={i} size={16} className={i < hud.hp ? "fill-[#ff3b6b] text-[#ff3b6b]" : "text-[#33415e]"} />)}</div>
            <div className="flex items-center gap-1 text-[10px] font-bold text-[#ffd23d] whitespace-nowrap"><Trophy size={11} /> BEST {hud.best}m</div>
          </div>
        </div>
        <div className="mt-1 h-[5px] rounded-full bg-[#0d1321] overflow-hidden" aria-label={`Progresso verso obiettivo ${hud.goal} metri`}><div className="h-full bg-[#38f2c8]" style={{ width: `${Math.min(100, Math.round((hud.m / Math.max(1, hud.goal)) * 100))}%` }} /></div>
        <div className="mt-2 flex items-end gap-2" aria-label="RAMPINO">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 text-[8px] font-bold tracking-widest text-[#00e5ff] leading-none"><Anchor size={9} /> RAMPINO</div>
            <div className="mt-1 h-[4px] rounded-full bg-[#0d1321] overflow-hidden"><div className={`h-full rounded-full ${hud.grappleReady ? "bg-[#00e5ff]" : "bg-[#5a6a80]"}`} style={{ width: `${Math.round(hud.grapple * 100)}%` }} /></div>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={goToLevels} className="w-[60px] h-[44px] min-h-[44px] rounded-xl border-2 border-[#1e2a44] bg-[#0d1321] text-white text-[10px] font-bold flex items-center justify-center gap-1 active:scale-95 active:bg-[#1e2a44]" aria-label="Metti in pausa e torna alla selezione livelli">🏠 LIVELLI</button>
            <button onClick={() => { if (phase === "playing") setPhase("paused"); else if (phase === "paused") startResumeCountdown(); }} className="w-[72px] h-[44px] min-h-[44px] rounded-xl border-2 border-[#38f2c8] bg-[#0d1321] text-white text-[10px] font-bold flex items-center justify-center gap-1 active:scale-95 active:bg-[#38f2c8] active:text-black shadow-[0_0_14px_rgba(56,242,200,0.35)]" aria-label={phase === "paused" ? "Riprendi il gioco" : "Metti in pausa"}>{phase === "paused" ? <><Play size={14} /> RIPRENDI</> : <><Pause size={14} /> PAUSA</>}</button>
          </div>
        </div>
        <div className="sr-only">{saveNote} {hud.points > hud.m ? `+${hud.points - hud.m} punti` : ""} Salti dritti: {hud.straight} su 4. Premi P o Esc per mettere in pausa.</div>
      </header>
      )}
      <main className={isFullscreen ? "flex-1 min-h-0 flex items-center justify-center relative overflow-hidden p-0 m-0 w-full h-full bg-[#05070c]" : "flex-1 min-h-0 flex items-center justify-center px-3 py-1 relative overflow-hidden"}>
        <div style={isFullscreen ? undefined : { aspectRatio: "9 / 16" }} className={isFullscreen ? "relative w-full h-full shrink-0 overflow-hidden bg-[#05070c]" : "relative h-full max-h-full max-w-full shrink-0 rounded-[18px] overflow-hidden border-2 border-[#1e2a44] shadow-[0_18px_50px_rgba(0,0,0,0.6)] bg-[#05070c]"}>
          <canvas ref={canvasRef} width={270} height={480} className="block w-full h-full" aria-label="Kubo Infinito" />
          {isFullscreen && phase === "playing" && (
            <div className="absolute top-[64px] left-1/2 -translate-x-1/2 bg-black/70 text-white font-display text-[12px] px-3 py-1.5 rounded-full whitespace-nowrap pointer-events-none z-[20]">{hud.m}m / {hud.goal}m · ♥ {hud.hp}</div>
          )}
          {!isFullscreen && levelBanner && phase === "playing" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-black/75 border border-[#ffd23d] text-[#ffd23d] font-display text-[11px] tracking-wide px-3 py-1.5 rounded-full whitespace-nowrap pointer-events-none">{levelBanner}</div>
          )}
          {!isFullscreen && phase === "playing" && g.current.floorWait > 0 && (
            <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-black/60 text-white text-[10px] font-bold tracking-widest px-2 py-1 rounded-full pointer-events-none">PREPARATI… IL PAVIMENTO SALE</div>
          )}
          {!isFullscreen && phase === "playing" && hud.windOn && (
            <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-[#bfe9ff] text-[#0b2a3a] font-display text-[11px] px-3 py-1 rounded-full pointer-events-none">VENTO! {hud.windDir < 0 ? "◀◀◀" : "▶▶▶"}</div>
          )}
          {!isFullscreen && phase === "playing" && hud.tongueWarn && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-[#ff3b00] text-white font-display text-[11px] px-3 py-1 rounded-full animate-pulse pointer-events-none">ATTENTO! LAVA A SCATTO</div>
          )}
          {!isFullscreen && floorDanger && (
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex flex-col items-center gap-0.5 pointer-events-none"><AlertTriangle size={18} className="text-[#ff3b00] animate-bounce" /><div className="bg-[#ff3b00] text-white font-display text-[11px] px-2 py-0.5 rounded-full animate-pulse">SALIII!</div></div>
          )}
          {phase === "paused" && isFullscreen && (
            <div className="absolute inset-0 z-30 bg-black/60 flex flex-col items-center justify-center gap-3 p-5 text-center">
              <div className="font-display text-[14px] leading-none"><span className="text-[#ff5400]">KUBO</span> <span className="text-white">RUN</span></div>
              <div className="font-display text-white text-[28px] leading-none">PAUSA</div>
              {resumeCount !== null ? <div className="font-display text-white text-[48px] leading-none" aria-live="polite">{resumeCount === 0 ? "VIA!" : resumeCount}</div> : <button onClick={startResumeCountdown} className="bg-[#38f2c8] text-black font-display text-[14px] px-6 py-3 rounded-full active:scale-95">RIPRENDI</button>}
            </div>
          )}
          {phase === "paused" && !isFullscreen && (
            <div className="absolute inset-0 z-30 bg-black/75 flex flex-col items-center justify-center gap-3 p-5 text-center">
              <div className="font-display text-[14px] leading-none"><span className="text-[#ff5400]">KUBO</span> <span className="text-white">RUN</span></div>
              <div className="font-display text-white text-[28px] leading-none">PAUSA</div>
              <div className="text-[13px] text-[#cbd5e1]">Livello {selectedLevel} — {currentCfg.name} — {hud.m}m / {currentCfg.goal}m</div>
              <div className="text-[11px] text-[#8fa3b8]">Il gioco è fermo: pavimento, nemici e timer sono in pausa.</div>
              {resumeCount !== null ? (
                <div className="flex flex-col items-center gap-2 py-2" aria-live="polite"><div className="font-display text-[#38f2c8] text-[64px] leading-none">{resumeCount === 0 ? "VIA!" : resumeCount}</div><div className="text-[12px] font-bold text-white tracking-widest">PREPARATI…</div></div>
              ) : (
                <div className="flex flex-col gap-2 mt-1 w-[200px] max-w-full">
                  <button onClick={startResumeCountdown} className="w-[200px] max-w-full inline-flex items-center justify-center gap-2 bg-[#38f2c8] text-black font-display text-[14px] px-5 py-3 rounded-full active:scale-95"><Play size={16} /> ▶️ RIPRENDI</button>
                  <button onClick={restartFromPause} className="w-[200px] max-w-full inline-flex items-center justify-center gap-2 bg-[#ff5400] text-white font-display text-[14px] px-5 py-3 rounded-full active:scale-95"><RotateCcw size={16} /> 🔄 RICOMINCIA</button>
                  <button onClick={goToLevels} className="w-[200px] max-w-full inline-flex items-center justify-center gap-2 bg-[#161f33] border border-[#2a3a5e] text-white font-display text-[13px] px-5 py-3 rounded-full active:scale-95">🏠 SELEZIONE LIVELLI</button>
                  <button onClick={toggleMute} className="w-[200px] max-w-full inline-flex items-center justify-center gap-2 bg-[#0d1321] border border-[#2a3a5e] text-white font-display text-[13px] px-5 py-3 rounded-full active:scale-95">🔊 AUDIO {muted ? "OFF" : "ON"}</button>
                </div>
              )}
              <div className="text-[11px] text-[#8fa3b8]">P o Esc per riprendere · P per pausa</div>
            </div>
          )}
          {phase === "over" && isFullscreen && (
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-center p-5 gap-2">
              <div className="font-display text-[14px] leading-none"><span className="text-[#ff5400]">KUBO</span> <span className="text-white">RUN</span></div>
              <div className="font-display text-white text-[22px]">{isWin ? "🎉 LIVELLO COMPLETATO!" : "GAME OVER"}</div>
              <div className="text-white text-[14px]">{hud.m}m / {currentCfg.goal}m</div>
              {isWin && <div className="text-[22px] leading-none text-[#ffd23d]" aria-label={`${winStars} stelle su 3`}>{[1, 2, 3].map(i => <span key={i}>{i <= winStars ? "★" : "☆"}</span>)}</div>}
              <button onClick={() => startGame(selectedLevel)} className="bg-[#ff5400] text-white font-display text-[15px] px-6 py-3 rounded-full active:scale-95">RIGIOCA</button>
              {isWin && selectedLevel < 22 && <button onClick={() => startGame(selectedLevel + 1)} className="bg-[#38f2c8] text-black font-display text-[14px] px-6 py-3 rounded-full active:scale-95">PROSSIMO LIVELLO →</button>}
              <button onClick={goToMenu} className="bg-[#161f33] text-white font-display text-[13px] px-6 py-3 rounded-full active:scale-95">MENU</button>
            </div>
          )}
          {phase === "over" && !isFullscreen && (
            <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center text-center p-5 gap-2 overflow-y-auto">
              <div className="font-display text-[14px] leading-none"><span className="text-[#ff5400]">KUBO</span> <span className="text-white">RUN</span></div>
              <div className={`font-display text-[24px] ${isWin ? "text-[#4ade80]" : "text-[#ff3b6b]"}`}>{isWin ? "🎉 LIVELLO COMPLETATO!" : "GAME OVER"}</div>
              {isLegend && <div className="bg-[#ffd23d] text-black font-display text-[12px] px-3 py-1.5 rounded-full flex items-center gap-1"><Sparkles size={14} /> LEGGENDA DELL’ABISSO! <Sparkles size={14} /></div>}
              {isLegend && <div className="text-[18px] leading-none" aria-hidden="true">✨ 🎉 ✨ 🎉 ✨</div>}
              {deathCause === "floor" && !isWin && <div className="flex items-center gap-1 text-[#ff5400] font-bold text-[13px]"><Flame size={15} /> IL PAVIMENTO TI HA PRESO!</div>}
              <div className="font-display text-white text-[34px]">{hud.m} m</div>
              {isWin && <div className="text-[26px] leading-none" aria-label={`${winStars} stelle su 3`}>{[1, 2, 3].map(i => <span key={i}>{i <= winStars ? "★" : "☆"}</span>)}</div>}
              {isWin && <div className="text-[11px] text-[#cbd5e1]">Stelle in base a cuori rimasti e tempo · ♥ {hud.hp}/3</div>}
              <div className="text-[12px] text-[#ffd23d] font-bold">PUNTI {hud.points} · OBIETTIVO {currentCfg.goal}m · BEST LIV. {selectedLevel} {bestByLevel[selectedLevel] || 0} m</div>
              <p className="text-[12px] text-[#cbd5e1]">Livello {selectedLevel} — {currentCfg.name}. {isWin ? (selectedLevel < 22 ? "Prossimo mondo disponibile!" : "Hai completato tutti i 22 mondi!") : selectedLevel < 22 ? `Mancano ${Math.max(0, currentCfg.goal - hud.m)}m per completare.` : "Hai affrontato l’Abisso."}</p>
              <div className="flex flex-col gap-2 mt-1 w-full max-w-[220px]">
                {isWin && selectedLevel < 22 && <button onClick={() => startGame(selectedLevel + 1)} className="inline-flex items-center justify-center gap-2 bg-[#38f2c8] text-black font-display text-[15px] px-6 py-3 rounded-full active:scale-95">PROSSIMO LIVELLO →</button>}
                <button onClick={() => startGame(selectedLevel)} className="inline-flex items-center justify-center gap-2 bg-[#ff5400] text-white font-display text-[15px] px-6 py-3 rounded-full active:scale-95"><RotateCcw size={18} /> RIGIOCA (R)</button>
                <button onClick={goToMenu} className="inline-flex items-center justify-center gap-2 bg-[#161f33] border border-[#2a3a5e] text-white font-display text-[14px] px-6 py-3 rounded-full active:scale-95">MENU</button>
              </div>
              <span className="text-[11px] text-[#8fa3b8]">Premi R per rigiocare istantaneamente</span>
            </div>
          )}
          {!isFullscreen && phase === "playing" && (
            <button onClick={() => setPhase("paused")} className="absolute top-2 right-2 w-9 h-9 rounded-full bg-black/50 text-white flex items-center justify-center" aria-label="Pausa"><Pause size={16} /></button>
          )}
        </div>
      </main>
      <footer className={isFullscreen ? "absolute bottom-0 left-0 right-0 w-full mx-auto bg-transparent z-50 pointer-events-none" : "shrink-0 w-full max-w-[420px] mx-auto bg-[#0a0f1e] border-t border-[#1a2a4a] relative z-50"} style={isFullscreen ? { boxSizing: "border-box", height: "calc(128px + env(safe-area-inset-bottom))", minHeight: "calc(128px + env(safe-area-inset-bottom))", padding: "8px 14px calc(8px + env(safe-area-inset-bottom))" } : { boxSizing: "border-box", height: "calc(128px + env(safe-area-inset-bottom))", minHeight: "calc(128px + env(safe-area-inset-bottom))", padding: "8px 14px calc(8px + env(safe-area-inset-bottom))" }}>
        <div className="flex items-center justify-between h-full gap-2">
          <div onPointerDown={joyStart} onPointerMove={(e) => joy.current.active && updateJoy(e)} onPointerUp={joyEnd} onPointerCancel={joyEnd} className="w-[108px] h-[108px] shrink-0 rounded-full relative touch-none select-none pointer-events-auto" style={{ background: "rgba(13,19,33,0.62)", border: "4px solid rgba(30,42,68,0.95)", boxShadow: "0 10px 28px rgba(0,0,0,0.55), inset 0 0 0 2px rgba(255,255,255,0.12)" }} role="slider" aria-label="Pad di movimento: sinistra, destra, su per saltare, giù per scendere" aria-valuenow={0}>
            <span aria-hidden="true" className="absolute left-[8px] top-1/2 -translate-y-1/2 text-[12px] font-black text-[#8fa3b8] pointer-events-none">◀</span>
            <span aria-hidden="true" className="absolute right-[8px] top-1/2 -translate-y-1/2 text-[12px] font-black text-[#8fa3b8] pointer-events-none">▶</span>
            <span aria-hidden="true" className="absolute left-1/2 -translate-x-1/2 top-[6px] text-[12px] font-black text-[#8fa3b8] pointer-events-none">▲</span>
            <span aria-hidden="true" className="absolute left-1/2 -translate-x-1/2 bottom-[6px] text-[12px] font-black text-[#8fa3b8] pointer-events-none">▼</span>
            <div className="absolute w-[54px] h-[54px] rounded-full" style={{ left: `calc(50% - 27px + ${joyPos.x}px)`, top: `calc(50% - 27px + ${joyPos.y}px)`, backgroundColor: bonusPad, border: "3px solid rgba(0,0,0,0.45)", boxShadow: "0 6px 16px rgba(0,0,0,0.55), inset 0 -4px 0 rgba(0,0,0,0.22)" }} />
          </div>
          <button onPointerDown={(e) => { e.preventDefault(); startGrappleAim(); }} onPointerUp={(e) => { e.preventDefault(); launchGrapple(); }} onPointerCancel={() => launchGrapple()} onPointerLeave={() => launchGrapple()} onContextMenu={(e) => e.preventDefault()} style={hud.grappleReady && !grappleFlash ? { backgroundColor: bonusRamp, borderColor: bonusRamp, boxShadow: "0 10px 28px rgba(0,0,0,0.55), 0 0 26px rgba(0,229,255,0.35)", opacity: 0.94 } : { boxShadow: "0 10px 28px rgba(0,0,0,0.55)", opacity: 0.94 }} className={`w-[92px] h-[92px] shrink-0 rounded-full border-4 flex flex-col items-center justify-center gap-1 text-[9px] font-black tracking-widest transition-all pointer-events-auto ${grappleFlash ? "bg-white text-black border-white scale-110" : hud.grappleReady ? "text-black animate-pulse" : "bg-[#33415e] text-[#8fa3b8] border-[#2a3a5e]"}`} aria-label="Rampino: tieni premuto per mirare verso il muro, rilascia per lanciare"><Anchor size={36} strokeWidth={2.5} /><span>RAMPINO</span></button>
        </div>
      </footer>
      {showHelp && phase !== "menu" && !isFullscreen && (
        <div className="absolute inset-0 z-[80] bg-black/80 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Come si gioca">
          <div className="w-full max-w-[360px] max-h-[88dvh] overflow-y-auto bg-[#0d1321] border border-[#1e2a44] rounded-2xl p-4">
            <div className="flex items-start justify-between gap-2"><div className="font-display text-white text-[16px]">COME SI GIOCA</div><button onClick={() => setShowHelp(false)} className="w-8 h-8 rounded-full bg-[#161f33] text-white flex items-center justify-center" aria-label="Chiudi aiuto"><X size={16} /></button></div>
            <div className="text-[13px] leading-relaxed text-[#cbd5e1] mt-3 space-y-2">
              <p><b className="text-white">PAD (sinistra):</b> trascina a sinistra / destra per muoverti, SU per saltare, GIÙ per scendere veloce.</p>
              <p><b className="text-white">RAMPINO (destra):</b> tieni premuto per mirare, rilascia per sparare solo su-sinistra o su-destra a ~60° verso i muri laterali. Solo pareti sopra di te. Da appeso: PAD SU = salti via, PAD GIÙ = ti sganci e cadi, PAD lato opposto = ti sganci con spinta.</p>
              <p><b className="text-white">Tastiera:</b> A/D o frecce = muovi · W / Su / Spazio = salta · E/Q = rampino · P/Esc = pausa · R = rigioca · M = audio · F = tutto schermo.</p>
            </div>
            <button onClick={() => setShowHelp(false)} className="mt-4 w-full bg-[#38f2c8] text-black font-display text-[13px] py-2.5 rounded-full">HO CAPITO</button>
          </div>
        </div>
      )}
      <div className="sr-only">Tastiera: A/D o frecce per muoverti, Spazio o W per saltare, tieni premuto E o Q per mirare col rampino verso il muro e rilascia per lanciarlo, R per rigiocare, M per audio, F per tutto schermo.</div>
        </>
      )}
    </div>
    </>
  );
}
